// Flock Farm — generic key/value data store endpoints + worker-write validation.
//
// Extracted from server.js so server.js stays focused on middleware + mounting
// (same pattern dairy_farm and agri_farm already follow). All flock-specific
// worker-permission logic (which fields a worker may/may not touch on a bird,
// the "workers cannot mark birds as sold" rule, etc.) lives here and only here.
//
// Routes mounted at /api by server.js, so the public paths stay:
//   GET  /api/data/:key   — read any bucket (admin or worker)
//   PUT  /api/data/:key   — write a bucket (role-gated, optimistic-concurrency)
import express from 'express';
import mongoose from 'mongoose';
import DataStore from '../models/DataStore.js';
import Image from '../models/Image.js';
import { authRequired } from '../middleware/auth.js';

const router = express.Router();

// ─── Bucket whitelist + per-role write rules ────────────────────────────────
const ALLOWED_KEYS = [
  'birds', 'expenses', 'feed', 'eggs', 'settings',
  'vaccinations', 'customers', 'customerSales',
  'incubation', 'checklist', 'diary',
  'laborers', 'laborAttendance', 'laborAdvances',
  'suppliers', 'supplierPayments',
];

const ADMIN_ONLY_WRITE_KEYS = new Set([
  'birds', 'settings', 'customers',
  'laborers', 'laborAttendance', 'laborAdvances',
  'suppliers', 'supplierPayments',
]);

const WORKER_WRITE_KEYS = new Set([
  'expenses', 'feed', 'eggs', 'vaccinations',
  'customerSales', 'incubation', 'checklist', 'diary',
]);

// Workers may edit only these fields on a bird record. Everything else is
// immutable from a worker session — protects identity, sale price, photo, etc.
const WORKER_MUTABLE_BIRD_FIELDS = new Set([
  'status',
  'lastVaccinationDate',
  'dateDied',
  'deathReason',
  'deathDetail',
]);

const IMMUTABLE_BIRD_FIELDS_FOR_WORKERS = [
  'id',
  'name',
  'gender',
  'dateBought',
  'price',
  'ageBoughtDays',
  'breed',
  'customBreed',
  'image',
  'dateOfBirth',
  'salePrice',
  'saleDate',
];

// ─── Helpers ────────────────────────────────────────────────────────────────
function sameValue(a, b) {
  return JSON.stringify(a ?? null) === JSON.stringify(b ?? null);
}

function validateWorkerBirdWrite(existingBirds, incomingBirds) {
  if (!Array.isArray(existingBirds) || !Array.isArray(incomingBirds)) {
    return { ok: false, error: 'Bird data must stay an array.' };
  }
  if (existingBirds.length !== incomingBirds.length) {
    return { ok: false, error: 'Workers cannot add or delete birds.' };
  }

  const existingById = new Map(existingBirds.map((bird) => [bird.id, bird]));
  for (const bird of incomingBirds) {
    const previous = existingById.get(bird.id);
    if (!previous) {
      return { ok: false, error: 'Workers cannot create new bird records.' };
    }

    for (const field of IMMUTABLE_BIRD_FIELDS_FOR_WORKERS) {
      if (!sameValue(previous[field], bird[field])) {
        return { ok: false, error: `Workers cannot modify bird field "${field}".` };
      }
    }

    for (const key of Object.keys(bird)) {
      if (!WORKER_MUTABLE_BIRD_FIELDS.has(key) && !IMMUTABLE_BIRD_FIELDS_FOR_WORKERS.includes(key)) {
        if (!sameValue(previous[key], bird[key])) {
          return { ok: false, error: `Workers cannot modify bird field "${key}".` };
        }
      }
    }

    if (bird.status === 'Sold' && previous.status !== 'Sold') {
      return { ok: false, error: 'Workers cannot mark birds as sold.' };
    }
  }

  return { ok: true };
}

// ─── Image space GC ─────────────────────────────────────────────────────────
// Bird photos are stored as Image documents in MongoDB and referenced by
// '/api/images/<id>' paths inside the birds array. Whenever the birds bucket
// is saved, any image that is NO LONGER referenced (photo replaced, photo
// removed, or bird deleted) is deleted from the DB so storage space is freed
// instead of accumulating orphaned images forever.
function extractImageIds(value) {
  const ids = new Set();
  if (Array.isArray(value)) {
    for (const item of value) {
      const p = item && typeof item.image === 'string' ? item.image : '';
      const m = p.match(/^\/api\/images\/([a-f0-9]{24})$/i);
      if (m) ids.add(m[1]);
    }
  }
  return ids;
}

async function cleanupOrphanedBirdImages(oldIds, newIds) {
  try {
    const orphaned = [...oldIds].filter((id) => !newIds.has(id));
    for (const id of orphaned) {
      if (mongoose.isValidObjectId(id)) {
        await Image.findByIdAndDelete(id);
      }
    }
    if (orphaned.length > 0) {
      console.log(`🗑️  Freed ${orphaned.length} orphaned bird image(s) from the DB.`);
    }
  } catch (err) {
    console.error('Bird image cleanup failed (non-fatal):', err.message);
  }
}

// ─── GET /data/:key ─────────────────────────────────────────────────────────
// Any logged-in user (admin or worker) can read data.
// Returns `version` so clients can do optimistic-concurrency writes.
router.get('/data/:key', authRequired, async (req, res) => {
  const { key } = req.params;
  if (!ALLOWED_KEYS.includes(key)) {
    return res.status(400).json({ error: `Unknown data key: ${key}` });
  }
  try {
    const doc = await DataStore.findOne({ key });
    res.json({
      key,
      exists: !!doc,
      value: doc ? doc.value : null,
      version: doc ? (doc.version || 0) : 0,
    });
  } catch (err) {
    console.error('GET /api/data error:', err);
    res.status(500).json({ error: 'Failed to load data' });
  }
});

// ─── PUT /data/:key ─────────────────────────────────────────────────────────
// Authenticated write with SERVER-SIDE role enforcement. Workers may log
// day-to-day activity only; structural data remains admin-only even if someone
// bypasses the UI and calls the API directly.
//
// Concurrency: clients send `baseVersion` (the version they loaded). If the
// stored version differs, another user saved in between — reject with 409 and
// return the fresh data so the client can merge/reload instead of silently
// overwriting (last-write-wins data loss). The final write is CONDITIONAL on
// the version still matching, which also closes the worker-validation
// read-then-write race (TOCTOU).
router.put('/data/:key', authRequired, async (req, res) => {
  const { key } = req.params;
  if (!ALLOWED_KEYS.includes(key)) {
    return res.status(400).json({ error: `Unknown data key: ${key}` });
  }
  try {
    const { value, baseVersion } = req.body;

    // Role gate first (cheap, no DB read needed for the non-birds cases)
    if (req.user.role !== 'admin') {
      if (key !== 'birds') {
        if (!WORKER_WRITE_KEYS.has(key)) {
          return res.status(403).json({ error: `Workers cannot modify "${key}"` });
        }
        if (ADMIN_ONLY_WRITE_KEYS.has(key)) {
          return res.status(403).json({ error: `Admin role required to modify "${key}"` });
        }
      }
    }

    const current = await DataStore.findOne({ key });
    const currentVersion = current ? (current.version || 0) : 0;
    // Snapshot image references BEFORE the write — needed for the bird-image
    // GC below (in-memory mode returns live objects, so reading after the
    // update would already show the new value).
    const oldImageIds = key === 'birds' ? extractImageIds(current ? current.value : null) : null;

    // Optimistic-concurrency check (only when the client opts in by sending
    // baseVersion — keeps backwards compatibility with older clients).
    if (baseVersion !== undefined && baseVersion !== null) {
      const base = Number(baseVersion);
      if (!Number.isFinite(base) || base !== currentVersion) {
        return res.status(409).json({
          error: 'This data was changed by another user since you loaded it. Refresh to get the latest version.',
          conflict: true,
          key,
          value: current ? current.value : null,
          version: currentVersion,
        });
      }
    }

    // Worker bird-write validation against the same snapshot we version-check
    if (req.user.role !== 'admin' && key === 'birds') {
      const validation = validateWorkerBirdWrite(current?.value ?? [], value);
      if (!validation.ok) {
        return res.status(403).json({ error: validation.error });
      }
    }

    // Conditional write: only succeeds if version is still what we read.
    // Legacy docs (created before versioning) have no `version` field at all,
    // and `{version: 0}` does NOT match a missing field in MongoDB — so when
    // the expected version is 0, also accept docs where the field is absent.
    let doc;
    if (current) {
      const versionMatch = currentVersion === 0
        ? { $or: [{ version: 0 }, { version: null }, { version: { $exists: false } }] }
        : { version: currentVersion };
      doc = await DataStore.findOneAndUpdate(
        { key, ...versionMatch },
        { $set: { value, version: currentVersion + 1 } },
        { new: true }
      );
    } else {
      try {
        doc = await DataStore.create({ key, value, version: 1 });
      } catch (createErr) {
        // Duplicate key: someone else created the doc concurrently
        if (createErr && createErr.code === 11000) doc = null;
        else throw createErr;
      }
    }

    if (!doc) {
      const fresh = await DataStore.findOne({ key });
      return res.status(409).json({
        error: 'This data was changed by another user while saving. Refresh to get the latest version.',
        conflict: true,
        key,
        value: fresh ? fresh.value : null,
        version: fresh ? (fresh.version || 0) : 0,
      });
    }

    // Free storage: delete Image docs no longer referenced by any bird
    if (key === 'birds' && oldImageIds) {
      await cleanupOrphanedBirdImages(oldImageIds, extractImageIds(doc.value));
    }

    res.json({ key, exists: true, value: doc.value, version: doc.version || 0 });
  } catch (err) {
    console.error('PUT /api/data error:', err);
    res.status(500).json({ error: 'Failed to save data' });
  }
});

export default router;
