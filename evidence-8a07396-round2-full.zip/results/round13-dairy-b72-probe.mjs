import { spawn } from 'node:child_process';
async function boot(dir, port) {
  const proc = spawn(process.execPath, ['server.js'], { cwd: dir, env: { ...process.env, PORT: String(port), MEMORY_MODE: '1', JWT_SECRET: 'testingcake987', DISABLE_INTERNAL_SCHEDULER: '1', NODE_ENV: 'test' }, stdio: 'ignore' });
  const base = `http://127.0.0.1:${port}`;
  for (let i = 0; i < 60; i++) { try { const r = await fetch(base + '/api/farms'); if (r.status) break; } catch { await new Promise(r => setTimeout(r, 400)); } }
  return { proc, base };
}
async function login(base, path, u, p) {
  const r = await fetch(base + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: u, password: p }) });
  await r.text();
  return r.status;
}
// DAIRY isolated
{
  const { proc, base } = await boot('/home/user/verify-clone/dairy_farm/backend', 18651);
  const owner = await (await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'admin', password: 'admin123' }) })).json().then(j => j.token);
  const p72 = 'A'.repeat(72) + 'X';
  const farmsD = await (await fetch(base + '/api/farms', { headers: { Authorization: `Bearer ${owner}` } })).json();
  const farmA = (farmsD.farms || farmsD)[0].id || (farmsD.farms || farmsD)[0]._id;
  const u = 'b72dairy' + Date.now().toString(36);
  const su = await fetch(base + '/api/auth/users', { method: 'POST', headers: { Authorization: `Bearer ${owner}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ username: u, password: p72, role: 'worker', email: u + '@t.local', farmIds: [farmA] }) });
  console.log('DAIRY create 73-byte-pw user ->', su.status, (await su.text()).slice(0, 120));
  console.log('DAIRY login correct 73-byte ->', await login(base, '/api/auth/login', u, p72));
  console.log('DAIRY login byte73-differs ->', await login(base, '/api/auth/login', u, 'A'.repeat(72) + 'Y'));
  console.log('DAIRY login 71A+B+padding ->', await login(base, '/api/auth/login', u, 'A'.repeat(71) + 'B' + 'X'));
  proc.kill('SIGKILL');
}
// AGRI create status for the record
{
  const { proc, base } = await boot('/home/user/verify-clone/agri_farm/backend', 18652);
  const owner = await (await fetch(base + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'admin', password: 'admin123' }) })).json().then(j => j.access_token);
  const farms = await (await fetch(base + '/api/farms', { headers: { Authorization: `Bearer ${owner}` } })).json();
  const farmA = farms.farms[0].id;
  const p72 = 'A'.repeat(72) + 'X';
  const u = 'b72agri' + Date.now().toString(36);
  const su = await fetch(base + '/api/signup', { method: 'POST', headers: { Authorization: `Bearer ${owner}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ username: u, password: p72, role: 'worker', email: u + '@t.local', farmIds: [farmA] }) });
  console.log('AGRI create 73-byte-pw user ->', su.status, (await su.text()).slice(0, 160));
  proc.kill('SIGKILL');
}
process.exit(0);
