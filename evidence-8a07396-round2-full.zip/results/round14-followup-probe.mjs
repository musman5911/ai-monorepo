import { spawn } from 'node:child_process';
async function boot(dir, port) {
  const proc = spawn(process.execPath, ['server.js'], { cwd: dir, env: { ...process.env, PORT: String(port), MEMORY_MODE: '1', JWT_SECRET: 'testingcake987', DISABLE_INTERNAL_SCHEDULER: '1', NODE_ENV: 'test' }, stdio: 'ignore' });
  const base = `http://127.0.0.1:${port}`;
  for (let i = 0; i < 60; i++) { try { const r = await fetch(base + '/api/farms'); if (r.status) break; } catch { await new Promise(r => setTimeout(r, 400)); } }
  return { proc, base };
}
// Dairy: 12MB body + object-name storage + dailylog Feb30 read-back
{
  const { proc, base } = await boot('/home/user/verify-clone/dairy_farm/backend', 18671);
  const tok = await (await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'admin', password: 'admin123' }) })).json().then(j => j.token);
  const farms = await (await fetch(base + '/api/farms', { headers: { Authorization: `Bearer ${tok}` } })).json();
  const farmA = (farms.farms || farms)[0].id || (farms.farms || farms)[0]._id;
  const H = { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json', 'X-Farm-Id': farmA };
  const big = await fetch(base + '/api/cows', { method: 'POST', headers: H, body: JSON.stringify({ name: 'z'.repeat(12_000_000), breed: 'Jersey' }) });
  console.log('DAIRY 12MB body ->', big.status, (await big.text()).slice(0, 80));
  const obj = await fetch(base + '/api/cows', { method: 'POST', headers: H, body: JSON.stringify({ name: { $ne: null }, breed: 'Jersey', gender: 'female', status: 'active' }) });
  const oj = await obj.json().catch(() => ({}));
  console.log('DAIRY object-name create ->', obj.status, 'stored name =', JSON.stringify(oj.name ?? oj.record?.name ?? oj));
  const feb = await fetch(base + '/api/dailylog/2026-02-30', { headers: H });
  console.log('DAIRY GET dailylog/2026-02-30 ->', feb.status, (await feb.text()).slice(0, 120));
  proc.kill('SIGKILL');
}
// Agri + Flock 12MB
for (const [tag, dir, port, path, loginPath, key, body] of [
  ['AGRI', '/home/user/verify-clone/agri_farm/backend', 18672, '/api/crops', '/api/login', 'access_token', { name: 'z'.repeat(12_000_000) }],
  ['FLOCK', '/home/user/verify-clone/flock_farm/backend', 18673, '/api/batches', '/api/auth/login', 'token', { name: 'z'.repeat(12_000_000), type: 'Broiler', start_date: '2026-09-01', intake_count: 1, cost_per_bird: 1 }],
]) {
  const { proc, base } = await boot(dir, port);
  const tok = await (await fetch(base + loginPath, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'admin', password: 'admin123' }) })).json().then(j => j[key]);
  const farms = await (await fetch(base + '/api/farms', { headers: { Authorization: `Bearer ${tok}` } })).json();
  const farmA = (farms.farms || farms)[0].id;
  const big = await fetch(base + path, { method: 'POST', headers: { Authorization: `Bearer ${tok}`, 'Content-Type': 'application/json', 'X-Farm-Id': farmA }, body: JSON.stringify(body) });
  console.log(tag, '12MB body ->', big.status, (await big.text()).slice(0, 80));
  proc.kill('SIGKILL');
}
process.exit(0);
