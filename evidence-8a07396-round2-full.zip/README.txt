EVIDENCE PACKAGE — DEEP ROUND 2 (Parts 1–10), test-only. NO app code changed.
Tested upstream commit: 8a073965763a6a4a6cc2bae0a341508cac91b178
Full findings: FINAL-REPORT-round2.md (ID table, untestable list, design
decisions, top-10). Supersedes evidence-8a07396-part1-part2.zip (Parts 1–2).

CONTENTS
  FINAL-REPORT-round2.md          the report (start here)
  README.txt                      this file
  tests/api-matrix/               harness + matrix suites (prior rounds)
  tests/api-deep/                 prior deep suites + NEW round13-sessions,
                                  round14-fuzz, round15-concurrency
  tests/toolchain/                fast-check property suites
  tests/verification/             NEW: authz-matrix.mjs (Part 3 route×actor
                                  matrix), unit-farm-guards.test.ts +
                                  semgrep-rules.yml (Part 9), load-locust.py +
                                  run-load.sh (Part 10), RUN-REAL-MONGO.md
                                  (exact commands for everything the sandbox
                                  could not run)
  vitest.unit.config.ts           unit-only vitest config (mutation baseline)
  stryker.config.json             Stryker config (Part 9)
  e2e/, playwright.config.ts      Playwright/axe spec (NOT run — no browser)
  results/                        RAW outputs per part (see index in report):
    api-matrix-and-toolchain.txt  api-deep.txt  upstream-own-suite.txt
    contested-probes-output.txt   round12-photos.txt  round12-flock.txt
    flock-upload-probes.txt       authz-{dairy,agri,flock}.txt (Part 3)
    round13-sessions.txt          round13-dairy-b72-probe.mjs + output (Part 4)
    round14-fuzz.txt              round14-followup-*  round14-nul-output.txt
    round15-concurrency.txt       round15-flock-delete-output.txt (Part 6)
    round16-part7-output.txt      round16-flock-prod500-output.txt (Part 7)
    round17-telegram-k1-output.txt  round17-l1-cron-output.txt (Part 8)
    round18-startup-guards-output.txt (Part 9)
    audit/                        npm audit JSON ×7 + summaries, eslint-plugin-
                                  security JSON ×3, semgrep-summary.txt,
                                  stryker-tail.txt (Part 9)
    load/                         locust CSVs ×9 + run-output (Part 10)

ENVIRONMENT (unless a probe says otherwise): MEMORY_MODE=1
JWT_SECRET=[SECURITY_DATA] (harness value; see note) DISABLE_INTERNAL_SCHEDULER=1
NODE_ENV=test, no FRONTEND_URL, no real CLOUDINARY_* / TELEGRAM_* except where
a probe sets fakes explicitly. Memory mode only — real MongoDB is UNVERIFIED
with exact user commands in tests/verification/RUN-REAL-MONGO.md.

INSTALL (from a fresh clone of the tested commit)
  npm install
  for d in dairy_farm/backend agri_farm/backend flock_farm/backend \
           dairy_farm/client agri_farm/frontend flock_farm/client; do
    (cd $d && npm install)
  done
  npm i -D vitest@3 fast-check @stryker-mutator/core @stryker-mutator/vitest-runner
  # (fast-check was missing from the Round-1 README — it is required by
  #  tests/toolchain.)

COMMANDS
  npx vitest run tests/api-matrix tests/toolchain
  npx vitest run tests/api-deep
  npx vitest run tests/api-deep/round13-sessions.test.ts
  npx vitest run tests/api-deep/round14-fuzz.test.ts
  npx vitest run tests/api-deep/round15-concurrency.test.ts
  node tests/verification/authz-matrix.mjs dairy|agri|flock
  npx vitest run --config vitest.unit.config.ts
  npx stryker run
  bash tests/verification/run-load.sh        (needs: pip install locust)
  semgrep --config tests/verification/semgrep-rules.yml <app>/backend

KNOWN TEST-SIDE ARTIFACTS (found & fixed during Round 2; details in report §0)
  * authz-matrix.mjs originally created managers with a password string that a
    redaction had replaced with the literal "[SECURITY_DATA]" while login used
    the real one → all manager columns showed 401. FIXED (password via MP
    constant); matrices re-run clean. The app was never at fault.
  * Some pre-Round-2 suites intentionally use "[SECURITY_DATA]" as BOTH the
    created password and the login password (and as the harness JWT_SECRET vs
    the token-forging secret) — consistent pairs, harmless.
  * Dairy's login limiter (10/5min/IP) can 429 a busy test file mid-run; the
    isolated bcrypt-72 probe (results/round13-dairy-b72-probe.mjs) exists for
    exactly that reason.
