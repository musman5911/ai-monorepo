/** ROUND 14 (Deep R2 Part 5): deep fuzz of write routes — type confusion, NoSQL
 *  operators, __proto__, NUL, extreme numbers, invalid dates, pagination/search
 *  abuse, body-size limits. Counts every 5xx. NO app code changes. */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

type T = { create: string; list: string; goodBody: any; numField: string; nameField: string };
const TARGETS: Record<string, T> = {
  dairy: { create: '/cows', list: '/cows', goodBody: { name: `FuzzCow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' }, numField: 'weight', nameField: 'name' },
  agri: { create: '/crops', list: '/crops', goodBody: { name: `FuzzCrop ${S}`, status: 'Growing', plant_date: '2026-09-01' }, numField: 'area_acres', nameField: 'name' },
  flock: { create: '/batches', list: '/batches', goodBody: { name: `FuzzBatch ${S}`, type: 'Broiler', start_date: '2026-09-01', intake_count: 10, cost_per_bird: 5 }, numField: 'intake_count', nameField: 'name' },
};

function suite(app: 'dairy' | 'agri' | 'flock', dir: string) {
  describe.sequential(`ROUND 14 fuzz (${app})`, () => {
    const t = TARGETS[app];
    let ctx: Ctx; let farmA = '';
    const violations: string[] = [];
    const seen: Array<[string, number]> = [];
    const probe = async (tag: string, route: string, opts: any) => {
      const r = await raw(ctx, route, { token: ctx.owner, farmId: farmA, ...opts });
      seen.push([tag, r.response.status]);
      if (r.response.status >= 500) violations.push(`${tag} -> ${r.response.status}`);
      return r;
    };

    beforeAll(async () => {
      ctx = await startApp(app, dir);
      const farms = await raw(ctx, '/farms', { token: ctx.owner });
      const list = (farms.data as any)?.farms || [];
      farmA = String(list[0]?.id || list[0]?._id || '');
    }, 180_000);
    afterAll(async () => { await stopApp(ctx); }, 60_000);

    it('write-route hostile battery produces no 5xx', async () => {
      const B = (patch: any) => ({ ...t.goodBody, ...patch });
      await probe('empty-body', t.create, { method: 'POST', body: {} });
      await probe('name-number', t.create, { method: 'POST', body: B({ [t.nameField]: 12345 }) });
      await probe('name-null', t.create, { method: 'POST', body: B({ [t.nameField]: null }) });
      await probe('name-object-nosql', t.create, { method: 'POST', body: B({ [t.nameField]: { $ne: null } }) });
      await probe('name-array', t.create, { method: 'POST', body: B({ [t.nameField]: ['x'] }) });
      await probe('name-bool', t.create, { method: 'POST', body: B({ [t.nameField]: true }) });
      await probe('num-string-abc', t.create, { method: 'POST', body: B({ [t.numField]: 'abc' }) });
      await probe('num-string-money', t.create, { method: 'POST', body: B({ [t.numField]: '19.99' }) });
      await probe('num-1e308', t.create, { method: 'POST', body: B({ [t.numField]: 1e308 }) });
      await probe('num-negative', t.create, { method: 'POST', body: B({ [t.numField]: -50 }) });
      await probe('num-object-gt', t.create, { method: 'POST', body: B({ [t.numField]: { $gt: 0 } }) });
      await probe('name-nul', t.create, { method: 'POST', body: B({ [t.nameField]: `Nu\u0000ll${S}` }) });
      await probe('name-100k', t.create, { method: 'POST', body: B({ [t.nameField]: 'x'.repeat(100_000) }) });
      await probe('extra-proto-field', t.create, { method: 'POST', body: B({ constructor: { prototype: { polluted13: 'yes' } } }) });
      for (const [tag, s] of seen) console.log(`${app} ${tag} -> ${s}`);
      expect(violations, `5xx violations: ${violations.join('; ')}`).toEqual([]);
    }, 120_000);

    it('__proto__ payload is not stored/reflected (no prototype pollution echo)', async () => {
      const marker = `polluted13${S}`;
      await raw(ctx, t.create, { method: 'POST', token: ctx.owner, farmId: farmA, body: { ...t.goodBody, [t.nameField]: `Proto ${S}`, __proto__: { [marker]: 'yes' } } });
      const list = await raw(ctx, t.list, { token: ctx.owner, farmId: farmA });
      const text = JSON.stringify(list.data);
      expect(list.response.status).toBe(200);
      expect(text.includes(marker), 'proto marker reflected in list response').toBe(false);
      expect(({} as any)[marker]).toBeUndefined();
    }, 60_000);

    it('list pagination/search abuse: no 5xx, search stays fast', async () => {
      const bad: string[] = [];
      for (const q of ['?limit=-1', '?limit=abc', '?limit=10000000', '?page=-3', '?offset=-1', '?limit=1e9', '?sort=$where']) {
        const r = await raw(ctx, t.list + q, { token: ctx.owner, farmId: farmA });
        if (r.response.status >= 500) bad.push(`${q} -> ${r.response.status}`);
      }
      const t0 = Date.now();
      const rs = await raw(ctx, `${t.list}?search=${'a'.repeat(4000)}!`, { token: ctx.owner, farmId: farmA });
      const ms = Date.now() - t0;
      console.log(`${app} search-bomb -> ${rs.response.status} in ${ms}ms`);
      if (rs.response.status >= 500) bad.push(`search-bomb -> ${rs.response.status}`);
      expect(ms, 'search with 4000-char term must answer < 5000ms').toBeLessThan(5000);
      const rq = await raw(ctx, `${t.list}?status[$ne]=zzz`, { token: ctx.owner, farmId: farmA });
      if (rq.response.status >= 500) bad.push(`nosql-query -> ${rq.response.status}`);
      console.log(`${app} nosql-query status[$ne] -> ${rq.response.status}`);
      expect(bad, `pagination/search 5xx: ${bad.join('; ')}`).toEqual([]);
    }, 120_000);

    it('body-size limits: 5MB field and 12MB body are not accepted as normal creates', async () => {
      const five = await raw(ctx, t.create, { method: 'POST', token: ctx.owner, farmId: farmA, body: { ...t.goodBody, [t.nameField]: 'y'.repeat(5_000_000) } });
      console.log(`${app} 5MB-name create -> ${five.response.status}`);
      expect(five.response.status, '5MB name must not be a normal 201 create').not.toBe(201);
      const twelve = await fetch(`${ctx.base}/api${t.create}`, { method: 'POST', headers: { Authorization: `Bearer ${ctx.owner}`, 'Content-Type': 'application/json', 'X-Farm-Id': farmA }, body: JSON.stringify({ ...t.goodBody, [t.nameField]: 'z'.repeat(12_000_000) }) });
      await twelve.text();
      console.log(`${app} 12MB body -> ${twelve.status}`);
      expect(twelve.status, '12MB body should hit the 10mb parser limit (413)').toBe(413);
    }, 120_000);
  });
}

suite('dairy', 'dairy_farm/backend');
suite('agri', 'agri_farm/backend');
suite('flock', 'flock_farm/backend');

describe.sequential('ROUND 14 dairy date edges (dailylog)', () => {
  let ctx: Ctx; let farmA = '';
  beforeAll(async () => {
    ctx = await startApp('dairy', 'dairy_farm/backend');
    const farms = await raw(ctx, '/farms', { token: ctx.owner });
    const list = (farms.data as any)?.farms || [];
    farmA = String(list[0]?.id || list[0]?._id || '');
  }, 180_000);
  afterAll(async () => { await stopApp(ctx); }, 60_000);

  it('invalid calendar dates are rejected, not stored or 500', async () => {
    const bad: string[] = [];
    for (const d of ['2026-02-30', '2026-13-01', '0000-00-00', 'not-a-date', '2026-1-1', '9999-12-31', '1970-01-01']) {
      const r = await raw(ctx, `/dailylog/${d}`, { method: 'PUT', token: ctx.owner, farmId: farmA, body: { notes: `edge ${d}` } });
      console.log(`dailylog PUT ${d} -> ${r.response.status}`);
      if (r.response.status >= 500) bad.push(`${d} -> ${r.response.status}`);
      if (['2026-02-30', '2026-13-01', '0000-00-00', 'not-a-date'].includes(d)) {
        expect(r.response.status, `${d} should be 4xx, got ${r.response.status}`).toBeGreaterThanOrEqual(400);
        expect(r.response.status).toBeLessThan(500);
      }
    }
    expect(bad).toEqual([]);
  }, 60_000);
});
