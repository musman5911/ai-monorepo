/** ROUND 15 (Deep R2 Part 6): concurrency + restore robustness + flock import/export.
 *  20x parallel double-submit, 10x parallel DELETE, concurrent restores, extra/missing
 *  collections, 101MB restore, flock export->import round-trip. NO app code changes. */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, rowsOf, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const CREATE: Record<string, { route: string; list: string; body: any }> = {
  dairy: { route: '/cows', list: '/cows', body: { name: `ConcCow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } },
  agri: { route: '/crops', list: '/crops', body: { name: `ConcCrop ${S}`, status: 'Growing', plant_date: '2026-09-01' } },
  flock: { route: '/batches', list: '/batches', body: { name: `ConcBatch ${S}`, type: 'Broiler', start_date: '2026-09-01', intake_count: 10, cost_per_bird: 5 } },
};
const RESTORE: Record<string, string> = { dairy: '/backup/restore', agri: '/restore', flock: '/backup/restore' };

function suite(app: 'dairy' | 'agri' | 'flock', dir: string) {
  describe.sequential(`ROUND 15 concurrency (${app})`, () => {
    const c = CREATE[app];
    let ctx: Ctx; let farmA = '';
    beforeAll(async () => {
      ctx = await startApp(app, dir);
      const farms = await raw(ctx, '/farms', { token: ctx.owner });
      const list = (farms.data as any)?.farms || [];
      farmA = String(list[0]?.id || list[0]?._id || '');
    }, 180_000);
    afterAll(async () => { await stopApp(ctx); }, 60_000);

    it('20x parallel identical creates: no 5xx (duplicate count recorded)', async () => {
      const rs = await Promise.all(Array.from({ length: 20 }, () => raw(ctx, c.route, { method: 'POST', token: ctx.owner, farmId: farmA, body: c.body })));
      const codes = rs.map(r => r.response.status);
      const list = await raw(ctx, `${c.list}?limit=500`, { token: ctx.owner, farmId: farmA });
      const marker = String(c.body.name);
      const count = rowsOf(list.data).filter((x: any) => String(x.name || '').includes(marker)).length;
      console.log(`${app} 20x parallel create codes: ${codes.join(',')} | records with marker: ${count}`);
      expect(codes.every(s => s < 500), `5xx in parallel creates: ${codes.join(',')}`).toBe(true);
      expect(count, 'at least one record must exist').toBeGreaterThanOrEqual(1);
    }, 120_000);

    it('10x parallel DELETE of the same record: exactly one success, no 5xx', async () => {
      const one = await raw(ctx, c.route, { method: 'POST', token: ctx.owner, farmId: farmA, body: { ...c.body, name: `DelTarget ${S}` } });
      const id = app === 'flock' ? String((one.data as any)?.batch?.batch_id || idOf(one.data)) : idOf(one.data);
      expect(id).toBeTruthy();
      const rs = await Promise.all(Array.from({ length: 10 }, () => raw(ctx, `${c.route}/${id}`, { method: 'DELETE', token: ctx.owner, farmId: farmA })));
      const codes = rs.map(r => r.response.status);
      const wins = codes.filter(s => s >= 200 && s < 300).length;
      console.log(`${app} 10x parallel DELETE codes: ${codes.join(',')} | successes=${wins}`);
      expect(codes.every(s => s < 500)).toBe(true);
      expect(wins, `exactly one DELETE should succeed, got ${wins}: ${codes.join(',')}`).toBe(1);
    }, 120_000);

    it('3x concurrent restores of the same backup: no 5xx, farm count stable', async () => {
      const backup = await raw(ctx, '/backup', { token: ctx.owner });
      expect(backup.response.status).toBe(200);
      const farmsBefore = ((await raw(ctx, '/farms', { token: ctx.owner })).data as any)?.farms?.length;
      const rs = await Promise.all([1, 2, 3].map(() => raw(ctx, RESTORE[app], { method: 'POST', token: ctx.owner, body: backup.data })));
      const codes = rs.map(r => r.response.status);
      const farmsAfter = ((await raw(ctx, '/farms', { token: ctx.owner })).data as any)?.farms?.length;
      console.log(`${app} concurrent restore codes: ${codes.join(',')} | farms ${farmsBefore} -> ${farmsAfter}`);
      expect(codes.every(s => s < 500)).toBe(true);
      expect(farmsAfter).toBe(farmsBefore);
    }, 180_000);

    it('restore with an extra unknown collection + missing collections: no 5xx, farms intact', async () => {
      const backup = await raw(ctx, '/backup', { token: ctx.owner });
      const farmsBefore = ((await raw(ctx, '/farms', { token: ctx.owner })).data as any)?.farms?.length;
      const tampered: any = { ...(backup.data as any), evilCollection13: [{ _id: 'x1', name: 'injected' }], version: 1 };
      delete tampered.farms;
      const r = await raw(ctx, RESTORE[app], { method: 'POST', token: ctx.owner, body: tampered });
      const farmsAfter = ((await raw(ctx, '/farms', { token: ctx.owner })).data as any)?.farms?.length;
      console.log(`${app} tampered restore -> ${r.response.status} | farms ${farmsBefore} -> ${farmsAfter}`);
      expect(r.response.status).toBeLessThan(500);
      expect(farmsAfter, 'farms must survive a partial/tampered restore').toBe(farmsBefore);
    }, 120_000);

    it('restore body over the 100MB restore limit is 413, not a crash', async () => {
      const pad = 'p'.repeat(101 * 1024 * 1024);
      const res = await fetch(`${ctx.base}/api${RESTORE[app]}`, { method: 'POST', headers: { Authorization: `Bearer ${ctx.owner}`, 'Content-Type': 'application/json' }, body: `{"pad":"${pad}"}` });
      await res.text();
      console.log(`${app} 101MB restore -> ${res.status}`);
      expect(res.status).toBe(413);
      const alive = await raw(ctx, '/farms', { token: ctx.owner });
      expect(alive.response.status).toBe(200);
    }, 180_000);
  });
}

suite('dairy', 'dairy_farm/backend');
suite('agri', 'agri_farm/backend');
suite('flock', 'flock_farm/backend');

describe.sequential('ROUND 15 flock export/import round-trip (J1 recheck)', () => {
  let ctx: Ctx; let farmA = '';
  beforeAll(async () => {
    ctx = await startApp('flock', 'flock_farm/backend');
    const farms = await raw(ctx, '/farms', { token: ctx.owner });
    const list = (farms.data as any)?.farms || [];
    farmA = String(list[0]?.id || list[0]?._id || '');
  }, 180_000);
  afterAll(async () => { await stopApp(ctx); }, 60_000);

  it('export -> import -> import again: batch count never duplicates', async () => {
    const mk = await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, farmId: farmA, body: { name: `RT Batch ${S}`, type: 'Broiler', start_date: '2026-09-01', intake_count: 7, cost_per_bird: 3 } });
    expect([200, 201]).toContain(mk.response.status);
    const count = async () => rowsOf((await raw(ctx, '/batches?limit=500', { token: ctx.owner, farmId: farmA })).data).filter((x: any) => String(x.name || '').includes(`RT Batch ${S}`)).length;
    const before = await count();
    const exp = await raw(ctx, '/batches/export-all', { token: ctx.owner, farmId: farmA });
    console.log(`flock export-all -> ${exp.response.status} bytes=${JSON.stringify(exp.data).length}`);
    expect(exp.response.status).toBe(200);
    const imp1 = await raw(ctx, '/batches/import-all', { method: 'POST', token: ctx.owner, farmId: farmA, body: exp.data });
    const after1 = await count();
    const imp2 = await raw(ctx, '/batches/import-all', { method: 'POST', token: ctx.owner, farmId: farmA, body: exp.data });
    const after2 = await count();
    console.log(`flock import#1 -> ${imp1.response.status}, import#2 -> ${imp2.response.status} | marker count ${before} -> ${after1} -> ${after2}`);
    expect(imp1.response.status).toBeLessThan(500);
    expect(imp2.response.status).toBeLessThan(500);
    expect(after2, `re-import must not duplicate batches (${before} -> ${after1} -> ${after2})`).toBe(before);
  }, 180_000);
});
