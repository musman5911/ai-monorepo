/** ROUND 13 (Deep R2 Part 4): session/token lifecycle — deactivation, role demotion,
 *  farmIds removal, bcrypt 72-byte, 1MB password, XFF vs rate limiter, cross-app
 *  tokens, forgot-password enumeration. NO app code changes. */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const PW = 'RoleTest123!';
type Cfg = { users: string; login: string; list: string; usersList: string; edit: (id: string) => string; forgot: string };
const CFG: Record<string, Cfg> = {
  dairy: { users: '/auth/users', login: '/auth/login', list: '/cows', usersList: '/auth/users', edit: (id) => `/auth/users/${id}`, forgot: '/auth/forgot-password' },
  agri: { users: '/signup', login: '/login', list: '/crops', usersList: '/users', edit: (id) => `/users/${id}/edit`, forgot: '/forgot-password' },
  flock: { users: '/auth/users', login: '/auth/login', list: '/batches', usersList: '/auth/users', edit: (id) => `/auth/users/${id}`, forgot: '/auth/forgot-password' },
};

function suite(app: 'dairy' | 'agri' | 'flock', dir: string) {
  describe.sequential(`ROUND 13 sessions (${app})`, () => {
    const cfg = CFG[app];
    let ctx: Ctx;
    let farmA = ''; let farmB = '';
    const loginAs = async (u: string, p: string) => {
      const r = await raw(ctx, cfg.login, { method: 'POST', body: { username: u, password: p } });
      return { status: r.response.status, token: String((r.data as any)?.token || (r.data as any)?.access_token || '') };
    };
    const mkUser = async (tag: string, role: string, farmIds: string[], password = PW) => {
      const u = `r13${tag}${S}`;
      const r = await raw(ctx, cfg.users, { method: 'POST', token: ctx.owner, farmId: app === 'flock' ? farmIds[0] : undefined, body: { username: u, password, role, email: `${u}@t.local`, farmIds } });
      const id = String((r.data as any)?.id || (r.data as any)?._id || (r.data as any)?.user?.id || (r.data as any)?.user?._id || idOf(r.data) || '');
      return { u, id, status: r.response.status };
    };
    const findId = async (username: string) => {
      const r = await raw(ctx, cfg.usersList, { token: ctx.owner });
      const rows = Array.isArray(r.data) ? r.data : (r.data as any)?.users || (r.data as any)?.items || [];
      const hit = rows.find((x: any) => x.username === username);
      return String(hit?._id || hit?.id || '');
    };

    beforeAll(async () => {
      ctx = await startApp(app, dir);
      const farms = await raw(ctx, '/farms', { token: ctx.owner });
      const list = (farms.data as any)?.farms || [];
      farmA = String(list[0]?.id || list[0]?._id || '');
      const fb = await raw(ctx, '/farms', { method: 'POST', token: ctx.owner, body: { name: `R13 FarmB ${S}` } });
      farmB = String((fb.data as any)?.id || idOf(fb.data));
      expect(farmA && farmB && farmA !== farmB).toBeTruthy();
    }, 180_000);
    afterAll(async () => { await stopApp(ctx); }, 60_000);

    it('role demotion manager->worker revokes manager powers on the OLD token', async () => {
      const m = await mkUser('dm', 'manager', [farmA]);
      const id = m.id || (await findId(m.u));
      const { token } = await loginAs(m.u, PW);
      expect((await raw(ctx, cfg.usersList, { token, farmId: farmA })).response.status, 'mgr usersList before demotion').toBe(200);
      const ed = await raw(ctx, cfg.edit(id), { method: 'PATCH', token: ctx.owner, body: { adminPassword: 'admin123', role: 'worker' } });
      expect([200, 204], `demote edit -> ${ed.response.status} ${JSON.stringify(ed.data).slice(0, 120)}`).toContain(ed.response.status);
      const after = await raw(ctx, cfg.usersList, { token, farmId: farmA });
      expect(after.response.status, `OLD token usersList after demotion (want 403, got ${after.response.status})`).toBe(403);
    }, 60_000);

    it('removing farmIds revokes the OLD token farm access (keeps new farm)', async () => {
      const m = await mkUser('fr', 'manager', [farmA]);
      const id = m.id || (await findId(m.u));
      const { token } = await loginAs(m.u, PW);
      expect((await raw(ctx, cfg.list, { token, farmId: farmA })).response.status, 'mgr list farmA before').toBe(200);
      const ed = await raw(ctx, cfg.edit(id), { method: 'PATCH', token: ctx.owner, body: { adminPassword: 'admin123', farmIds: [farmB] } });
      expect([200, 204], `farmIds edit -> ${ed.response.status} ${JSON.stringify(ed.data).slice(0, 120)}`).toContain(ed.response.status);
      const gone = await raw(ctx, cfg.list, { token, farmId: farmA });
      expect(gone.response.status, `OLD token farmA after removal (want 403, got ${gone.response.status})`).toBe(403);
      const kept = await raw(ctx, cfg.list, { token, farmId: farmB });
      expect(kept.response.status, `OLD token farmB after move (want 200, got ${kept.response.status})`).toBe(200);
    }, 60_000);

    it('deactivation kills the OLD token and fresh login (where the feature exists)', async () => {
      const m = await mkUser('da', 'manager', [farmA]);
      const id = m.id || (await findId(m.u));
      const { token } = await loginAs(m.u, PW);
      const ed = await raw(ctx, cfg.edit(id), { method: 'PATCH', token: ctx.owner, body: { adminPassword: 'admin123', active: false } });
      console.log(`${app} deactivate edit -> ${ed.response.status} ${JSON.stringify(ed.data).slice(0, 120)}`);
      if (ed.response.status >= 400) {
        console.log(`${app}: deactivation NOT supported via edit (status ${ed.response.status}) — recording as feature-absent`);
        expect(ed.response.status).toBeGreaterThanOrEqual(400);
        return;
      }
      const after = await raw(ctx, cfg.list, { token, farmId: farmA });
      expect(after.response.status, `deactivated OLD token list (want 401/403, got ${after.response.status})`).toBeGreaterThanOrEqual(401);
      expect(after.response.status).toBeLessThan(500);
      const relog = await loginAs(m.u, PW);
      expect(relog.status, `deactivated fresh login (want 401/403, got ${relog.status})`).toBeGreaterThanOrEqual(401);
      expect(relog.status).toBeLessThan(500);
    }, 60_000);

    it('bcrypt 72-byte: password differing only after byte 72 must NOT authenticate', async () => {
      const p72 = `${'A'.repeat(72)}X`;
      const m = await mkUser('b72', 'worker', [farmA], p72);
      console.log(`${app} create 73-byte-password user -> ${m.status}`);
      if (m.status >= 400) { expect(m.status, 'create rejected (policy)').toBeGreaterThanOrEqual(400); return; }
      const good = await loginAs(m.u, p72);
      expect(good.status, `correct 73-byte login (got ${good.status})`).toBe(200);
      const trunc = await loginAs(m.u, `${'A'.repeat(72)}Y`);
      expect(trunc.status, `byte-73-differing login (want 401, got ${trunc.status} — 200 means bcrypt 72-byte truncation)`).toBe(401);
    }, 60_000);

    it('1MB password does not hang or 500 the login/signup', async () => {
      const big = 'B'.repeat(1_000_000);
      const t0 = Date.now();
      const r = await raw(ctx, cfg.login, { method: 'POST', body: { username: 'admin', password: big } });
      const ms = Date.now() - t0;
      console.log(`${app} 1MB-password login -> ${r.response.status} in ${ms}ms`);
      expect(r.response.status).toBeLessThan(500);
      expect(ms).toBeLessThan(15_000);
    }, 60_000);

    it('login rate limiter cannot be reset by spoofing X-Forwarded-For', async () => {
      const attempt = async (xff?: string) => {
        const headers: Record<string, string> = { 'Content-Type': 'application/json' };
        if (xff) headers['X-Forwarded-For'] = xff;
        const path = app === 'agri' ? '/api/login' : '/api/auth/login';
        const res = await fetch(`${ctx.base}${path}`, { method: 'POST', headers, body: JSON.stringify({ username: `nosuch${S}`, password: 'WrongPass1!' }) });
        await res.text();
        return res.status;
      };
      const plain: number[] = [];
      for (let i = 0; i < 15; i++) plain.push(await attempt());
      const spoofed: number[] = [];
      for (let i = 0; i < 15; i++) spoofed.push(await attempt(`7.7.7.${i + 1}`));
      console.log(`${app} limiter plain: ${plain.join(',')}`);
      console.log(`${app} limiter xff-spoofed: ${spoofed.join(',')}`);
      const plainLimited = plain.includes(429);
      const spoofLimited = spoofed.includes(429);
      expect(plainLimited, 'limiter should engage on 15 rapid failures from one IP').toBe(true);
      expect(spoofLimited, 'limiter must still engage when XFF is spoofed (else trust-proxy XFF resets the bucket)').toBe(true);
    }, 120_000);

    it('forgot-password does not enumerate registered emails', async () => {
      const m = await mkUser('fp', 'worker', [farmA]);
      const hit = await raw(ctx, cfg.forgot, { method: 'POST', body: { email: `${m.u}@t.local` } });
      const miss = await raw(ctx, cfg.forgot, { method: 'POST', body: { email: `ghost${S}@t.local` } });
      console.log(`${app} forgot existing -> ${hit.response.status} ${JSON.stringify(hit.data).slice(0, 100)} | nonexistent -> ${miss.response.status} ${JSON.stringify(miss.data).slice(0, 100)}`);
      expect(miss.response.status, `nonexistent email status ${miss.response.status} vs existing ${hit.response.status}`).toBe(hit.response.status);
    }, 60_000);
  });
}

suite('dairy', 'dairy_farm/backend');
suite('agri', 'agri_farm/backend');
suite('flock', 'flock_farm/backend');

describe.sequential('ROUND 13 cross-app tokens (same JWT_SECRET, different user DBs)', () => {
  let dairy: Ctx; let agri: Ctx; let flock: Ctx;
  beforeAll(async () => {
    dairy = await startApp('dairy', 'dairy_farm/backend');
    agri = await startApp('agri', 'agri_farm/backend');
    flock = await startApp('flock', 'flock_farm/backend');
  }, 300_000);
  afterAll(async () => { await stopApp(dairy); await stopApp(agri); await stopApp(flock); }, 60_000);

  it('owner tokens from one app are rejected by the other two', async () => {
    const probes: Array<[string, Ctx, string]> = [
      ['dairy-token -> agri', agri, dairy.owner],
      ['dairy-token -> flock', flock, dairy.owner],
      ['agri-token -> dairy', dairy, agri.owner],
      ['agri-token -> flock', flock, agri.owner],
      ['flock-token -> dairy', dairy, flock.owner],
      ['flock-token -> agri', agri, flock.owner],
    ];
    for (const [tag, target, token] of probes) {
      const r = await raw(target, '/farms', { token });
      console.log(`${tag}: GET /farms -> ${r.response.status}`);
      expect(r.response.status, `${tag} (want 401/403, got ${r.response.status})`).toBeGreaterThanOrEqual(401);
      expect(r.response.status).toBeLessThan(500);
    }
  }, 120_000);
});
