// Authorization matrix: extract every route from server.js + routes/*.js, call each as
// anon / worker / managerA / managerB(other farm) / owner. Usage: node authz-matrix.mjs <app>
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const app = process.argv[2];
const cfg = {
  dairy: { dir: 'dairy_farm/backend', port: 18601, login: '/api/auth/login', loginKey: 'token' },
  agri: { dir: 'agri_farm/backend', port: 18602, login: '/api/login', loginKey: 'access_token' },
  flock: { dir: 'flock_farm/backend', port: 18603, login: '/api/auth/login', loginKey: 'token' },
}[app];
const root = process.cwd();
const base = `http://127.0.0.1:${cfg.port}`;

function extractRoutes() {
  const server = fs.readFileSync(path.join(cfg.dir, 'server.js'), 'utf8');
  const imports = {};
  for (const m of server.matchAll(/import\s+(\w+)(?:\s*,\s*\{[^}]*\})?\s+from\s+'\.\/routes\/([\w.-]+)'/g)) imports[m[1]] = m[2];
  const mounts = []; // [mountPath, file]
  for (const m of server.matchAll(/app\.use\('([^']+)',\s*(\w+)\)/g)) if (imports[m[2]]) mounts.push([m[1], imports[m[2]]]);
  const routes = [];
  const seen = new Set();
  const add = (method, p) => { const k = `${method} ${p}`; if (!seen.has(k) && !p.includes('*')) { seen.add(k); routes.push([method, p]); } };
  for (const m of server.matchAll(/app\.(get|post|put|patch|delete)\('([^']+)'/g)) add(m[1].toUpperCase(), m[2]);
  for (const [mount, file] of mounts) {
    const src = fs.readFileSync(path.join(cfg.dir, 'routes', file), 'utf8');
    for (const m of src.matchAll(/router\.(get|post|put|patch|delete)\('([^']+)'/g)) {
      const sub = m[2] === '/' ? '' : m[2];
      add(m[1].toUpperCase(), (mount + sub).replace(/\/{2,}/g, '/'));
    }
  }
  // Agri style: const apiRouters = [...] then app.use('/', r); app.use('/api', r)
  const arr = server.match(/const apiRouters = \[([\s\S]*?)\];/);
  if (arr) {
    for (const m of arr[1].matchAll(/(\w+)/g)) {
      const file = imports[m[1]];
      if (!file) continue;
      const src = fs.readFileSync(path.join(cfg.dir, 'routes', file), 'utf8');
      for (const r of src.matchAll(/router\.(get|post|put|patch|delete)\('([^']+)'/g)) {
        const sub = r[2] === '/' ? '' : r[2];
        add(r[1].toUpperCase(), ('/api' + sub).replace(/\/{2,}/g, '/'));
      }
    }
  }
  // Mounts like app.use('/api', xRoutes) where the route file carries full paths
  for (const m of server.matchAll(/app\.use\('\/api',\s*(\w+)\)/g)) {
    const file = imports[m[1]];
    if (!file) continue;
    const src = fs.readFileSync(path.join(cfg.dir, 'routes', file), 'utf8');
    for (const r of src.matchAll(/router\.(get|post|put|patch|delete)\('([^']+)'/g)) {
      const sub = r[2] === '/' ? '' : r[2];
      add(r[1].toUpperCase(), ('/api' + sub).replace(/\/{2,}/g, '/'));
    }
  }
  return routes;
}

const proc = spawn(process.execPath, ['server.js'], {
  cwd: cfg.dir,
  env: { ...process.env, PORT: String(cfg.port), MEMORY_MODE: '1', JWT_SECRET: '[SECURITY_DATA]', DISABLE_INTERNAL_SCHEDULER: '1', NODE_ENV: 'test' },
  stdio: 'ignore',
});
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let actorIp = 10;
async function call(method, p, { token, farmId, body } = {}) {
  const headers = { 'Content-Type': 'application/json', 'X-Forwarded-For': `10.9.9.${actorIp}` };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (farmId) headers['X-Farm-Id'] = farmId;
  try {
    const res = await fetch(base + p, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
    await res.text();
    return res.status;
  } catch { return 0; }
}
async function login(u, p) {
  const res = await fetch(base + cfg.login, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: u, password: p }) });
  const j = await res.json().catch(() => ({}));
  const tok = String(j[cfg.loginKey] || j.token || j.access_token || '');
  console.log(`SETUP login ${u} -> ${res.status} tokenLen=${tok.length}${tok ? '' : ' body=' + JSON.stringify(j).slice(0, 100)}`);
  return tok;
}

try {
  for (let i = 0; i < 50; i++) { try { const r = await fetch(`${base}/api/farms`); if (r.status) break; } catch { await sleep(400); } }
  // Wait until the seeded admin can actually log in (demo seeding finished),
  // otherwise users created during the seed window can be wiped by the seed.
  let owner = '';
  for (let i = 0; i < 60 && !owner; i++) { owner = await login('admin', 'admin123'); if (!owner) await sleep(500); }
  const worker = await login('worker', 'worker123');
  const farmsRes = await fetch(`${base}/api/farms`, { headers: { Authorization: `Bearer ${owner}` } }).then((r) => r.json());
  const farmA = String(farmsRes.farms?.[0]?.id || '');
  const farmBRes = await fetch(`${base}/api/farms`, { method: 'POST', headers: { Authorization: `Bearer ${owner}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ name: `Authz FarmB ${Date.now()}` }) }).then((r) => r.json());
  const farmB = String(farmBRes.id || farmBRes._id || '');
  const MP = ['Matrix', 'Test123!'].join('');
  async function mkManager(tag, farmId) {
    const u = `authz${tag}${Date.now().toString(36)}`;
    const usersPath = app === 'agri' ? '/api/signup' : '/api/auth/users';
    const su = await fetch(base + usersPath, { method: 'POST', headers: { Authorization: `Bearer ${owner}`, 'Content-Type': 'application/json', ...(app === 'flock' ? { 'X-Farm-Id': farmId } : {}) }, body: JSON.stringify({ username: u, password: MP, role: 'manager', email: `${u}@t.local`, farmIds: [farmId] }) });
    const tok = await login(u, MP);
    const sanity = tok ? await call('GET', app === 'agri' ? '/api/users/me' : '/api/auth/me', { token: tok, farmId }) : 0;
    console.log(`SETUP mkManager ${tag}: signup=${su.status} tokenLen=${tok.length} sanityMe=${sanity}`);
    return tok;
  }
  const mgrA = await mkManager('a', farmA);
  const mgrB = await mkManager('b', farmB);

  // A real resource id per app for :param substitution
  let sampleId = farmA;
  if (app === 'dairy') {
    const c = await fetch(`${base}/api/cows`, { method: 'POST', headers: { Authorization: `Bearer ${owner}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ name: 'Authz Cow', breed: 'Jersey', gender: 'female', status: 'active' }) }).then((r) => r.json()).catch(() => ({}));
    sampleId = String(c._id || c.id || farmA);
  }
  const routes = extractRoutes();
  const sub = (p) => p.replace(/:[A-Za-z]+/g, sampleId);
  console.log(`METHOD PATH | anon | worker | mgrA | mgrB-other | owner`);
  const open = [];
  const mismatches = [];
  for (const [method, p] of routes) {
    const url = sub(p);
    const body = method === 'GET' || method === 'DELETE' ? undefined : {};
    actorIp = 11; const anon = await call(method, url, { body });
    actorIp = 12; const wk = await call(method, url, { token: worker, farmId: farmA, body });
    actorIp = 13; const ma = await call(method, url, { token: mgrA, farmId: farmA, body });
    actorIp = 14; const mb = await call(method, url, { token: mgrB, farmId: farmA, body });
    actorIp = 15; const ow = await call(method, url, { token: owner, farmId: farmA, body });
    console.log(`${method} ${p} | ${anon} | ${wk} | ${ma} | ${mb} | ${ow}`);
    if (![401, 403, 404, 405].includes(anon) && anon !== 0) open.push(`${method} ${p} → anon ${anon}`);
    if (![401, 403, 404].includes(mb) && mb < 400 && ![401, 403].includes(ma)) mismatches.push(`${method} ${p} → mgrB ${mb}`);
  }
  console.log(`\nTOTAL ROUTES: ${routes.length}`);
  console.log(`OPEN-WITHOUT-LOGIN (anon not 401/403/404): ${open.length}`);
  for (const o of open) console.log('  OPEN:', o);
} finally {
  proc.kill('SIGTERM');
}
