"""Load smoke (Deep R2 Part 10): login once, then read-heavy farm traffic.
Target list route is chosen by LOCUST_LIST_ROUTE env (per app).
MEMORY_MODE numbers = app overhead smoke, NOT production Mongo capacity."""
import os
from locust import HttpUser, between, task

LIST_ROUTE = os.environ.get("LOCUST_LIST_ROUTE", "/api/cows")
LOGIN_ROUTE = os.environ.get("LOCUST_LOGIN_ROUTE", "/api/auth/login")


class FarmUser(HttpUser):
    wait_time = between(0.1, 0.5)

    def on_start(self):
        if LOGIN_ROUTE.endswith("/api/login"):  # agri form login
            r = self.client.post(LOGIN_ROUTE, data={"username": "admin", "password": "admin123"})
            key = "access_token"
        else:
            r = self.client.post(LOGIN_ROUTE, json={"username": "admin", "password": "admin123"})
            key = "token"
        try:
            self.token = r.json().get(key) or r.json().get("token") or ""
        except Exception:
            self.token = ""
        self.headers = {"Authorization": f"Bearer {self.token}"}

    @task(5)
    def list_main(self):
        self.client.get(LIST_ROUTE, headers=self.headers, name="GET list")

    @task(2)
    def farms(self):
        self.client.get("/api/farms", headers=self.headers, name="GET farms")

    @task(1)
    def list_paged(self):
        self.client.get(f"{LIST_ROUTE}?limit=20&page=1", headers=self.headers, name="GET list paged")
