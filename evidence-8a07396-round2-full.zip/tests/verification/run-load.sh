#!/bin/bash
# Part 10 load smoke: 10/50/200 users x 3 apps, 25s each, memory mode.
# Usage: bash tests/verification/run-load.sh
set -u
cd "$(dirname "$0")/../.."
mkdir -p results/load
run_app() {
  local app="$1" dir="$2" port="$3" list="$4" login="$5"
  PORT=$port MEMORY_MODE=1 JWT_SECRET=[SECURITY_DATA] DISABLE_INTERNAL_SCHEDULER=1 NODE_ENV=test \
    node "$dir/server.js" > "results/load/server-$app.log" 2>&1 &
  local srv=$!
  for i in $(seq 1 40); do
    code=$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1:$port/api/farms" || true)
    [ "$code" = "401" ] || [ "$code" = "200" ] && break
    sleep 0.5
  done
  sleep 2
  for users in 10 50 200; do
    echo "== $app @ $users users"
    LOCUST_LIST_ROUTE="$list" LOCUST_LOGIN_ROUTE="$login" \
      locust -f tests/verification/load-locust.py --headless \
        -u "$users" -r 20 -t 25s --host "http://127.0.0.1:$port" \
        --csv "results/load/$app-$users" --only-summary
  done
  kill $srv 2>/dev/null
  wait $srv 2>/dev/null
}
run_app dairy dairy_farm/backend 18801 /api/cows /api/auth/login
run_app agri agri_farm/backend 18802 /api/crops /api/login
run_app flock flock_farm/backend 18803 /api/batches /api/auth/login
echo "LOAD DONE"
