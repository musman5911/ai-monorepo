/** Unit tests for the shared farm/role guard core (dairy copy of muf-farms.mjs).
 *  These double as the mutation-testing baseline (Deep R2 Part 9). */
import { describe, expect, it } from 'vitest';
// @ts-ignore - plain ESM module without types
import { mufNormalizeRole, mufIsOwner, mufIsFullRole, mufLegacyRole, mufResolveFarmAccess, mufScopeFilter, mufStripFarmId } from '../../dairy_farm/backend/muf-farms.mjs';

const F = (id: string, archived = false, createdAt = '2024-01-01') => ({ _id: id, archived, createdAt });
const farms = [F('farmA', false, '2024-01-01'), F('farmB', false, '2024-01-02'), F('farmOld', true, '2023-01-01')];

describe('mufNormalizeRole', () => {
  it('maps owner/admin to owner, manager stays, everything else is worker', () => {
    expect(mufNormalizeRole('owner')).toBe('owner');
    expect(mufNormalizeRole('admin')).toBe('owner');
    expect(mufNormalizeRole('manager')).toBe('manager');
    expect(mufNormalizeRole('worker')).toBe('worker');
    expect(mufNormalizeRole(undefined)).toBe('worker');
    expect(mufNormalizeRole(null)).toBe('worker');
    expect(mufNormalizeRole('superadmin')).toBe('worker');
    expect(mufNormalizeRole('')).toBe('worker');
    expect(mufNormalizeRole('ADMIN')).toBe('worker');
  });
  it('role predicates', () => {
    expect(mufIsOwner('admin')).toBe(true);
    expect(mufIsOwner('manager')).toBe(false);
    expect(mufIsFullRole('manager')).toBe(true);
    expect(mufIsFullRole('worker')).toBe(false);
    expect(mufLegacyRole('owner')).toBe('admin');
    expect(mufLegacyRole('manager')).toBe('admin');
    expect(mufLegacyRole('worker')).toBe('worker');
  });
});

describe('mufResolveFarmAccess', () => {
  it('no farms at all -> 503 MIGRATION_REQUIRED', () => {
    const r = mufResolveFarmAccess({ user: { role: 'owner', farmIds: [] }, farms: [], requested: '' });
    expect(r.ok).toBe(false);
    expect(r.status).toBe(503);
    expect(r.code).toBe('MIGRATION_REQUIRED');
  });
  it('worker assigned nothing -> 403 NO_FARM_ACCESS', () => {
    const r = mufResolveFarmAccess({ user: { role: 'worker', farmIds: [] }, farms, requested: '' });
    expect(r.ok).toBe(false);
    expect(r.status).toBe(403);
    expect(r.code).toBe('NO_FARM_ACCESS');
  });
  it('worker requesting an unassigned farm -> 403 FARM_FORBIDDEN', () => {
    const r = mufResolveFarmAccess({ user: { role: 'worker', farmIds: ['farmA'] }, farms, requested: 'farmB' });
    expect(r.ok).toBe(false);
    expect(r.code).toBe('FARM_FORBIDDEN');
  });
  it('worker requesting assigned farm -> single mode that farm', () => {
    const r = mufResolveFarmAccess({ user: { role: 'worker', farmIds: ['farmA'] }, farms, requested: 'farmA' });
    expect(r.ok).toBe(true);
    expect(r.ctx.mode).toBe('single');
    expect(r.ctx.farmId).toBe('farmA');
    expect(r.ctx.farmIds).toEqual(['farmA']);
  });
  it('worker all-mode contains only assigned active farms', () => {
    const r = mufResolveFarmAccess({ user: { role: 'manager', farmIds: ['farmA', 'farmOld'] }, farms, requested: 'all' });
    expect(r.ok).toBe(true);
    expect(r.ctx.mode).toBe('all');
    expect(r.ctx.farmIds).toEqual(['farmA']);
  });
  it('worker default picks first assigned active farm', () => {
    const r = mufResolveFarmAccess({ user: { role: 'worker', farmIds: ['farmB', 'farmA'] }, farms, requested: '' });
    expect(r.ok).toBe(true);
    expect(r.ctx.farmId).toBe('farmA');
  });
  it('owner sees every farm incl. archived in all-mode fallback and any single farm', () => {
    const all = mufResolveFarmAccess({ user: { role: 'owner', farmIds: [] }, farms, requested: 'all' });
    expect(all.ok).toBe(true);
    expect(all.ctx.farmIds).toEqual(['farmA', 'farmB']);
    const single = mufResolveFarmAccess({ user: { role: 'admin', farmIds: [] }, farms, requested: 'farmOld' });
    expect(single.ok).toBe(true);
    expect(single.ctx.farmId).toBe('farmOld');
  });
  it('anonymous-shaped user is treated as unassigned worker', () => {
    const r = mufResolveFarmAccess({ user: undefined, farms, requested: 'farmA' });
    expect(r.ok).toBe(false);
    expect(r.status).toBe(403);
  });
});

describe('mufScopeFilter', () => {
  it('single mode pins farmId and overrides client filter via $and', () => {
    const ctx: any = { mode: 'single', farmId: 'farmA', farmIds: ['farmA'] };
    expect(mufScopeFilter({ status: 'active' }, ctx)).toEqual({ status: 'active', farmId: 'farmA' });
    const overridden = mufScopeFilter({ farmId: 'farmB' }, ctx);
    expect(overridden).toEqual({ $and: [{ farmId: 'farmB' }, { farmId: 'farmA' }] });
  });
  it('all mode scopes to the allowed id set', () => {
    const ctx: any = { mode: 'all', farmId: null, farmIds: ['farmA', 'farmB'] };
    expect(mufScopeFilter({}, ctx)).toEqual({ farmId: { $in: ['farmA', 'farmB'] } });
  });
});

describe('mufStripFarmId', () => {
  it('removes farmId at top level and inside update operators', () => {
    expect(mufStripFarmId({ farmId: 'farmB', name: 'x' })).toEqual({ name: 'x' });
    expect(mufStripFarmId({ $set: { farmId: 'farmB', name: 'y' } })).toEqual({ $set: { name: 'y' } });
    expect(mufStripFarmId({ $inc: { farmId: 1, n: 2 } })).toEqual({ $inc: { n: 2 } });
  });
  it('passes through non-objects untouched', () => {
    expect(mufStripFarmId(null)).toBe(null);
    expect(mufStripFarmId('str')).toBe('str');
    expect(mufStripFarmId([1, 2])).toEqual([1, 2]);
  });
});
