# Run-it-yourself: everything the sandbox could NOT execute (Deep Round 2)

Sandbox limits that forced these out: no Docker, no `mongod`, no root apt, no
Java, and the network allowlist blocks the Playwright browser CDN,
api.telegram.org, Cloudinary, and the semgrep registry. Everything below is an
exact command sequence for a normal dev machine.

## 0. Setup

```bash
git clone https://github.com/musman5911/ai-monorepo   # or your fork URL
cd ai-monorepo                                        # verify-clone layout works too
git rev-parse HEAD                                    # expect 8a073965763a6a4a6cc2bae0a341508cac91b178 (or newer)
npm install
for d in dairy_farm/backend agri_farm/backend flock_farm/backend dairy_farm/client agri_farm/frontend flock_farm/client; do (cd $d && npm install); done
npm i -D vitest@3 fast-check @stryker-mutator/core @stryker-mutator/vitest-runner
```

## 1. Real MongoDB (the A1/A2/A6/G1/G2/I1/I2/K1/ROLE-F1 real-DB variants + Parts 2 & 6)

The suites spawn the backends themselves, but `tests/api-matrix/harness.ts`
pins `MEMORY_MODE: '1'`. To run the same suites against real Mongo:

```bash
docker run -d --name muf-mongo -p 27017:27017 mongo:7
# one-line change so spawned backends use Mongo instead of the in-memory store:
sed -i "s/MEMORY_MODE: '1',/MEMORY_MODE: process.env.MEMORY_MODE ?? '1',/" tests/api-matrix/harness.ts
export MEMORY_MODE=0 MONGO_URI=mongodb://127.0.0.1:27017 JWT_SECRET=[SECURITY_DATA] DISABLE_INTERNAL_SCHEDULER=1 NODE_ENV=test
npx vitest run tests/api-matrix tests/api-deep
```

Then restore the harness line (`git checkout tests/api-matrix/harness.ts`) —
the committed harness must keep `MEMORY_MODE: '1'` for CI determinism.
Highest-value real-DB checks: A1/A2 (logout/password-change revocation —
token-validation may differ with real user docs), A6/G1/G2/I1/I2 (backup
validate/restore atomicity — memory mode skips Mongo transactions; Dairy
`routes/backup.js` only uses a transaction when a replica set is connected,
so also try a single-node replica set: add `--replSet rs0` + `rs.initiate()`),
ROLE-F1 (Flock `farmIds` ignored on user create), K1 already verified in
memory mode (Part 8 of the final report).

Cloudinary (Part 2 cloud mode): create a free Cloudinary cloud, then

```bash
export CLOUDINARY_CLOUD_NAME=... CLOUDINARY_API_KEY=... CLOUDINARY_API_SECRET=...
npx vitest run tests/api-deep/round12-photos-cloudinary.test.ts tests/api-deep/round12-photos-flock.test.ts
unset CLOUDINARY_CLOUD_NAME CLOUDINARY_API_KEY CLOUDINARY_API_SECRET
```

The suite's fake-secret test already proves a misconfigured cloud fails
without leaking the secret; with real credentials the same file exercises the
cloudinary branch of `muf-storage` (upload → proxied GET → delete → orphan
cleanup) that the sandbox could not reach (cloudinary.com is not allowlisted).

## 2. Accessibility (M1–M4) + Playwright main flows

```bash
npx playwright install chromium        # browser CDN is blocked in the sandbox
# build + serve one frontend, then run the axe spec per app:
cd dairy_farm/client && npm run build && cd ../..
npx playwright test e2e/toolchain-visual-a11y.spec.ts
```

`playwright.config.ts` + `e2e/toolchain-visual-a11y.spec.ts` are in this
evidence bundle. No LLM/API key is needed to *run* Playwright tests — keys are
only needed for the optional planner/healer *agents*.

## 3. Dedicated secret scanners (history was grep-scanned in Part 9)

```bash
gitleaks git --redact --report-format json --report-path gitleaks.json .
# or
trufflehog git file://. --json > trufflehog.json
```

## 4. semgrep official packs (local-rules run already done in Part 9)

```bash
pip install semgrep
semgrep --config p/javascript --config p/security-audit dairy_farm/backend agri_farm/backend flock_farm/backend
```

## 5. k6 alternative to the Locust smoke (Part 10)

```bash
# https://k6.io/docs/get-started/installation/
k6 run --vus 50 --duration 30s your-load-script.js   # point it at /api/cows etc.
```

Locust equivalent used in the sandbox (already run, results in `results/load/`):

```bash
bash tests/verification/run-load.sh
```
