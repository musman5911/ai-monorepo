import { defineConfig } from '@playwright/test';
import { existsSync } from 'node:fs';

/**
 * Browser E2E + visual-regression config for the three farm websites.
 *
 * The sandbox cannot download Playwright's stock browsers (CDN blocked),
 * so we drive the Chromium build bundled in @sparticuz/chromium.
 * `node e2e/ensure-browser.cjs` extracts it to /tmp/chromium first
 * (npm run test:e2e does this automatically). NSS libs built locally
 * live in /tmp/nss-libs when present.
 *
 * Requires the live stack: backends :3000/:3001/:8000 and Vite
 * frontends :5000 (Dairy) / :5173 (Flock) / :3030 (Agri).
 */
const sparticuzExe = '/tmp/chromium';
const nssLibs = '/tmp/nss-libs';

export default defineConfig({
  testDir: './e2e',
  timeout: 90_000,
  expect: { timeout: 15_000 },
  workers: 1, // single-process sandbox Chromium + shared demo data
  retries: 1,
  reporter: [['list']],
  use: {
    viewport: { width: 1280, height: 800 },
    locale: 'en-US',
    screenshot: 'only-on-failure',
    launchOptions: {
      ...(existsSync(sparticuzExe) ? { executablePath: sparticuzExe } : {}),
      args: ['--no-sandbox', '--disable-dev-shm-usage', '--enable-unsafe-swiftshader', '--in-process-gpu', '--use-gl=angle', '--use-angle=swiftshader'],
      env: {
        ...process.env,
        ...(existsSync(nssLibs) ? { LD_LIBRARY_PATH: nssLibs } : {}),
      },
    },
  },
  projects: [
    { name: 'dairy', use: { baseURL: process.env.E2E_DAIRY_URL || 'http://localhost:5000' } },
    { name: 'flock', use: { baseURL: process.env.E2E_FLOCK_URL || 'http://localhost:5173' } },
    { name: 'agri', use: { baseURL: process.env.E2E_AGRI_URL || 'http://localhost:3030' } },
  ],
});
