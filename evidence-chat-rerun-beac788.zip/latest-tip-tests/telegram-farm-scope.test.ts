import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { mufGetFarmContext, mufRunWithFarmContext } from '../dairy_farm/backend/muf-farms.mjs';
import {
  mufTelegramFarmContext,
  mufTelegramFarmId,
  mufRunTelegramFarm,
} from '../dairy_farm/backend/muf-telegram-farms.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const apps = ['dairy_farm', 'flock_farm', 'agri_farm'];

function source(app: string, relativePath: string) {
  return fs.readFileSync(path.join(root, app, relativePath), 'utf8').replace(/\r\n/g, '\n');
}

describe('Phase 7: Telegram farm isolation', () => {
  it('creates only a single-farm context and refuses missing farm ids', () => {
    expect(mufTelegramFarmContext('farm-b')).toEqual({
      mode: 'single', farmId: 'farm-b', farmIds: ['farm-b'], userId: 'telegram',
    });
    expect(mufTelegramFarmContext('')).toBeNull();
    expect(mufTelegramFarmContext(undefined)).toBeNull();
  });

  it('fails closed for legacy links without a farm assignment', () => {
    expect(mufTelegramFarmId({ userId: 'user-1' })).toBe('');
    expect(mufTelegramFarmId({ farmId: 'farm-b', userId: 'user-1' })).toBe('farm-b');
  });

  it('runs webhook work in the linked farm context, never the default farm', async () => {
    const result = await mufRunTelegramFarm('farm-b', mufRunWithFarmContext, async () => {
      expect(mufGetFarmContext()).toMatchObject({ mode: 'single', farmId: 'farm-b', farmIds: ['farm-b'] });
      return 42;
    });
    expect(result).toBe(42);
    await expect(mufRunTelegramFarm('', mufRunWithFarmContext, async () => 'unsafe')).resolves.toBeNull();
    expect(mufGetFarmContext()).toBeNull();
  });

  it('simulates Farm B writes and proves Farm A summaries exclude them', async () => {
    const records: Array<{ farmId: string; amount: number }> = [];
    await mufRunTelegramFarm('farm-b', mufRunWithFarmContext, async () => {
      const context = mufGetFarmContext();
      if (context?.farmId) records.push({ farmId: context.farmId, amount: 250 });
    });
    await mufRunTelegramFarm('', mufRunWithFarmContext, async () => {
      records.push({ farmId: 'default-farm', amount: 999 });
    });
    const farmASummary = records.filter((record) => record.farmId === 'farm-a');
    expect(records).toEqual([{ farmId: 'farm-b', amount: 250 }]);
    expect(farmASummary).toEqual([]);
  });

  it('keeps the farm-context helper identical across all three apps', () => {
    const contents = apps.map((app) => source(app, 'backend/muf-telegram-farms.mjs'));
    expect(contents[1]).toBe(contents[0]);
    expect(contents[2]).toBe(contents[0]);
  });

  it.each(apps)('%s stores the farm on Telegram links and scopes webhook execution', (app) => {
    const route = source(app, 'backend/routes/telegram.js');
    expect(route).toContain('farmId:');
    expect(route).toContain('mufTelegramFarmId');
    expect(route).toContain('mufRunTelegramFarm');
    expect(route).toContain('if (!link)');
    expect(route).toContain('notLinked');
    expect(route).toContain('Select one farm before creating a Telegram link code');
    expect(route).toContain('no linked admin chat');
  });

  it('consumes Telegram link codes atomically and updates links by chat key', () => {
    const agri = source('agri_farm', 'backend/routes/telegram.js');
    const dairy = source('dairy_farm', 'backend/routes/telegram.js');
    const flock = source('flock_farm', 'backend/routes/telegram.js');
    expect(agri).toContain('async function tgConsumeCode(code, nowMs)');
    expect(agri).toContain('await tgSetEntry(\'links\', chatId');
    expect(dairy).toContain('async function consumeLinkCode(code, nowMs)');
    expect(dairy).toContain('await setMetaEntry(LINKS_KEY, chatId');
    expect(flock).toContain('async function consumeStoreCode(code, nowMs, farmId)');
    expect(flock).toContain('setStoreEntry(LINKS_KEY, chatId, linkRecord, targetFarmId)');
    for (const route of [agri, dairy, flock]) {
      expect(route).toMatch(/\[\`value\.\$\{code\}\.expires\`\]: \{ \$gte: nowMs \}/);
    }
  });

  it('uses the deterministic attendance identity for Agri Telegram submissions', () => {
    const route = source('agri_farm', 'backend/routes/telegram.js');
    expect(route).toContain("import { mufLaborAttendanceId } from '../utils/attendance-id.mjs'");
    expect(route).toContain('_id: mufLaborAttendanceId(link.laborerId, date)');
    expect(route).toContain('if (error?.code !== 11000) throw error');
    expect(route).toContain('const raced = await Attendance.findOne({ laborer_id: link.laborerId, date })');
  });

  it('scopes Dairy manual email summaries to the selected or assigned farms', () => {
    const route = source('dairy_farm', 'backend/routes/email.js');
    expect(route).toContain('mufRunWithFarmContext');
    expect(route).toContain('allowedFarmIds');
    expect(route).toContain('Farm context is required');
    expect(route).toContain('farm.name || \'Dairy Farm\'');
  });

  it.each(apps)('%s generates scheduled summaries separately per farm', (app) => {
    const route = source(app, 'backend/routes/telegram.js');
    expect(route).toMatch(/Farm\.find\(\{ archived: \{ \$ne: true \} \}\)/);
    expect(route).toContain('mufTelegramFarmId(link)');
    expect(route).toContain('lastPushDate');
    expect(route).toContain('allowedFarmIds');
  });
});
