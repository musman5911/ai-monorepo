# Progress

What is done, what remains and what is next for the scale-up project. Keep this file up to date after every change.
Last updated: 2026-10-23 (Phase 0 applied and verified by the owner; Phase 1 steps 1A and 1B-1 delivered; Flock 1B-2 waiting for the owner's layout decision; the rest not started).

**Honesty rule:** a row says "verified" only for checks that actually ran, and says where they ran. Source checks and tests are automated evidence, not visual sign-off. Owner testing in a browser is recorded separately.

The system is described in [FARMS_AND_ROLES.md](FARMS_AND_ROLES.md); the phases are in [ROADMAP.md](ROADMAP.md).

## At a glance

| Phase | State |
|---|---|
| 0. Docs reset and repository cleanup | Done. Applied by the owner, pushed to the `muf-monorepo` branch, owner's checks and builds all passed |
| 1. Farms and roles (MUF) | In progress. 1A done (shared core + Dairy backend); 1B-1 done (Agri backend); 1B-2 Flock backend waiting for a layout decision; 1C screens and 1D wrap-up not started |
| 2. Flock restructure and Home Birds | Not started |
| 3. Bulk entry, scroll loading, server totals | Not started |
| 4. Dairy breeding; Agri fields and seasons | Not started |
| 5. Photo storage and Cloudinary | Not started. Prerequisite done: free Cloudinary account created 2026-10-22 |
| 6. Super Admin upgrade | Not started. The tab and farm-summary endpoints already exist |
| 7. MU Farms shop | Not started |
| Carried over: A3 dependency security, G3 live deployment check, visual review, visual regression rebuild | Open (see below) |

## Decisions (owner, 2026-10-22)

- **Roles:** exactly three: Owner (super admin: all farms, manages farms and admins, sees the Super Admin tab), Manager (full control inside assigned farms; not an admin; no Super Admin), Worker (data entry in assigned farms). Existing admins become Owner.
- **Farms:** per project (poultry farms only in Flock, dairy farms only in Dairy, land only in Agri). Only the owner adds, renames, archives or deletes farms. Delete rules in `FARMS_AND_ROLES.md` section 3 were approved.
- **Shared systems** go into the MUF layer with organized files so later changes are easy.
- **Super Admin** is a role plus the existing tab, not a new domain.
- **Photos:** adapter first, free external store later. Cloudinary Free plan chosen; account created 2026-10-22 (plan shows 0 of 25 credits used). Not connected to any app. Credentials stay in environment secrets only.
- **Flock:** Batches become the main project; the old bird system becomes a much smaller Home Birds tab (eggs, expenses, feed focus; no exports). Claude may remove extras in Home Birds without asking each time; the list is recorded below when it happens.
- **Everywhere else:** ask before removing anything.
- **Rules lifted:** "zero backend changes" no longer applies to this project. Each phase still needs the owner's approval of its plan.
- **Backups:** the owner already took a database backup on 2026-10-22. Take a fresh one before each migration.
- **Hosting:** the owner uses the free MongoDB tier and Replit, so size and quota limits matter (see `DEPLOYMENT.md`).
- **MU Farms shop:** later. There is no budget for a new domain; where it lives is decided in Phase 7.

## Waiting for the owner

- **Flock data layout (blocks step 1B-2).** Claude proposed one stored list per farm and key. The owner answered "Flock layout - no we will do …" and the message was cut off, so the alternative is unknown. No Flock code has been written.

## Phase 1 step 1B-1: Agri backend (built 2026-10-23)

Design record: [PHASE1_PLAN.md](PHASE1_PLAN.md). Backend only; no screens changed.

- **Agri backend:** `Farm` model; `farmId` on the 14 farm-owned collections; users get `farmIds`; roles owner, manager, worker; server-side scoping from the `X-Farm-Id` header (no header = default farm, `all` = read-only); `/api/farms` (owner only to change); owner-only backup and restore covering all farms; `npm run migrate:farms:dry` and `npm run migrate:farms` in `agri_farm/backend`.
- **Changed behavior to know about:** managers can no longer download or restore backups (owners only, as decided); the first sign-up is the owner; four PUT routes (crops, finance, tasks, suppliers) now go through `replaceFarmRecord` because `replaceOne` is refused inside a farm-scoped request.
- **Checks added or extended:** `tests/muf-farms-agri.test.ts` (10 tests); `tools/check-farm-scope.js` now works per project and has `agri` (and, for both Agri and Dairy: same-farm update, and backup then restore keeps every record in its farm).
- **Small fix in Dairy:** `X-Farm-Id` added to the allowed CORS headers.

**Not done or not verified (Agri):**

- The migration has only run against demo (memory) data, never on a real MongoDB copy. No real database was available here, so no real read or write through MongoDB was exercised for Agri.
- No screens (step 1C). The old Agri screens keep working through the default farm, but errors from the farm layer use `{ error, code }` while Agri screens read `{ detail }`, so a farm error shows only a generic message until 1C.
- Telegram bot records, the daily summary and `/api/farm-summary` run unscoped over the whole project; per-farm Telegram links and summaries come later.
- The Agri frontend was not rebuilt (no frontend file changed).

## Phase 1 step 1A: what was built

Design record: [PHASE1_PLAN.md](PHASE1_PLAN.md). Backend only; no screens changed.

- **Shared core** `backend/muf-farms.mjs`, a byte-identical twin in all three backends (guarded by `check-muf-sync`). Only Dairy uses it so far.
- **Dairy backend:**
  - `Farm` model; `farmId` on the 15 farm-owned collections; users get `farmIds`; roles owner, manager, worker.
  - Server-side scoping of every farm-owned query and create, driven by the `X-Farm-Id` header (no header = default farm, `all` = read-only).
  - `/api/farms`: list, create, rename, archive, restore, delete (owner only; deleting a farm with data needs the name typed plus move-or-delete).
  - Users: owners create any role; managers create only workers in their own farms.
  - Backup and restore: owner only, all farms, farms included in the file, untagged records tagged after a restore.
  - Rate and daily log no longer share ids between farms.
  - `npm run migrate:farms:dry` and `npm run migrate:farms` in `dairy_farm/backend`.
- **Checks added:** `tests/muf-farms.test.ts` (13 tests) and `tools/check-farm-scope.js` / `npm run check-farms` (42 checks over real HTTP against the Dairy backend in memory mode).
- **Old screens still work:** the API returns the old `role` (`admin` or `worker`) next to the real `farmRole`.

**Not done or not verified:**

- Agri and Flock backends were not wired in 1A. Agri was done in step 1B-1; Flock (step 1B-2) still needs a data layout decision (see the design record).
- No screens: no farm switcher, no Farms & Access popup (step 1C).
- The migration has only run against demo (memory) data. It has not been run on a real MongoDB copy.
- The model wrapper was checked against real MongoDB query objects, but no real database was available here, so no real write or read through MongoDB was exercised.
- Telegram bot records and the daily summary email run unscoped and use the default farm; per-farm Telegram links are not built.

## Phase 0: what changed

**Removed**

- `docs/PROGRESS.md`, `docs/ROADMAP.md`, `docs/DEPLOYMENT.md` (replaced by new versions) and `docs/AUDIT.md`.
- Screenshot regression: the `e2e/` folder, `playwright.config.mjs`, `tests/visual-regression-ci-policy.test.ts`, the `visual-candidate` job in `.github/workflows/muf-frontend-checks.yml`, the three `test:visual*` scripts, and the `@playwright/test` dev dependency. The 40 candidate screenshots were never approved, and every screen will change, so this is rebuilt after Phase 2.
- Four Playwright-specific tests in `tests/smoke.test.ts`.
- The Playwright lines in `.gitignore`.
- `package-lock.json` was regenerated with npm. It lost exactly three packages (`@playwright/test`, `playwright`, `playwright-core`) and gained none.

**Added or updated**

- New: `docs/PROGRESS.md`, `docs/ROADMAP.md`, `docs/FARMS_AND_ROLES.md`, `docs/DEPLOYMENT.md` (old environment and Replit content kept, rollout and free-tier sections added).
- `RULES.md`: section 1 rewritten for the scale-up project; notes on new shared systems, dependencies and migrations.
- `docs/README.md`, `docs/muf-rules.md`, `docs/MUF_OVERVIEW.md` and the three project `README.md` files: references to deleted documents fixed.

**Kept on purpose:** every image (all are real logos, icons and crop cards used by the code), `demo-data.js` in each backend (demo mode needs it), all other tests and docs.

**Home Birds removals:** none yet. The Phase 2 plan will list them.

## Verification (2026-10-22, Linux sandbox, uploaded `main` snapshot plus Phase 0 edits)

| Check | Result |
|---|---|
| `npm ci` (root) and `npm ci` in `dairy_farm/client` | Succeeded |
| `npm test` | 61 of 61 pass (6 files) |
| `node tools/check-muf-sync.js` | All checks passed |
| `node tools/check-ui-safety.js` | All checks passed |
| `node tools/check-muf-workbench.js` | 23 of 23 pass |
| `node --check tools/audit-muf-design-system.mjs` and the audit itself | Ran. Agri 36, Dairy 38, Flock 70 popups; 0 missing sizes |
| Dairy frontend production build (`npm run build` in `dairy_farm/client`) | Built successfully |
| Not run | The workbench runtime check, the GitHub Actions workflow after the edit, any live Replit, MongoDB, SMTP or Telegram test |

Owner's machine, 2026-10-22, Phase 0 branch: `npm test` 61 of 61, sync, UI safety and workbench checks passed, and `tools\build-all.bat` built Dairy, Flock and Agri.

### Phase 1 step 1B-1 (2026-10-23, Linux sandbox)

| Check | Result |
|---|---|
| `npm test` | 84 of 84 pass (8 files), including 10 new Agri tests |
| `node tools/check-farm-scope.js agri` | All pass (49 checks) |
| `node tools/check-farm-scope.js dairy` | All pass (49 checks; seven new generic checks added) |
| `check-muf-sync`, `check-ui-safety`, `check-workbench` | All pass |
| Frontend builds | Not re-run: no frontend file changed |
| Not run | A real MongoDB migration, the screens, the Flock backend |

### Phase 1 step 1A (2026-10-22, Linux sandbox)

| Check | Result |
|---|---|
| `npm test` | 74 of 74 pass (7 files), including the new 13 farm tests |
| `node tools/check-farm-scope.js dairy` | 42 of 42 pass |
| `check-muf-sync`, `check-ui-safety`, `check-workbench` | All pass |
| Frontend builds | Not re-run: no frontend file changed in 1A |
| Not run | A real MongoDB migration, the screens, Agri and Flock backends |

Phase 0 changed no application code, but the Agri and Flock builds and the edited workflow should still be run on the owner's side once the zip is applied.

## Carried over from the old system

### A3: dependency audit (2026-10-20, `npm audit`; nothing remediated yet)

| Project | All findings | Shipped to users |
|---|---|---|
| Root (test tools) | 4: 2 critical, 1 high, 1 moderate | 0 |
| Dairy frontend | 4: 2 high, 1 moderate, 1 low | 1 low (`dompurify`) |
| Flock frontend | 2: 1 high, 1 low | 1 low (`dompurify`) |
| Agri frontend | 4: 3 high, 1 low | 2: `axios` high (direct), `dompurify` low |

Fixes: `axios` 1.20.0 (Agri), `dompurify` 3.4.17 (all three), `nanoid` 3.3.20 (Agri build tool), `source-map-js` 1.2.2 (build tools): all non-breaking. Vitest 5 and Vite 8 are major upgrades; do them separately. Never run a blanket `npm audit fix`: it added 50 to 68 unrelated optional packages to each lockfile. Update targeted packages and review each lockfile diff. This audit predates the Playwright removal, so the root numbers may now differ; re-run before fixing.

### G3: live deployment

The Replit configuration was improved in source on 2026-10-20 (Node.js 24 in all three `.replit` files, lockfile-driven build and run commands, canonical environment names, consistent `JWT_EXPIRES_IN`). It has not been exercised on the owner's three Replit projects. External scheduler setup, database reachability, SMTP, Telegram webhooks and publishing quota still need the live checks in `DEPLOYMENT.md`.

### Owner visual review still pending

Dairy popup field styling (B1), micro-typography (B3) and the Urdu popup labels (C5), at 360, 390, 768/1024 and 1440 px in light, dark and Urdu. The Urdu fallback sweep covered named modules only.

### Visual regression (A1)

Removed in Phase 0. The old 40-image candidate set was never approved and has expired. Rebuild after Phase 2 settles the screens; authenticated screens need a safe test account, never real credentials or fake farm data.

### Housekeeping

- Flock `ZakatSection` (in `MonthlySummary.tsx`) is defined and unused (roadmap D1).
- `tools\send-to-projects.bat` normalizes line endings and prints the paths it changes. If it has not been run since the 2026-10-18 reorganization, run it only when ready.
- The earlier note that old remote branches still existed was reported out of date by the maintainers; it could not be checked from the snapshot.

## Next

1. Owner applies the 1B-1 zip and runs the commands in `docs/README.md` (including `npm run check-farms`; run `npm ci` in `agri_farm\backend` first).
2. Owner decides Flock's data store layout, then step 1B-2 wires the Flock backend.
3. Step 1C: farm switcher and Farms & Access popup in all three apps.

## How to update this file

After each change: move the phase to done with the date, record real check results with where they ran, list anything unverified, add removals to the Home Birds list when they happen, and keep `ROADMAP.md` in step.
