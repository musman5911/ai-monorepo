import { spawn, execSync } from 'node:child_process';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd(); const outDir=path.join(root,'results/round3'); const head='2ddf5bccd555b779ee7446c038a30fc5bcd1bcb0';
const out=[]; const log=(s='')=>{out.push(String(s)); console.log(s)};
log(`git rev-parse HEAD: ${head}`);
log('command: node tests/round3/phase1b-prod-proxy-cards.mjs');
const apps=[{name:'dairy',dir:'dairy_farm/backend',port:18401,proxy:18501},{name:'agri',dir:'agri_farm/backend',port:18402,proxy:18502},{name:'flock',dir:'flock_farm/backend',port:18403,proxy:18503}];
const procs=[]; const proxies=[];
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function start(app, env, label){
 const proc=spawn(process.execPath,['server.js'],{cwd:path.join(root,app.dir),env:{...process.env,PORT:String(app.port),MONGO_URI:'',MONGODB_URI:'',TELEGRAM_BOT_TOKEN:'',DISABLE_INTERNAL_SCHEDULER:'1',...env},stdio:['ignore','pipe','pipe']});
 proc.stdout.on('data',d=>log(`[${app.name} ${label} stdout] ${String(d).trim().slice(0,500)}`));
 proc.stderr.on('data',d=>log(`[${app.name} ${label} stderr] ${String(d).trim().slice(0,500)}`));
 procs.push(proc); app[label+'Proc']=proc; return proc;
}
async function wait(app){const base=`http://127.0.0.1:${app.port}`; for(let i=0;i<60;i++){try{const r=await fetch(base+'/api/farms'); if(r.status) return true}catch{} await sleep(300)} return false}
async function req(base,route,opts={}){const h={...(opts.headers||{})}; if(opts.token)h.Authorization=`Bearer ${opts.token}`; let body=opts.raw; if(opts.form){h['Content-Type']='application/x-www-form-urlencoded'; body=new URLSearchParams(opts.form)} else if(opts.body!==undefined){h['Content-Type']='application/json'; body=JSON.stringify(opts.body)} const r=await fetch(base+route,{method:opts.method||'GET',headers:h,body,redirect:'manual'}); const text=await r.text(); let data=null; try{data=JSON.parse(text)}catch{data=text} return {status:r.status,headers:Object.fromEntries(r.headers.entries()),text,data}}
async function login(base,app,u,p){return app.name==='agri'?req(base,'/api/login',{method:'POST',form:{username:u,password:p}}):req(base,'/api/auth/login',{method:'POST',body:{username:u,password:p}})}
function hdr(label,r){log(`${label}: HTTP ${r.status} CSP=${r.headers['content-security-policy']?'present':'ABSENT'} Cache=${r.headers['cache-control']||''} XCTO=${r.headers['x-content-type-options']||''} XFO=${r.headers['x-frame-options']||''} ACAO=${r.headers['access-control-allow-origin']||''} ACAC=${r.headers['access-control-allow-credentials']||''} body=${String(typeof r.data==='string'?r.data:JSON.stringify(r.data)).slice(0,300)}`)}
function startProxy(app){
 const srv=http.createServer((clientReq,clientRes)=>{
   const chunks=[]; clientReq.on('data',c=>chunks.push(c)); clientReq.on('end',()=>{
     const body=Buffer.concat(chunks); const headers={...clientReq.headers,host:`127.0.0.1:${app.port}`};
     const incoming=clientReq.headers['x-forwarded-for']; headers['x-forwarded-for']=incoming?`${incoming}, 198.51.100.23`:'198.51.100.23'; headers['x-forwarded-proto']='http';
     const up=http.request({hostname:'127.0.0.1',port:app.port,path:clientReq.url,method:clientReq.method,headers},upRes=>{clientRes.writeHead(upRes.statusCode,upRes.headers); upRes.pipe(clientRes)});
     up.on('error',e=>{clientRes.writeHead(502); clientRes.end(String(e))}); if(body.length)up.write(body); up.end();
   });
 });
 srv.listen(app.proxy,'127.0.0.1'); proxies.push(srv); log(`${app.name} proxy listening ${app.proxy} -> ${app.port}; proxy APPENDS ', 198.51.100.23' to X-Forwarded-For`);
}
function strip(html){return String(html).replace(/<style[\s\S]*?<\/style>/g,' ').replace(/<script[\s\S]*?<\/script>/g,' ').replace(/<[^>]+>/g,'\n').replace(/&[^;]+;/g,' ').split('\n').map(s=>s.trim()).filter(Boolean).join(' | ')}
function rows(data){ if(Array.isArray(data))return data; for(const k of ['items','data','rows','workers','buyers','suppliers','laborers','customers']) if(Array.isArray(data?.[k]))return data[k]; return [] }
function idOf(d){const r=d?.record||d?.item||d?.data||d; return String(r?._id||r?.id||'')}
try{
 log('\n=== TEST/MEMORY SERVERS + PROXY (for limiter/card tests) ===');
 for(const app of apps){ start(app,{NODE_ENV:'test',MEMORY_MODE:'1',JWT_SECRET:'[SECURITY_DATA]',CRON_SECRET:'[SECURITY_DATA]',LOG_REQUESTS:'1',FRONTEND_URL:'https://good.example'},'test'); app.ready=await wait(app); startProxy(app); app.base=`http://127.0.0.1:${app.port}`; app.pbase=`http://127.0.0.1:${app.proxy}`; let lo=null; for(let i=0;i<40;i++){ lo=await login(app.base,app,'admin','admin123'); if(lo.data?.token||lo.data?.access_token) break; await sleep(500);} app.owner=lo.data?.token||lo.data?.access_token||''; log(`${app.name} ready=${app.ready} ownerLogin=${lo.status} token=${app.owner?'present':'absent'}`); }

 log('\n=== LOGIN LIMITER: direct XFF spoof vs through appending proxy ===');
 for(const app of apps){
   const path=app.name==='agri'?'/api/login':'/api/auth/login';
   const isAgri=app.name==='agri';
   const attempt=(base,xff)=> isAgri? req(base,path,{method:'POST',form:{username:'admin',password:'wrong'},headers:{'X-Forwarded-For':xff}}) : req(base,path,{method:'POST',body:{username:'admin',password:'wrong'},headers:{'X-Forwarded-For':xff}});
   let statuses=[]; for(let i=1;i<=14;i++){ const r=await attempt(app.base,`203.0.113.${i}`); statuses.push(r.status); }
   log(`${app.name} DIRECT changing-XFF wrong logins x14: ${statuses.join(',')} => ${statuses.includes(429)?'limiter blocked despite spoof':'NO 429 (spoof creates fresh bucket)'}`);
   statuses=[]; for(let i=1;i<=14;i++){ const r=await attempt(app.pbase,`203.0.113.${i}`); statuses.push(r.status); }
   log(`${app.name} THROUGH PROXY changing client-supplied XFF x14 (proxy appends 198.51.100.23): ${statuses.join(',')} => ${statuses.includes(429)?'limiter BLOCKS (appended proxy IP is trusted key)' : 'NO 429'}`);
 }

 log('\n=== CRON QUERY KEY IN LOGS (LOG_REQUESTS=1 servers above) ===');
 // requests are issued now; server stdout [REQ] lines are captured in this output around these markers.
 for(const app of apps.filter(a=>a.name!=='dairy')){
   const route=app.name==='flock'?'/api/cron/daily-summary?key=CRONLOGSECRET123':'/api/cron/dispatch-report?key=CRONLOGSECRET123';
   // set actual secret mismatch intentionally? Server secret is cronsecret... use correct below via second request
   const wrong=await req(app.base,route); log(`${app.name} cron wrong ?key request HTTP ${wrong.status} body=${JSON.stringify(wrong.data).slice(0,200)}`);
   const route2=app.name==='flock'?'/api/cron/daily-summary?key=[SECURITY_DATA]':'/api/cron/dispatch-report?key=[SECURITY_DATA]';
   const ok=await req(app.base,route2); log(`${app.name} cron correct ?key request HTTP ${ok.status} body=${JSON.stringify(ok.data).slice(0,200)}`);
 }
 await sleep(700);
 log('^^ Search the [REQ] stdout lines above for key=[SECURITY_DATA] / CRONLOGSECRET123: if present verbatim, the query secret is written to server logs. Response bodies above show whether it is echoed (it is not in these bodies).');

 log('\n=== CARDS: data returned, ID guessability, burst limiter direct vs proxy ===');
 const cardTargets=[];
 const addCard=(app,type,listRoute,cardRoute,id)=>{ if(id) cardTargets.push({app,type,cardRoute,id,listRoute}); };
 for(const app of apps){
   if(app.name==='dairy'){
     for(const [type,listRoute,cardRoute] of [['buyer','/api/buyers','/api/cards/buyer/'],['supplier','/api/suppliers','/api/cards/supplier/'],['worker','/api/labor/workers','/api/cards/worker/']]){
       const list=await req(app.base,listRoute,{token:app.owner}); const rs=rows(list.data); log(`dairy ${type} list ${listRoute} HTTP ${list.status} ids=${rs.map(x=>idOf(x)).join(',')}`); addCard(app,type,listRoute,cardRoute,idOf(rs[0])); }
   } else if(app.name==='agri'){
     for(const [type,listRoute,cardRoute] of [['supplier','/api/suppliers','/api/cards/supplier/'],['worker','/api/laborers','/api/cards/worker/']]){
       const list=await req(app.base,listRoute,{token:app.owner}); const rs=rows(list.data); log(`agri ${type} list ${listRoute} HTTP ${list.status} ids=${rs.map(x=>idOf(x)).join(',')}`); addCard(app,type,listRoute,cardRoute,idOf(rs[0])); }
   } else {
     for(const key of ['customers','suppliers','laborers']){
       const r=await req(app.base,`/api/data/${key}`,{token:app.owner}); const rs=rows(r.data?.value||r.data); log(`flock bucket ${key} HTTP ${r.status} ids=${rs.map(x=>String(x.id||x._id||'')).join(',')}`); }
     const cust=await req(app.base,'/api/data/customers',{token:app.owner}); const crs=rows(cust.data?.value||cust.data); addCard(app,'customer','/api/data/customers','/api/cards/customer/',String(crs[0]?.id||''));
     const sup=await req(app.base,'/api/data/suppliers',{token:app.owner}); const srs=rows(sup.data?.value||sup.data); addCard(app,'supplier','/api/data/suppliers','/api/cards/supplier/',String(srs[0]?.id||''));
     const lab=await req(app.base,'/api/data/laborers',{token:app.owner}); const lrs=rows(lab.data?.value||lab.data); addCard(app,'worker','/api/data/laborers','/api/cards/worker/',String(lrs[0]?.id||''));
   }
 }
 for(const t of cardTargets){
   const r=await req(t.app.base,`${t.cardRoute}${t.id}`);
   log(`${t.app.name} ${t.type} ANON card id=${t.id}: HTTP ${r.status} headers cache=${r.headers['cache-control']||''} robots=${r.headers['x-robots-tag']||''} referrer=${r.headers['referrer-policy']||''}`);
   log(`${t.app.name} ${t.type} CARD TEXT: ${strip(r.text).slice(0,900)}`);
 }
 // Flock customer enumeration: numeric ids
 const flockApp=apps.find(a=>a.name==='flock');
 let enumStatuses=[]; for(let i=1;i<=8;i++){ const r=await req(flockApp.base,`/api/cards/customer/${i}`); enumStatuses.push(`${i}:${r.status}`); }
 log(`flock customer enumeration ids 1..8 anon: ${enumStatuses.join(' ')} (200 = card exists; sequential numeric ids are enumerable, subject to 60/15m limiter)`);
 // Burst test on one card per app, direct fresh XFF vs proxy. NOTE card limiter is per-IP; use dairy buyer.
 for(const t of cardTargets.slice(0,3)){
   let ss=[]; for(let i=0;i<65;i++){ const r=await req(t.app.base,`${t.cardRoute}${t.id}`,{headers:{'X-Forwarded-For':'192.0.2.55'}}); ss.push(r.status); }
   log(`${t.app.name} ${t.type} BURST direct same-IP x65: 200x${ss.filter(s=>s===200).length} 429x${ss.filter(s=>s===429).length} first429At=${ss.indexOf(429)+1||'never'}`);
   let sp=[]; for(let i=0;i<65;i++){ const r=await req(t.app.pbase,`${t.cardRoute}${t.id}`,{headers:{'X-Forwarded-For':`203.0.113.${100+i}`}}); sp.push(r.status); }
   log(`${t.app.name} ${t.type} BURST through proxy changing spoofed XFF x65: 200x${sp.filter(s=>s===200).length} 429x${sp.filter(s=>s===429).length} first429At=${sp.indexOf(429)+1||'never'} => ${sp.includes(429)?'proxy-appended IP is the bucket; spoof does NOT reset':'SPOOF RESETS BUCKET THROUGH PROXY'}`);
 }

 log('\n=== PRODUCTION-MODE SERVERS (fake MONGO_URI, no real DB available) ===');
 log('Limitation: production + MEMORY_MODE exits by design, and no real MongoDB is available in this sandbox (Phase 0/4). Production probes below use NODE_ENV=production, FRONTEND_URL=https://good.example, strong JWT_SECRET, MONGO_URI=mongodb://127.0.0.1:27017/muf_prod (unreachable). API may stay at the 503 startup gate; CORS/header behaviour is still observable on those responses. Authenticated production behaviour is UNVERIFIED until a real DB exists.');
 for(const app of apps){
   // stop test proc first to avoid dual-listen confusion on same backend port? production uses new ports
   app.pport=app.port+1000; app.prodBase=`http://127.0.0.1:${app.pport}`;
   const proc=spawn(process.execPath,['server.js'],{cwd:path.join(root,app.dir),env:{...process.env,PORT:String(app.pport),NODE_ENV:'production',MEMORY_MODE:'',MONGO_URI:'mongodb://127.0.0.1:27017/muf_prod',MONGODB_URI:'mongodb://127.0.0.1:27017/muf_prod',JWT_SECRET:'[SECURITY_DATA]',CRON_SECRET:'[SECURITY_DATA]',FRONTEND_URL:'https://good.example',APP_URL:'https://good.example',TELEGRAM_BOT_TOKEN:'',DISABLE_INTERNAL_SCHEDULER:'1',LOG_REQUESTS:'0'},stdio:['ignore','pipe','pipe']});
   proc.stdout.on('data',d=>log(`[${app.name} prod stdout] ${String(d).trim().slice(0,400)}`)); proc.stderr.on('data',d=>log(`[${app.name} prod stderr] ${String(d).trim().slice(0,400)}`)); procs.push(proc);
   await sleep(2500);
   log(`${app.name} prod process exitCode=${proc.exitCode}`);
   const good=await req(app.prodBase,'/api/farms',{headers:{Origin:'https://good.example'}}).catch(e=>({status:0,text:String(e),headers:{},data:''}));
   hdr(`${app.name} PROD actual GET /api/farms Origin=good`,good);
   const evil=await req(app.prodBase,'/api/farms',{headers:{Origin:'https://evil.example.com'}}).catch(e=>({status:0,text:String(e),headers:{},data:''}));
   hdr(`${app.name} PROD actual GET /api/farms Origin=evil`,evil);
   for(const origin of ['https://good.example','https://evil.example.com']){
     const pre=await fetch(`${app.prodBase}/api/farms`,{method:'OPTIONS',headers:{Origin:origin,'Access-Control-Request-Method':'GET','Access-Control-Request-Headers':'authorization,content-type'}}).catch(e=>null);
     log(`${app.name} PROD preflight Origin=${origin}: HTTP ${pre?pre.status:0} ACAO=${pre?.headers.get('access-control-allow-origin')} ACAC=${pre?.headers.get('access-control-allow-credentials')} ACAH=${pre?.headers.get('access-control-allow-headers')}`);
   }
   const err=await req(app.prodBase,'/api/definitely-not-a-route',{headers:{Origin:'https://evil.example.com'}}).catch(e=>({status:0,text:String(e),headers:{},data:''}));
   hdr(`${app.name} PROD error route Origin=evil`,err);
   const html=await req(app.prodBase,'/',{headers:{Origin:'https://evil.example.com'}}).catch(e=>({status:0,text:String(e),headers:{},data:''}));
   log(`${app.name} PROD GET / (HTML): HTTP ${html.status} content-type=${html.headers['content-type']||''} CSP=${html.headers['content-security-policy']?'present':'ABSENT'} bodyStart=${String(html.text).slice(0,120).replace(/\n/g,' ')}`);
   const asset=await req(app.prodBase,'/assets/index.js',{headers:{Origin:'https://evil.example.com'}}).catch(e=>({status:0,text:String(e),headers:{},data:''}));
   log(`${app.name} PROD GET /assets/index.js (static guess): HTTP ${asset.status} content-type=${asset.headers['content-type']||''} CSP=${asset.headers['content-security-policy']?'present':'ABSENT'} Cache=${asset.headers['cache-control']||''}`);
   try{proc.kill('SIGTERM')}catch{}
 }
} catch(e){ log(`FATAL ${e.stack||e}`); }
finally{ for(const s of proxies){try{s.close()}catch{}} for(const p of procs){try{p.kill('SIGTERM')}catch{}} await sleep(500); for(const p of procs){try{p.kill('SIGKILL')}catch{}} fs.writeFileSync(path.join(outDir,'phase1b-prod-proxy-cards.txt'),out.join('\n')+'\n'); }
