import { spawn, execSync } from 'node:child_process';
import fs from 'node:fs'; import path from 'node:path';
import { createRequire } from 'node:module';
const require2=createRequire('/home/user/bughunt-round3/tools-round3/package.json');
const pwCore=require2('playwright-core');
const root=process.cwd(); const head=execSync('git rev-parse HEAD',{cwd:root,encoding:'utf8'}).trim();
const out=[]; const log=(s='')=>{out.push(String(s)); console.log(s)};
log(`git rev-parse HEAD: ${head}`); log('command: node tests/round3/phase3b-state.mjs'); log('environment: real Chromium 153, backends NODE_ENV=test MEMORY_MODE=1 serving built dist');
process.env.LD_LIBRARY_PATH='/home/user/bughunt-round3/tools-round3/src/dist/Release/lib';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const axeSource=fs.readFileSync(path.join(root,'tools-round3/node_modules/axe-core/axe.min.js'),'utf8');
const shotDir=path.join(root,'results/round3/screenshots');
const apps=[{name:'dairy',dir:'dairy_farm/backend',port:19401,agri:false},{name:'agri',dir:'agri_farm/backend',port:19402,agri:true},{name:'flock',dir:'flock_farm/backend',port:19403,agri:false}];
const chr=require2('@sparticuz/chromium').default; const exe=await chr.executablePath();
async function dump(page,label){ const d=await page.evaluate(async()=>{ const ls={}; for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i); ls[k]=String(localStorage.getItem(k)).slice(0,160)} const ss={}; for(let i=0;i<sessionStorage.length;i++){const k=sessionStorage.key(i); ss[k]=String(sessionStorage.getItem(k)).slice(0,160)} let cachesList={}; try{ for(const k of await caches.keys()){ const c=await caches.open(k); const reqs=await c.keys(); cachesList[k]=reqs.map(r=>new URL(r.url).pathname).slice(0,12);} }catch{} return {localStorage:ls,sessionStorage:ss,caches:cachesList}; }); log(`${label}: ${JSON.stringify(d).slice(0,2200)}`); return d; }
for(const app of apps){
 log(`\n===== ${app.name} =====`);
 const proc=spawn(process.execPath,['server.js'],{cwd:path.join(root,app.dir),env:{...process.env,PORT:String(app.port),NODE_ENV:'test',MEMORY_MODE:'1',MONGO_URI:'',MONGODB_URI:'',JWT_SECRET:'[SECURITY_DATA]',DISABLE_INTERNAL_SCHEDULER:'1',LOG_REQUESTS:'0'},stdio:'ignore'});
 const base=`http://127.0.0.1:${app.port}`; for(let i=0;i<60;i++){ try{ const r=await fetch(base+'/'); if(r.status) break; }catch{} await sleep(400); }
 const browser=await pwCore.chromium.launch({executablePath:exe,args:[...chr.args,'--no-sandbox'],headless:true});
 try{
  const ctx=await browser.newContext({viewport:{width:1366,height:900}}); const page=await ctx.newPage();
  await page.goto(base+'/',{waitUntil:'load',timeout:45000}); await page.waitForTimeout(1200);
  // UI login admin
  await page.locator('input[type="text"], input:not([type]), input[type="email"]').first().fill('admin');
  await page.locator('input[type="password"]').first().fill('admin123');
  await page.locator('button[type="submit"], button').filter({hasText:/sign in|login/i}).first().click().catch(async()=>{ await page.locator('button').last().click(); });
  await page.waitForTimeout(3000);
  await page.evaluate(()=>{ const b=[...document.querySelectorAll('button')].find(e=>/got it/i.test(e.innerText)); if(b) b.click(); });
  await page.waitForTimeout(600);
  log(`${app.name} logged in as admin; url=${page.url()}`);
  const before=await dump(page,`${app.name} after-login`);
  // offline queue keys
  const qkeys=Object.keys(before.localStorage).filter(k=>/queue|offline|sync|pending|outbox/i.test(k));
  log(`${app.name} offline-queue localStorage keys: ${JSON.stringify(qkeys)} (values truncated in dump above)`);
  // dark via evaluate click on aria-label Toggle theme
  const darkClicked=await page.evaluate(()=>{ const b=document.querySelector('button[aria-label="Toggle theme"], button[aria-label*="theme" i]'); if(!b) return false; b.click(); return true; });
  await page.waitForTimeout(700);
  const darkState=await page.evaluate(()=>({cls:document.documentElement.className+' '+document.body.className, lsTheme:localStorage.getItem('theme')||localStorage.getItem('dm_dark')||localStorage.getItem('flockfarm_dark_mode')}));
  log(`${app.name} dark toggle clicked=${darkClicked} state=${JSON.stringify(darkState).slice(0,200)}`);
  await page.evaluate(axeSource).catch(()=>{}); const axeDark=await page.evaluate(async()=>{ const r=await window.axe.run(document,{resultTypes:['violations']}); return r.violations.map(v=>({id:v.id,impact:v.impact,nodes:v.nodes.length})); }).catch(e=>[{error:String(e)}]);
  log(`${app.name} AXE dark-desktop: ${JSON.stringify(axeDark).slice(0,500)}`);
  await page.screenshot({path:path.join(shotDir,`${app.name}-home-desktop-dark-en.png`),timeout:8000}).catch(()=>{});
  // back to light
  await page.evaluate(()=>{ const b=document.querySelector('button[aria-label="Toggle theme"], button[aria-label*="theme" i]'); if(b) b.click(); }); await page.waitForTimeout(500);
  // language switch
  const langClicked=await page.evaluate(()=>{ const b=document.querySelector('button[aria-label="Switch language"], button[aria-label*="language" i]'); if(!b) return false; b.click(); return true; });
  await page.waitForTimeout(900);
  const langState=await page.evaluate(()=>({dir:document.documentElement.dir||document.body.dir||'', lang:document.documentElement.lang||'', sample:document.body.innerText.slice(0,120).replace(/\n/g,' | ')}));
  log(`${app.name} language toggle clicked=${langClicked} state=${JSON.stringify(langState)}`);
  await page.evaluate(axeSource).catch(()=>{}); const axeUr=await page.evaluate(async()=>{ const r=await window.axe.run(document,{resultTypes:['violations']}); return r.violations.map(v=>({id:v.id,impact:v.impact,nodes:v.nodes.length})); }).catch(e=>[{error:String(e)}]);
  log(`${app.name} AXE urdu-desktop: ${JSON.stringify(axeUr).slice(0,500)}`);
  await page.screenshot({path:path.join(shotDir,`${app.name}-home-desktop-ur.png`),timeout:8000}).catch(()=>{});
  // logout via evaluate click
  const loClicked=await page.evaluate(()=>{ const b=document.querySelector('button.muf-logout, button[aria-label="Logout"], button[aria-label*="logout" i]'); if(!b) return false; b.click(); return true; });
  await page.waitForTimeout(900);
  const confirmClicked=await page.evaluate(()=>{ const btns=[...document.querySelectorAll('[role="dialog"] button, .modal button, dialog button, button')]; const b=btns.find(e=>/sign out|logout|log out|سائن آؤٹ|لاگ آؤٹ/i.test(e.innerText)) || btns[btns.length-1]; if(!b) return false; b.click(); return b.innerText; });
  await page.waitForTimeout(1800);
  log(`${app.name} logout confirm clicked=${JSON.stringify(confirmClicked)}`);
  log(`${app.name} logout clicked=${loClicked} url=${page.url()} bodyStart=${(await page.locator('body').innerText().catch(()=>'' )).slice(0,150).replace(/\n/g,' | ')}`);
  await dump(page,`${app.name} after-logout`);
  // login as worker (user B) in same context: check leftover admin data
  const hasLogin=await page.locator('input[type="password"]').count();
  if(hasLogin){
    await page.locator('input[type="text"], input:not([type]), input[type="email"]').first().fill('worker');
    await page.locator('input[type="password"]').first().fill('worker123');
    await page.locator('button[type="submit"], button').filter({hasText:/sign in|login/i}).first().click().catch(async()=>{ await page.locator('button').last().click(); });
    await page.waitForTimeout(3000);
    await page.evaluate(()=>{ const b=[...document.querySelectorAll('button')].find(e=>/got it/i.test(e.innerText)); if(b) b.click(); });
    await page.waitForTimeout(500);
    const btext=(await page.locator('body').innerText().catch(()=>'' )).slice(0,300).replace(/\n/g,' | ');
    log(`${app.name} user-B (worker) after-login text: ${btext}`);
    await dump(page,`${app.name} user-B storage`);
  } else log(`${app.name} user-B login form not present after logout (logout may have failed)`);
  await ctx.close();
 } catch(e){ log(`${app.name} FATAL ${String(e.stack||e).slice(0,600)}`); }
 finally{ await browser.close().catch(()=>{}); proc.kill('SIGTERM'); await sleep(300); try{proc.kill('SIGKILL')}catch{} }
}
fs.writeFileSync(path.join(root,'results/round3/phase3b-state.txt'), out.join('\n')+'\n');
