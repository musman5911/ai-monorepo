import crypto from 'node:crypto';
const orig = crypto.timingSafeEqual;
crypto.timingSafeEqual = (a,b) => { console.log('TSE', JSON.stringify(String(a)), JSON.stringify(String(b)), a.length, b.length); return orig(a,b); };
