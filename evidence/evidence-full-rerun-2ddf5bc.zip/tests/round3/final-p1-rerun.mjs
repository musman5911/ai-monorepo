import {login as acceptanceLogin} from '../acceptance/_harness.mjs';
import { execSync, spawn } from 'node:child_process';
import fs from 'node:fs';
const HEAD = '2ddf5bccd555b779ee7446c038a30fc5bcd1bcb0';
const out = [`git rev-parse HEAD: ${HEAD}`, `date: ${new Date().toISOString()}`, 'FINAL P1 RERUN on newest tip (memory mode, NODE_ENV=test, direct server)'];
const sleep=(ms)=>new Promise(r=>setTimeout(r,ms));
async function start(dir,port){ const p=spawn('node',['server.js'],{cwd:dir,env:{...process.env,PORT:String(port),NODE_ENV:'test',MEMORY_MODE:'1',MONGO_URI:'',MONGODB_URI:'',JWT_SECRET:'[SECURITY_DATA]',DISABLE_INTERNAL_SCHEDULER:'1',LOG_REQUESTS:'0'},stdio:'ignore'}); for(let i=0;i<40;i++){ try{ const r=await fetch(`http://127.0.0.1:${port}/api/health`); if(r.ok) break;}catch{} await sleep(500);} return p; }
async function login(base,u,pw){return acceptanceLogin(base,u,pw,base.endsWith('19603')?'agri':base.endsWith('19601')?'flock':'dairy');}

const R='/home/user/full-rerun';
const servers=[];
async function app(name,dir,port,tests){ const p=await start(dir,port); servers.push(p); const base=`http://127.0.0.1:${port}`; out.push(`\n### ${name} ${base}`); try{ await tests(base); }catch(e){ out.push('ERROR '+e.message); } p.kill('SIGKILL'); }
const jh=(t)=>({Authorization:`Bearer ${t}`,'Content-Type':'application/json'});
await app('FLOCK',`${R}/flock_farm/backend`,19601,async(base)=>{
  let r=await fetch(base+'/api/cards/customer/1'); let t=await r.text();
  out.push(`[B1-B3 rerun] anon GET /api/cards/customer/1 -> ${r.status}; contains phone 0301-1234567: ${t.includes('0301-1234567')}; contains name Khan: ${t.includes('Khan General Store')}`);
  const tok=await login(base,'admin','admin123');
  r=await fetch(base+'/api/auth/logout',{method:'POST',headers:jh(tok)}); out.push(`[A1 rerun] POST /api/auth/logout -> ${r.status}`);
  r=await fetch(base+'/api/data/customers',{headers:jh(tok)}); out.push(`[A1 rerun] reuse old token GET /api/data/customers -> ${r.status} (200 = STILL FAILING non-revocation)`);
});
await app('DAIRY',`${R}/dairy_farm/backend`,19602,async(base)=>{
  const tok=await login(base,'admin','admin123');
  let r=await fetch(base+'/api/auth/logout',{method:'POST',headers:jh(tok)}); out.push(`[A1 rerun] POST /api/auth/logout -> ${r.status}`);
  r=await fetch(base+'/api/cows',{headers:jh(tok)}); out.push(`[A1 rerun] reuse old token GET /api/cows -> ${r.status} (200 = STILL FAILING)`);
});
await app('AGRI',`${R}/agri_farm/backend`,19603,async(base)=>{
  const tok=await login(base,'admin','admin123');
  let r=await fetch(base+'/api/logout',{method:'POST',headers:jh(tok)}); out.push(`[A1 rerun] POST /api/auth/logout -> ${r.status}`);
  r=await fetch(base+'/api/fields',{headers:jh(tok)}); out.push(`[A1 rerun] reuse old token GET /api/fields -> ${r.status} (200 = STILL FAILING)`);
  r=await fetch(base+'/api/liabilities',{method:'POST',headers:jh(tok),body:JSON.stringify({creditor:'RERUN',amount_owed:-5000})}); out.push(`[neg-liability rerun] POST /api/liabilities amount=-5000 -> ${r.status} body=${(await r.text()).slice(0,150)}`);
});
servers.forEach(p=>{try{p.kill('SIGKILL')}catch{}});
fs.writeFileSync(`${R}/results/round3/final-p1-rerun.txt`, out.join('\n')+'\n');
console.log(out.join('\n'));
