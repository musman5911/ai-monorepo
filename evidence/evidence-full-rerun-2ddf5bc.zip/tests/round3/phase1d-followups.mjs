import { spawn, execSync } from 'node:child_process';
import fs from 'node:fs'; import path from 'node:path';
const root=process.cwd(); const head='2ddf5bccd555b779ee7446c038a30fc5bcd1bcb0';
const out=[]; const log=(s='')=>{out.push(String(s)); console.log(s)};
log(`git rev-parse HEAD: ${head}`); log('command: node tests/round3/phase1d-followups.mjs'); log('environment: direct local servers, NODE_ENV=test, MEMORY_MODE=1, LOG_REQUESTS=1; production-mode section labelled separately');
const apps=[{name:'dairy',dir:'dairy_farm/backend',port:19101},{name:'agri',dir:'agri_farm/backend',port:19102},{name:'flock',dir:'flock_farm/backend',port:19103}];
const procs=[]; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function start(app,env,label='test'){ const p=spawn(process.execPath,['server.js'],{cwd:path.join(root,app.dir),env:{...process.env,PORT:String(app.port),MONGO_URI:'',MONGODB_URI:'',TELEGRAM_BOT_TOKEN:'',DISABLE_INTERNAL_SCHEDULER:'1',...env},stdio:['ignore','pipe','pipe']}); p.stdout.on('data',d=>log(`[${app.name} ${label} stdout] ${String(d).trim().slice(0,400)}`)); p.stderr.on('data',d=>log(`[${app.name} ${label} stderr] ${String(d).trim().slice(0,250)}`)); procs.push(p); app.proc=p; app.base=`http://127.0.0.1:${app.port}`; return p; }
async function req(base,route,o={}){const h={...(o.headers||{})}; if(o.token)h.Authorization=`Bearer ${o.token}`; if(o.farmId)h['X-Farm-Id']=o.farmId; let body=o.raw; if(o.form){h['Content-Type']='application/x-www-form-urlencoded';body=new URLSearchParams(o.form)} else if(o.body!==undefined){h['Content-Type']='application/json';body=JSON.stringify(o.body)} const r=await fetch(base+route,{method:o.method||'GET',headers:h,body}); const t=await r.text(); let d=null; try{d=JSON.parse(t)}catch{d=t} return {status:r.status,headers:Object.fromEntries(r.headers.entries()),text:t,data:d}}
async function waitLogin(app){ let tok=''; for(let i=0;i<50&&!tok;i++){ try{ const r=app.name==='agri'?await req(app.base,'/api/login',{method:'POST',form:{username:'admin',password:'admin123'}}):await req(app.base,'/api/auth/login',{method:'POST',body:{username:'admin',password:'admin123'}}); tok=r.data?.token||r.data?.access_token||''; }catch{} if(!tok) await sleep(400);} return tok; }
function strip(html){return String(html).replace(/<style[\s\S]*?<\/style>/g,' ').replace(/<script[\s\S]*?<\/script>/g,' ').replace(/<[^>]+>/g,'\n').split('\n').map(s=>s.trim()).filter(Boolean).join(' | ')}
try{
 for(const app of apps){ start(app,{NODE_ENV:'test',MEMORY_MODE:'1',JWT_SECRET:'[SECURITY_DATA]',CRON_SECRET:'[SECURITY_DATA]',LOG_REQUESTS:'1'}); app.owner=await waitLogin(app); log(`${app.name} setup owner=${app.owner?'ok':'FAIL'}`); }
 const flock=apps[2], agri=apps[1], dairy=apps[0];
 log('\n=== FLOCK CARDS: enumeration quantification (anon, from id 1) ===');
 for(const [type,route] of [['customer','/api/cards/customer/'],['supplier','/api/cards/supplier/'],['worker','/api/cards/worker/']]){
   // sequential ids for customer/supplier; worker uses lw- ids handled separately
   if(type==='worker') continue;
   let found=[]; let first404=null; for(let i=1;i<=20;i++){ const r=await req(flock.base,route+i); if(r.status===200) found.push(i); else if(first404===null && r.status===404) first404=i; }
   log(`flock ${type}: anon ids 1..20 -> 200 at [${found.join(',')}], first 404 at ${first404} (limiter 60/15m shared per IP; this probe used <=20 requests)`);
   for(const i of found){ const r=await req(flock.base,route+i); log(`flock ${type} id=${i} FIELDS: ${strip(r.text).slice(0,700)}`); }
 }
 // workers: list ids from bucket, then timing-guess estimate
 const lab=await req(flock.base,'/api/data/laborers',{token:flock.owner}); const workers=Array.isArray(lab.data?.value)?lab.data.value:[];
 log(`flock worker bucket ids (owner view): ${workers.map(w=>String(w.id)).join(', ')}`);
 for(const w of workers){ const r=await req(flock.base,`/api/cards/worker/${w.id}`); log(`flock worker id=${w.id} anon HTTP ${r.status} FIELDS: ${strip(r.text).slice(0,650)}`); }
 log('flock worker id guessability: ids are lw-<epoch ms> (client LaborTab.tsx: id: `lw-${Date.now()}`). Enumerating one day = 86,400,000 possible ms values; at 60 req/15min/IP that is infeasible from one IP (~3.9 years of windows), but the timestamp is known to the day if creation date is known, narrowing to that day; IP rotation defeats the per-IP limiter (no global limiter observed). Customer/supplier integer ids remain trivially enumerable (max+1).');
 log('\n=== FLOCK CARDS: two-farm context test ===');
 const farms=await req(flock.base,'/api/farms',{token:flock.owner}); const farmA=farms.data?.farms?.[0]?.id||farms.data?.activeFarmId||''; log(`flock farms list HTTP ${farms.status} farmA=${farmA} farms=${(farms.data?.farms||[]).map(f=>f.id).join(',')}`);
 const custA=await req(flock.base,'/api/data/customers',{token:flock.owner,farmId:farmA}); log(`flock farmA customers bucket: ${JSON.stringify(custA.data?.value||[]).slice(0,300)}`);
 const mkFarm=await req(flock.base,'/api/farms',{method:'POST',token:flock.owner,body:{name:'R3 Farm B'}}); const farmB=mkFarm.data?.id||mkFarm.data?._id||mkFarm.data?.farm?.id||''; log(`flock create farmB HTTP ${mkFarm.status} farmB=${farmB} body=${JSON.stringify(mkFarm.data).slice(0,200)}`);
 if(farmB){
   const curB=await req(flock.base,'/api/data/customers',{token:flock.owner,farmId:farmB}); const verB=curB.data?.version||0; const valB=Array.isArray(curB.data?.value)?curB.data.value:[];
   const newVal=[...valB.filter(c=>c.id!==1), {id:1,name:'FARM-B-ONLY CUSTOMER',phone:'0399-0000001'}];
   const put=await req(flock.base,'/api/data/customers',{method:'PUT',token:flock.owner,farmId:farmB,body:{value:newVal,baseVersion:verB}}); log(`flock farmB PUT customers (id=1 FARM-B-ONLY) HTTP ${put.status} version=${put.data?.version}`);
   const custB=await req(flock.base,'/api/data/customers',{token:flock.owner,farmId:farmB}); log(`flock farmB customers after PUT: ${JSON.stringify(custB.data?.value||[]).slice(0,300)}`);
   const custA2=await req(flock.base,'/api/data/customers',{token:flock.owner,farmId:farmA}); log(`flock farmA customers after farmB PUT: ${JSON.stringify(custA2.data?.value||[]).slice(0,300)}`);
 }
 const anon1=await req(flock.base,'/api/cards/customer/1'); log(`flock ANON /cards/customer/1 (no farm context) HTTP ${anon1.status} SHOWS: ${strip(anon1.text).slice(0,500)}`);
 log('Interpretation: whichever farm name appears above is what an anonymous caller gets for id 1. If it is farm A (default) while farm B has its own id 1, the card route does not take farm context from the request; it resolves the default/first farm bucket. Cross-farm reading of farm B by anon would require the bucket selection to change; record exactly what was observed.');
 log('\n=== CRON ?key= LOGGING per app (LOG_REQUESTS=1, stdout captured above/below) ===');
 const flockCron=await req(flock.base,'/api/cron/daily-summary?key=[SECURITY_DATA]'); log(`flock cron correct ?key HTTP ${flockCron.status}`);
 const agriCron=await req(agri.base,'/api/cron/dispatch-report?key=[SECURITY_DATA]'); log(`agri cron correct ?key HTTP ${agriCron.status}`);
 const dairyCron=await req(dairy.base,'/api/telegram/cron?key=[SECURITY_DATA]'); log(`dairy telegram cron ?key HTTP ${dairyCron.status} (Dairy has no /cron/* route; telegram cron is its key-in-URL equivalent)`);
 await sleep(800);
 log('^^ Compare [REQ] stdout lines: an app logs the full ?key= URL only if a [REQ] line containing key=[SECURITY_DATA] appears for it above.');
 log('\n=== AGRI operator-object payloads on string/enum fields ===');
 const op={'$ne':'x'};
 const cropFields=[
   ['name',op],['status',op],['season',op],['crop_type',op],['variety',op],['unit',op],['notes',op],['plant_date',op],['harvest_date',op],['area_kanal',op],['fieldId',op],['field_id',op],
 ];
 for(const [field,val] of cropFields){
   const body={name:`R3 op ${field}`,status:'active',plant_date:'2026-10-01',area_kanal:5}; body[field]=val;
   const r=await req(agri.base,'/api/crops',{method:'POST',token:agri.owner,body});
   const stored=r.data&&typeof r.data==='object'?r.data[field]:undefined;
   log(`agri crop field ${field}={\"$ne\":\"x\"} -> HTTP ${r.status} stored=${JSON.stringify(stored)} body=${JSON.stringify(r.data).slice(0,220)}`);
 }
 // other Agri resources with string fields
 for(const [res,body] of [['liabilities',{creditor:op,amount_owed:100}],['inventory',{name:op,quantity:3,unit:'bags'}],['tasks',{title:op,status:'pending'}],['suppliers',{name:op,phone:'03001112223'}]]){
   const r=await req(agri.base,`/api/${res}`,{method:'POST',token:agri.owner,body});
   log(`agri ${res} operator-in-name/creditor/title -> HTTP ${r.status} body=${JSON.stringify(r.data).slice(0,220)}`);
 }
 log('\n=== Unconfigured-SMTP / service routes: status + body (SMTP unset in this env) ===');
 const smtpProbes=[
   [dairy,'POST','/api/auth/forgot-password',{email:'admin@example.com'}],[dairy,'POST','/api/auth/reset-password',{email:'admin@example.com',code:'123456',newPassword:'Newpass123!'}],[dairy,'POST','/api/auth/change-password',null],
   [flock,'POST','/api/auth/forgot-password',{email:'admin@example.com'}],[flock,'POST','/api/auth/reset-password',{email:'admin@example.com',code:'123456',newPassword:'Newpass123!'}],
   [agri,'POST','/api/forgot-password',{email:'admin@example.com'}],[agri,'POST','/api/reset-password',{email:'admin@example.com',code:'123456',newPassword:'Newpass123!'}],[agri,'POST','/api/request-profile-code',{}],[agri,'POST','/api/settings/automations/trigger',{}],
 ];
 for(const [app,method,route,body] of smtpProbes){ const o={method,token:route.includes('change-password')||route.includes('trigger')?app.owner:undefined}; if(body)o.body=body; const r=await req(app.base,route,o); log(`${app.name} ${method} ${route} (SMTP unconfigured) -> HTTP ${r.status} body=${String(r.text).slice(0,240)}`); }
 log('\n=== PRODUCTION-MODE full header sets (no real DB; fake MONGO_URI; dist absent until Phase 3 builds) ===');
 for(const app of apps){
   app.pport=app.port+1000; const p=spawn(process.execPath,['server.js'],{cwd:path.join(root,app.dir),env:{...process.env,PORT:String(app.pport),NODE_ENV:'production',MEMORY_MODE:'',MONGO_URI:'mongodb://127.0.0.1:27017/muf_prod',MONGODB_URI:'mongodb://127.0.0.1:27017/muf_prod',JWT_SECRET:'[SECURITY_DATA]',CRON_SECRET:'[SECURITY_DATA]',FRONTEND_URL:'https://good.example',APP_URL:'https://good.example',TELEGRAM_BOT_TOKEN:'',DISABLE_INTERNAL_SCHEDULER:'1',LOG_REQUESTS:'0'},stdio:'ignore'}); procs.push(p);
   await sleep(2200); const pb=`http://127.0.0.1:${app.pport}`;
   for(const [label,url] of [['HTML /',pb+'/'],['API /api/farms',pb+'/api/farms'],['ERROR /api/nope',pb+'/api/definitely-not-a-route']]){
     try{ const r=await fetch(url,{headers:{Origin:'https://evil.example.com'}}); const t=await r.text(); log(`${app.name} PROD ${label}: HTTP ${r.status}\n  headers: ${JSON.stringify(Object.fromEntries(r.headers.entries()))}\n  bodyStart: ${t.slice(0,100).replace(/\n/g,' ')}`);}catch(e){ log(`${app.name} PROD ${label}: FETCH FAILED ${e.message}`); }
   }
   try{p.kill('SIGTERM')}catch{}
 }
} catch(e){ log(`FATAL ${e.stack||e}`)}
finally{ for(const p of procs){try{p.kill('SIGTERM')}catch{}} await sleep(400); for(const p of procs){try{p.kill('SIGKILL')}catch{}} fs.writeFileSync(path.join(root,'results/round3/phase1d-followups.txt'),out.join('\n')+'\n'); }
