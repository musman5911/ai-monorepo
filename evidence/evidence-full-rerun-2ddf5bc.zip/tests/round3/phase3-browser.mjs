import { spawn, execSync } from 'node:child_process';
import fs from 'node:fs'; import path from 'node:path';
process.env.LD_LIBRARY_PATH = '/home/user/bughunt-round3/tools-round3/src/dist/Release/lib' + (process.env.LD_LIBRARY_PATH ? ':' + process.env.LD_LIBRARY_PATH : '');
import { createRequire } from 'node:module';
const require2 = createRequire('/home/user/bughunt-round3/tools-round3/package.json');
const pwCore = require2('playwright-core');
const root=process.cwd(); const head=execSync('git rev-parse HEAD',{cwd:root,encoding:'utf8'}).trim();
const out=[]; const log=(s='')=>{out.push(String(s)); console.log(s)};
log(`git rev-parse HEAD: ${head}`); log('command: node tests/round3/phase3-browser.mjs'); log('environment: real Chromium (@sparticuz/chromium 153 + locally built NSS libs), backends NODE_ENV=test MEMORY_MODE=1 serving built dist');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const axeSource=fs.readFileSync(path.join(root,'tools-round3/node_modules/axe-core/axe.min.js'),'utf8');
const shotDir=path.join(root,'results/round3/screenshots'); fs.mkdirSync(shotDir,{recursive:true});
const apps=[
 {name:'dairy', dir:'dairy_farm/backend', port:19301, loginPath:'/api/auth/login', agri:false},
 {name:'agri', dir:'agri_farm/backend', port:19302, loginPath:'/api/login', agri:true},
 {name:'flock', dir:'flock_farm/backend', port:19303, loginPath:'/api/auth/login', agri:false},
];
const procs=[];
async function storageDump(page,label){
  const dump=await page.evaluate(async ()=>{
    const ls={}; for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i); ls[k]=String(localStorage.getItem(k)).slice(0,200)}
    const ss={}; for(let i=0;i<sessionStorage.length;i++){const k=sessionStorage.key(i); ss[k]=String(sessionStorage.getItem(k)).slice(0,200)}
    let idb=[]; try{ idb=(await indexedDB.databases()).map(d=>d.name) }catch{}
    let cacheKeys=[]; try{ cacheKeys=await caches.keys() }catch{}
    let sw=[]; try{ const regs=await navigator.serviceWorker.getRegistrations(); sw=regs.map(r=>r.scope) }catch{}
    return {localStorage:ls, sessionStorage:ss, indexedDB:idb, caches:cacheKeys, serviceWorkers:sw, cookie:document.cookie.slice(0,200)};
  });
  log(`${label} STORAGE: ${JSON.stringify(dump).slice(0,2500)}`);
  return dump;
}
try{
  let executablePath='/tmp/chromium'; let launchArgs=['--no-sandbox'];
  try{ const chr=require2('@sparticuz/chromium').default; executablePath=await chr.executablePath(); launchArgs=[...chr.args,'--no-sandbox']; log(`chromium executable=${executablePath}`);}catch(e){ log(`chromium module fallback: ${e.message}`); }
  let browser=null;
  log('browser will be launched per-app (single-process Chromium stability)');
  const allAxe={};
  for(const app of apps){
    log(`\n===== APP ${app.name} =====`);
    const proc=spawn(process.execPath,['server.js'],{cwd:path.join(root,app.dir),env:{...process.env,PORT:String(app.port),NODE_ENV:'test',MEMORY_MODE:'1',MONGO_URI:'',MONGODB_URI:'',JWT_SECRET:'[SECURITY_DATA]',DISABLE_INTERNAL_SCHEDULER:'1',LOG_REQUESTS:'0'},stdio:'ignore'});
    procs.push(proc); const base=`http://127.0.0.1:${app.port}`;
    // wait login works
    let token=''; for(let i=0;i<60&&!token;i++){ try{ const r=await fetch(base+app.loginPath,{method:'POST',headers:{'Content-Type':app.agri?'application/x-www-form-urlencoded':'application/json'},body:app.agri?new URLSearchParams({username:'admin',password:'admin123'}):JSON.stringify({username:'admin',password:'admin123'})}); const j=await r.json().catch(()=>({})); token=j.token||j.access_token||''; }catch{} if(!token) await sleep(400); }
    log(`${app.name} API login token=${token?'ok':'FAIL'}`);
    browser=await pwCore.chromium.launch({executablePath, args:launchArgs, headless:true});
    log(`${app.name} browser launched version=${browser.version()}`);
    const ctx=await browser.newContext({viewport:{width:1366,height:900}});
    const page=await ctx.newPage();
    const resp=await page.goto(base+'/',{waitUntil:'load',timeout:45000}).catch(e=>null);
    log(`${app.name} GET / -> ${resp?resp.status():'FAILED'} title=${await page.title().catch(()=>'' )}`);
    await page.screenshot({path:path.join(shotDir,`${app.name}-login-desktop.png`),timeout:8000}).catch(e=>log(`${app.name} login screenshot failed ${e.message.slice(0,80)}`));
    // login via UI: find username/password inputs
    const inputs=await page.locator('input').count();
    log(`${app.name} login page inputs=${inputs} bodyText=${(await page.locator('body').innerText().catch(()=>'' )).slice(0,300).replace(/\n/g,' | ')}`);
    try{
      const userInput=page.locator('input[type="text"], input:not([type]), input[type="email"]').first();
      const passInput=page.locator('input[type="password"]').first();
      await userInput.fill('admin'); await passInput.fill('admin123');
      await page.getByRole('button',{name:/login|sign in|لاگ|داخل/i}).first().click({timeout:5000}).catch(async()=>{ await page.locator('button[type="submit"], button').first().click(); });
      await page.waitForTimeout(3500);
    }catch(e){ log(`${app.name} UI login attempt error: ${e.message}`); }
    try{ await page.locator('button:has-text("Got it"), button:has-text("سمجھ گیا")').first().click({timeout:3000}); await page.waitForTimeout(800); log(`${app.name} dismissed What's-new modal`);}catch{ log(`${app.name} no What's-new modal to dismiss`); }
    const btnDump=await page.evaluate(()=>[...document.querySelectorAll('button, a')].map(e=>({t:e.innerText.trim().slice(0,40), a:e.getAttribute('aria-label')||''})).filter(x=>x.t||x.a).slice(0,60)).catch(()=>[]);
    log(`${app.name} buttons: ${JSON.stringify(btnDump).slice(0,1200)}`);
    const afterLoginText=(await page.locator('body').innerText().catch(()=>'' )).slice(0,400).replace(/\n/g,' | ');
    log(`${app.name} after-login text: ${afterLoginText}`);
    await page.screenshot({path:path.join(shotDir,`${app.name}-home-desktop-light-en.png`),timeout:8000}).catch(e=>log(`${app.name} home screenshot failed ${e.message.slice(0,80)}`));
    await storageDump(page,`${app.name} after-login`);
    // axe helper
    async function runAxe(label){
      await page.evaluate(axeSource).catch(()=>{});
      const res=await page.evaluate(async ()=>{ return await window.axe.run(document,{resultTypes:['violations']}); }).catch(e=>({violations:[],error:String(e)}));
      const v=(res.violations||[]).map(x=>({id:x.id,impact:x.impact,nodes:x.nodes.length}));
      allAxe[label]=v; log(`${app.name} AXE ${label}: violations=${v.length} ${JSON.stringify(v).slice(0,600)}`);
      return v;
    }
    await runAxe('home-desktop-light-en');
    // enumerate nav tabs/buttons
    const navTexts=await page.evaluate(()=>{ const els=[...document.querySelectorAll('nav button, nav a, header button, aside button, [role="tab"]')]; return [...new Set(els.map(e=>e.innerText.trim()).filter(t=>t&&t.length<40))].slice(0,30); }).catch(()=>[]);
    log(`${app.name} nav items: ${JSON.stringify(navTexts)}`);
    for(const t of navTexts.slice(0,14)){
      try{ const clicked=await page.evaluate((txt)=>{ const els=[...document.querySelectorAll('button, a, [role="tab"], li, div')]; const el=els.find(e=>e.innerText && e.innerText.trim()===txt && e.getBoundingClientRect().width>0); if(!el) return false; el.click(); return true; }, t); if(!clicked) throw new Error('text element not found'); await page.waitForTimeout(900); await runAxe(`tab:${t}`); }catch(e){ log(`${app.name} tab '${t}' click/axe failed: ${String(e.message).slice(0,120)}`); }
    }
    // overflow check desktop
    const overflow=await page.evaluate(()=>{ const bad=[]; document.querySelectorAll('*').forEach(el=>{ if(el.scrollWidth>el.clientWidth+2 && el.clientWidth>0){ const r=el.getBoundingClientRect(); if(r.width>0&&r.width<2000) bad.push(`${el.tagName}.${String(el.className).slice(0,40)} sw=${el.scrollWidth} cw=${el.clientWidth}`);} }); return bad.slice(0,8); }).catch(()=>[]);
    log(`${app.name} horizontal-overflow elements (desktop): ${JSON.stringify(overflow)}`);
    // dark mode toggle
    try{ const darkBtn=page.locator('button[aria-label*="theme" i], button[aria-label*="dark" i], button:has-text("🌙")').first(); await darkBtn.click({timeout:2500}); await page.waitForTimeout(700); await runAxe('home-dark'); await page.screenshot({path:path.join(shotDir,`${app.name}-home-desktop-dark-en.png`),timeout:8000}).catch(()=>{}); log(`${app.name} dark toggle clicked`);}catch(e){ log(`${app.name} dark toggle not found/clicked: ${String(e.message).slice(0,120)}`); }
    // Urdu toggle
    try{ const urBtn=page.locator('button[aria-label*="language" i], button:has-text("اردو")').first(); await urBtn.click({timeout:2500}); await page.waitForTimeout(900); const dir=await page.evaluate(()=>document.documentElement.dir||document.body.dir); await runAxe('home-ur-rtl'); await page.screenshot({path:path.join(shotDir,`${app.name}-home-desktop-light-ur.png`),timeout:8000}).catch(()=>{}); log(`${app.name} Urdu toggle clicked, html dir=${dir}`);}catch(e){ log(`${app.name} Urdu toggle not found/clicked: ${String(e.message).slice(0,120)}`); }
    // mobile viewport
    await page.setViewportSize({width:375,height:740}); await page.waitForTimeout(800);
    await runAxe('home-mobile');
    const mOverflow=await page.evaluate(()=>{ const bad=[]; document.querySelectorAll('*').forEach(el=>{ if(el.scrollWidth>el.clientWidth+2 && el.clientWidth>0){ const r=el.getBoundingClientRect(); if(r.width>300&&r.width<800) bad.push(`${el.tagName} sw=${el.scrollWidth} cw=${el.clientWidth}`);} }); return {bad:bad.slice(0,6), docSW:document.documentElement.scrollWidth, winIW:window.innerWidth}; }).catch(()=>({}));
    log(`${app.name} mobile overflow: ${JSON.stringify(mOverflow)}`);
    await page.screenshot({path:path.join(shotDir,`${app.name}-home-mobile.png`),timeout:8000}).catch(e=>log(`${app.name} mobile screenshot failed ${e.message.slice(0,80)}`));
    // modal check mobile: click first add/new button if present
    try{ const addBtn=page.locator('button:has-text("+"), button:has-text("Add"), button:has-text("New")').first(); await addBtn.click({timeout:2500}); await page.waitForTimeout(900); const modal=await page.evaluate(()=>{ const m=document.querySelector('[role="dialog"], .modal, dialog[open]'); if(!m) return 'no modal element'; const r=m.getBoundingClientRect(); return `modal rect top=${Math.round(r.top)} left=${Math.round(r.left)} width=${Math.round(r.width)} winH=${window.innerHeight}`; }); log(`${app.name} mobile modal: ${modal}`); await page.screenshot({path:path.join(shotDir,`${app.name}-modal-mobile.png`),timeout:8000}).catch(()=>{}); await page.keyboard.press('Escape').catch(()=>{}); }catch(e){ log(`${app.name} mobile modal probe: ${String(e.message).slice(0,120)}`); }
    await storageDump(page,`${app.name} before-logout`);
    // logout
    let loggedOut=false;
    try{ const loBtn=page.locator('button[aria-label*="logout" i], button:has-text("Logout"), a:has-text("Logout")').first(); await loBtn.click({timeout:3000}); await page.waitForTimeout(1200); loggedOut=true; }catch(e){ log(`${app.name} logout button not found directly: ${String(e.message).slice(0,100)}`);
      // try menus/avatars
      try{ await page.locator('header button').last().click({timeout:2000}); await page.waitForTimeout(600); await page.locator('button:has-text("Logout"), a:has-text("Logout")').first().click({timeout:2000}); await page.waitForTimeout(1200); loggedOut=true; }catch(e2){ log(`${app.name} logout via menu failed: ${String(e2.message).slice(0,100)}`); }
    }
    log(`${app.name} logout clicked=${loggedOut} url=${page.url()}`);
    await storageDump(page,`${app.name} after-logout`);
    const postLogoutText=(await page.locator('body').innerText().catch(()=>'' )).slice(0,250).replace(/\n/g,' | ');
    log(`${app.name} after-logout text: ${postLogoutText}`);
    await ctx.close(); await browser.close().catch(()=>{});
    proc.kill('SIGTERM'); await sleep(300); try{proc.kill('SIGKILL')}catch{}
  }
  fs.writeFileSync(path.join(root,'results/round3/phase3-axe-raw.json'), JSON.stringify({head, generated:'phase3-browser.mjs axe results by view label', results:allAxe},null,2));
} catch(e){ log(`FATAL ${e.stack||e}`); }
finally{ for(const p of procs){try{p.kill('SIGKILL')}catch{}} fs.writeFileSync(path.join(root,'results/round3/phase3-browser.txt'), out.join('\n')+'\n'); }
