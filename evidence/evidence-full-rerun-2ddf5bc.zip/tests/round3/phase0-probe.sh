#!/usr/bin/env bash
# Phase 0 environment/install probe. This script only records availability and
# installs testing tools outside application source directories.
set +e
mkdir -p results/round3 tools-round3
exec > >(tee results/round3/phase0-probes.txt) 2>&1

echo "=== identity ==="
date -Is
uname -a
cat /etc/os-release 2>/dev/null | head -5

echo "=== runtimes ==="
for c in node npm npx python3 pip pip3 java go rustc cargo docker podman mongod mongosh apt-get conda curl git jq; do
  printf "%-12s " "$c"
  if command -v "$c" >/dev/null 2>&1; then echo "$(command -v "$c")"; else echo "MISSING"; fi
done
node --version 2>&1
npm --version 2>&1
python3 --version 2>&1
pip --version 2>&1
java -version 2>&1 | head -3
go version 2>&1
rustc --version 2>&1
cargo --version 2>&1
docker --version 2>&1
mongod --version 2>&1 | head -3
mongosh --version 2>&1

echo "=== browsers already present ==="
for c in chromium chromium-browser google-chrome google-chrome-stable chrome firefox firefox-esr; do
  printf "%-24s " "$c"
  if command -v "$c" >/dev/null 2>&1; then echo "$(command -v "$c")"; else echo "MISSING"; fi
done
find /usr/bin /usr/local/bin /opt -maxdepth 4 -type f \( -iname '*chrom*' -o -iname '*firefox*' \) 2>/dev/null | head -30

echo "=== system package / container probes (short) ==="
timeout 20 apt-get --version 2>&1 | head -2
timeout 20 docker info 2>&1 | head -20
timeout 20 conda --version 2>&1

echo "=== Python tool installs ==="
python3 -m pip install --break-system-packages -q schemathesis hypothesis requests pyjwt njsscan detect-secrets locust osv-scanner 2>&1 | tail -30
echo "pip batch rc=$?"
for c in schemathesis njsscan detect-secrets locust osv-scanner; do
  printf "%-16s " "$c"
  if command -v "$c" >/dev/null 2>&1; then "$c" --version 2>&1 | head -1; else echo "MISSING"; fi
done
python3 - <<'PY'
for name in ["schemathesis", "hypothesis", "requests", "jwt"]:
    try:
        m = __import__(name)
        print(name, "OK", getattr(m, "__version__", "version unknown"))
    except Exception as e:
        print(name, "FAIL", repr(e))
PY

echo "=== semgrep ==="
python3 -m pip install --break-system-packages -q semgrep 2>&1 | tail -20
semgrep --version 2>&1

echo "=== npm tool installs (isolated tools-round3) ==="
mkdir -p tools-round3
cd tools-round3 || exit 1
[ -f package.json ] || npm init -y >/dev/null 2>&1
timeout 600 npm install --no-audit --no-fund \
  fast-check autocannon playwright-core @sparticuz/chromium puppeteer-core lighthouse \
  @stryker-mutator/core @stryker-mutator/vitest-runner \
  eslint eslint-plugin-security eslint-plugin-no-unsanitized eslint-plugin-n eslint-plugin-promise \
  eslint-plugin-react eslint-plugin-react-hooks eslint-plugin-jsx-a11y \
  @typescript-eslint/parser @typescript-eslint/eslint-plugin \
  retire depcheck knip madge html-validate wcag-contrast colorjs.io \
  @babel/parser @babel/traverse ts-morph msw jsdom @testing-library/react jest-axe axe-core @axe-core/playwright 2>&1 | tail -40
echo "npm tools rc=$?"
for x in autocannon eslint stryker retire depcheck knip madge lighthouse; do
  printf "%-16s " "$x"
  if [ -x "node_modules/.bin/$x" ]; then echo "OK node_modules/.bin/$x"; else echo "MISSING"; fi
done
cd ..

echo "=== GitHub tool clones ==="
mkdir -p tools-round3/src
for spec in \
  "jwt_tool https://github.com/ticarpi/jwt_tool" \
  "NoSQLMap https://github.com/codingo/NoSQLMap" \
  "semgrep-rules https://github.com/semgrep/semgrep-rules" \
  "gitleaks https://github.com/gitleaks/gitleaks" \
  "FerretDB https://github.com/FerretDB/FerretDB"; do
  set -- $spec
  name=$1; url=$2
  if [ -d "tools-round3/src/$name/.git" ]; then
    echo "$name already cloned"
  else
    echo "--- git clone $url"
    timeout 180 git clone --depth 1 "$url" "tools-round3/src/$name" 2>&1 | tail -3
    echo "$name clone rc=$?"
  fi
done

echo "=== gitleaks build attempt ==="
if command -v go >/dev/null 2>&1 && [ -d tools-round3/src/gitleaks ]; then
  (cd tools-round3/src/gitleaks && timeout 300 go build -o ../../gitleaks .) 2>&1 | tail -20
  ls -l tools-round3/gitleaks 2>&1
else
  echo "SKIP: go or gitleaks source unavailable"
fi

echo "=== mongodb options ==="
for spec in \
  "apt-mongodb timeout 30 apt-cache policy mongodb" \
  "apt-mongodb-org timeout 30 apt-cache policy mongodb-org" \
  "conda-mongodb timeout 30 conda search mongodb" \
  "npm-mongodb-memory-server npm view mongodb-memory-server version"; do
  echo "--- $spec"
  eval "$spec" 2>&1 | head -20
  echo "rc=$?"
done
python3 -m pip index versions mongod 2>&1 | head -10
python3 -m pip index versions mongodb 2>&1 | head -10

echo "=== @sparticuz/chromium executable probe ==="
cd tools-round3 || exit 1
node - <<'JS'
(async () => {
  try {
    const chromium = require('@sparticuz/chromium');
    console.log('version export keys', Object.keys(chromium));
    const p = await chromium.executablePath();
    console.log('executablePath', p);
    const fs = require('fs');
    console.log('exists', fs.existsSync(p));
  } catch (e) {
    console.log('FAIL', e && e.stack || e);
  }
})();
JS
cd ..

echo "=== disk/memory ==="
df -h . /tmp 2>&1
free -h 2>&1 || vm_stat 2>&1 | head
