EVIDENCE PACKAGE — Part 1 regression + Part 2 Cloudinary/photo audit
Tested upstream commit: 8a073965763a6a4a6cc2bae0a341508cac91b178 (branch muf-monorepo tip; 2 docs commits past 3a2ff45)

CONTENTS
  tests/api-deep/ (incl. NEW round12-photos-cloudinary.test.ts, round12-photos-flock.test.ts)
  tests/api-matrix/, tests/toolchain/ (fast-check included), tests/verification/
  e2e/toolchain-visual-a11y.spec.ts (not re-run: no browser in sandbox)
  results/ RAW outputs: api-matrix-and-toolchain.txt, api-deep.txt, upstream-own-suite.txt,
           contested-probes-output.txt, round12-photos.txt, round12-flock.txt, flock-upload-probes.txt

ENVIRONMENT: local, MEMORY_MODE=1 JWT_SECRET=[SECURITY_DATA] DISABLE_INTERNAL_SCHEDULER=1 NODE_ENV=test,
no FRONTEND_URL/CORS_ORIGIN, no real CLOUDINARY_* (fallback mode) except the fake-config test in round12.

COMMANDS
  npm install (root, incl. devDeps vitest + fast-check) and in each app dir
  npx vitest run tests/api-matrix tests/toolchain
  npx vitest run tests/api-deep
  npx vitest run tests/api-deep/round12-photos-cloudinary.test.ts tests/api-deep/round12-photos-flock.test.ts
  bash tests/verification/contested-probes.sh
