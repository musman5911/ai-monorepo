/**
 * TOOLCHAIN security scan (OWASP-ZAP substitute: ZAP needs a
 * JVM, unavailable in this sandbox; these are the ZAP baseline
 * check classes automated): security headers, CORS reflection,
 * cache directives, banner disclosure, public-data exposure.
 * NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { raw, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const apps: Record<string, Ctx> = {};
const names = ['dairy', 'flock', 'agri'] as const;
const dirs: Record<string, string> = { dairy: 'dairy_farm/backend', flock: 'flock_farm/backend', agri: 'agri_farm/backend' };

describe.sequential('TOOLCHAIN security scan', () => {
  beforeAll(async () => { for (const n of names) apps[n] = await startApp(n, dirs[n]); }, 240_000);
  afterAll(async () => { for (const c of Object.values(apps)) await stopApp(c); }, 60_000);

  for (const n of names) {
    it(`${n}: API responses carry CSP + nosniff + frame protection`, async () => {
      const r = await raw(apps[n], '/farms', { token: apps[n].owner });
      const h = r.response.headers;
      expect(h.get('content-security-policy'), 'missing CSP').toBeTruthy();
      expect(h.get('x-content-type-options'), 'missing nosniff').toBe('nosniff');
      const frame = h.get('x-frame-options') || h.get('content-security-policy') || '';
      expect(frame, 'missing frame protection').toMatch(/DENY|SAMEORIGIN|frame-ancestors/i);
    });

    it(`${n}: authenticated responses are non-cacheable`, async () => {
      const r = await raw(apps[n], '/farms', { token: apps[n].owner });
      expect(r.response.headers.get('cache-control') || '', 'auth response cacheable').toMatch(/no-store|private/i);
    });

    it(`${n}: CORS does not reflect arbitrary origins with credentials`, async () => {
      const res = await fetch(`${apps[n].base}/api/farms`, { headers: { Authorization: `Bearer ${apps[n].owner}`, Origin: 'https://evil.example.com' } });
      const acao = res.headers.get('access-control-allow-origin');
      const acac = res.headers.get('access-control-allow-credentials');
      expect(acao === 'https://evil.example.com' && acac === 'true', `CORS reflects evil origin with credentials (acao=${acao} acac=${acac})`).toBe(false);
    });

    it(`${n}: no framework banner (X-Powered-By / Server version)`, async () => {
      const r = await raw(apps[n], '/farms', { token: apps[n].owner });
      expect(r.response.headers.get('x-powered-by'), 'X-Powered-By disclosed').toBeNull();
    });
  }

  it('dairy: public surfaces do not expose GPS coordinates or buyer phone numbers', async () => {
    const farms = await fetch(`${apps.dairy.base}/api/farms/public`).then(r => r.text()).catch(() => '');
    expect(farms, 'public farms payload contains coordinates').not.toMatch(/latitude|longitude|"lat"|"lng"/i);
    const cards = await raw(apps.dairy, '/cards/buyer/public', {});
    expect(JSON.stringify(cards.data || ''), 'public buyer card contains a phone').not.toMatch(/03\d{2}-?\d{7}|phone/i);
  });

  it('flock: image bytes are not served to anonymous callers', async () => {
    const r = await fetch(`${apps.flock.base}/api/images/000000000000000000000000`);
    expect([401, 403, 404], `anon image → ${r.status}`).toContain(r.status);
  });
});
