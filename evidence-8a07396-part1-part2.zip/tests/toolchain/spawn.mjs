// Spawn one app backend in memory mode on a given port (same env as harness).
import { spawn } from 'node:child_process';
const [dir, port] = process.argv.slice(2);
const proc = spawn(process.execPath, ['server.js'], {
  cwd: dir,
  env: { ...process.env, PORT: String(port), NODE_ENV: 'test', MEMORY_MODE: '1', MONGO_URI: '', MONGODB_URI: '', JWT_SECRET: 'testingcake987', TELEGRAM_BOT_TOKEN: '', DISABLE_INTERNAL_SCHEDULER: '1', LOG_REQUESTS: '0' },
  stdio: 'inherit',
});
process.on('SIGTERM', () => proc.kill('SIGTERM'));
