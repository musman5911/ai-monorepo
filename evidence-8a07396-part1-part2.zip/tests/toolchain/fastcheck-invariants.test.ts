/**
 * TOOLCHAIN: fast-check property invariants (API-driven).
 * Properties state laws that must hold for ALL generated
 * inputs; fast-check shrinks failures to minimal cases.
 * NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import fc from 'fast-check';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

describe.sequential('TOOLCHAIN fast-check invariants', () => {
  let agri: Ctx; let flock: Ctx; let dairy: Ctx;
  beforeAll(async () => {
    agri = await startApp('agri', 'agri_farm/backend');
    flock = await startApp('flock', 'flock_farm/backend');
    dairy = await startApp('dairy', 'dairy_farm/backend');
  }, 240_000);
  afterAll(async () => { await stopApp(agri); await stopApp(flock); await stopApp(dairy); }, 60_000);

  it('P1: agri inventory quantity is never negative after any PUT quantity', async () => {
    const c = await raw(agri, '/inventory', { method: 'POST', token: agri.owner, body: { name: `FC Inv ${S}`, quantity: 10, unit: 'bags' } });
    const itemId = idOf(c.data);
    expect(itemId).toBeTruthy();
    await fc.assert(fc.asyncProperty(fc.integer({ min: -100000, max: 100000 }), async (q) => {
      await raw(agri, `/inventory/${itemId}`, { method: 'PUT', token: agri.owner, body: { quantity: q } });
      const list = await raw(agri, '/inventory', { token: agri.owner });
      const row = (Array.isArray(list.data) ? list.data : []).find((r: any) => String(r._id) === itemId);
      expect(Number(row?.quantity), `quantity became ${row?.quantity} after PUT ${q}`).toBeGreaterThanOrEqual(0);
    }), { numRuns: 15 });
  });

  it('P2: agri liability amount_owed is never negative after any create amount', async () => {
    await fc.assert(fc.asyncProperty(fc.integer({ min: -100000, max: 100000 }), async (amt) => {
      const c = await raw(agri, '/liabilities', { method: 'POST', token: agri.owner, body: { creditor: `FC Cred ${S}`, amount_owed: amt } });
      if (c.response.status === 201) {
        const list = await raw(agri, '/liabilities', { token: agri.owner });
        const row = (Array.isArray(list.data) ? list.data : []).find((r: any) => String(r._id) === idOf(c.data));
        expect(Number(row?.amount_owed), `negative liability ${row?.amount_owed} stored`).toBeGreaterThanOrEqual(0);
      } else {
        expect([400, 422]).toContain(c.response.status);
      }
    }), { numRuns: 10 });
  });

  it('P3: flock live_count never goes negative under random mortality/sales sequences', async () => {
    const b = await raw(flock, '/batches', { method: 'POST', token: flock.owner, body: { name: `FC Batch ${S}`, type: 'Broiler', start_date: '2026-09-01', intake_count: 50, cost_per_bird: 5 } });
    const batchId = String((b.data as any)?.batch?.batch_id || (b.data as any)?.batch_id || idOf(b.data));
    expect(batchId).toBeTruthy();
    await fc.assert(fc.asyncProperty(fc.array(fc.record({ kind: fc.constantFrom('mortality', 'sales'), count: fc.integer({ min: 1, max: 60 }) }), { minLength: 1, maxLength: 6 }), async (ops) => {
      for (const op of ops) {
        const route = op.kind === 'mortality' ? 'mortality-logs' : 'sales-logs';
        const body = op.kind === 'mortality' ? { date: '2026-10-01', count: op.count, cause: 'fc' } : { date: '2026-10-01', count: op.count, buyer_name: 'fc', price_per_bird: 10 };
        await raw(flock, `/batches/${batchId}/${route}`, { method: 'POST', token: flock.owner, body });
      }
      const after = await raw(flock, `/batches/${batchId}`, { token: flock.owner });
      const live = Number((after.data as any)?.batch?.summary?.live_count ?? (after.data as any)?.summary?.live_count);
      if (Number.isFinite(live)) expect(live, `live_count went negative (${live})`).toBeGreaterThanOrEqual(0);
    }), { numRuns: 6 });
  });

  it('P4: malformed agri crop payloads never produce 500', async () => {
    const junk = fc.record({
      name: fc.oneof(fc.string(), fc.integer(), fc.constant(null), fc.constant({})),
      area_kanal: fc.oneof(fc.double(), fc.string(), fc.constant(null)),
      status: fc.string(),
      plant_date: fc.string(),
    });
    await fc.assert(fc.asyncProperty(junk, async (body) => {
      const r = await raw(agri, '/crops', { method: 'POST', token: agri.owner, body });
      expect(r.response.status, `500 on ${JSON.stringify(body).slice(0, 80)}`).toBeLessThan(500);
    }), { numRuns: 20 });
  });

  it('P5: dairy milk daily total equals morning + evening for the cow-day record', async () => {
    const cow = await raw(dairy, '/cows', { method: 'POST', token: dairy.owner, body: { name: `FC Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    const cowId = idOf(cow.data);
    const mk = await raw(dairy, '/milk', { method: 'POST', token: dairy.owner, body: { cowId, date: '2028-01-05', morning: 10.5, evening: 13 } });
    expect(mk.response.status, `milk create ${JSON.stringify(mk.data).slice(0, 100)}`).toBe(201);
    const dup = await raw(dairy, '/milk', { method: 'POST', token: dairy.owner, body: { cowId, date: '2028-01-05', morning: 1, evening: 1 } });
    expect([400, 409], `duplicate cow-day milk → ${dup.response.status}`).toContain(dup.response.status);
    const list = await raw(dairy, '/milk?limit=100', { token: dairy.owner });
    const rows = Array.isArray(list.data) ? list.data : (list.data?.items || list.data?.rows || []);
    const mine = rows.filter((r: any) => JSON.stringify(r).includes(cowId));
    const sum = mine.reduce((a: number, r: any) => a + Number(r.morning || 0) + Number(r.evening || 0), 0);
    expect(Math.abs(sum - 23.5), `milk entries sum ${sum} != 23.5`).toBeLessThan(0.001);
});
});
