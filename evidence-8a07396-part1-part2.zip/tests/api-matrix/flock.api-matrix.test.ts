/**
 * Flock backend — API field-matrix (NO app fixes; failures = findings).
 * Batches (full CRUD + field matrix), every batch log kind (create,
 * field validation, delete, closed-batch guards) and /data buckets
 * (valid round-trip vs wrong-type values).
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, rowsOf, S, startApp, stopApp, type Ctx } from './harness';

let ctx: Ctx;
let batchId = '';

/** Flock batches are addressed by their slug batch_id, not Mongo _id. */
const flockId = (data: any) => String(data?.batch?.batch_id || data?.batch_id || idOf(data));
const logIdOf = (data: any) => String(data?.log?._id || data?.log?.id || idOf(data));

const LONG = 'x'.repeat(10_000);
const SCRIPT = '<script>alert(1)</script>';

describe.sequential('Flock API field matrix', () => {
  beforeAll(async () => { ctx = await startApp('flock', 'flock_farm/backend'); }, 120_000);
  afterAll(async () => { await stopApp(ctx); }, 30_000);

  describe('batches', () => {
    const valid = () => ({ name: `Matrix Batch ${S}`, type: 'Broiler', start_date: '2026-09-01', intake_count: 500, source: 'Matrix hatchery', cost_per_bird: 120 });

    it('full CRUD: create → read → update → delete → 404', async () => {
      const created = await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, body: valid() });
      expect(created.response.status).toBe(201);
      const id = flockId(created.data);
      expect(id).toBeTruthy();
      const one = await raw(ctx, `/batches/${id}`, { token: ctx.owner });
      expect(one.response.status).toBe(200);
      const patched = await raw(ctx, `/batches/${id}`, { method: 'PATCH', token: ctx.owner, body: { name: `Matrix Batch Renamed ${S}` } });
      expect(patched.response.status).toBe(200);
      const after = await raw(ctx, `/batches/${id}`, { token: ctx.owner });
      expect(String(after.data.name || after.data.batch?.name)).toContain('Renamed');
      const del = await raw(ctx, `/batches/${id}`, { method: 'DELETE', token: ctx.owner });
      expect(del.response.status).toBe(200);
      expect((await raw(ctx, `/batches/${id}`, { token: ctx.owner })).response.status).toBe(404);
      expect((await raw(ctx, `/batches/${id}`, { method: 'DELETE', token: ctx.owner })).response.status, 'double-delete').toBe(404);
    });

    it('rejects empty/missing/bad-enum/negative/huge/oversized input', async () => {
      expect((await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, body: {} })).response.status).toBe(400);
      for (const field of ['name', 'type', 'start_date']) {
        const body: any = valid(); delete body[field];
        expect((await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, body })).response.status, `missing ${field}`).toBe(400);
      }
      expect((await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, body: { ...valid(), type: 'Alien' } })).response.status, 'bad type enum').toBe(400);
      expect((await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, body: { ...valid(), start_date: '01/09/2026' } })).response.status, 'bad date').toBe(400);
      expect((await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, body: { ...valid(), intake_count: -10 } })).response.status, 'negative intake').toBe(400);
      expect((await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, body: { ...valid(), intake_count: 'many' } })).response.status, 'string intake').toBe(400);
      expect((await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, body: { ...valid(), cost_per_bird: 1e15 } })).response.status, 'huge cost').toBe(400);
      expect((await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, body: { ...valid(), name: LONG } })).response.status, '10k name').toBe(400);
    });

    it('does not store script payloads verbatim; auth policy', async () => {
      const created = await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, body: { ...valid(), name: SCRIPT } });
      if (created.response.status === 201) {
        const id = flockId(created.data);
        const one = await raw(ctx, `/batches/${id}`, { token: ctx.owner });
        expect(String(one.data.name || ''), 'batch name stores <script> verbatim').not.toContain('<script>');
        await raw(ctx, `/batches/${id}`, { method: 'DELETE', token: ctx.owner });
      } else expect(created.response.status).toBe(400);

      expect((await raw(ctx, '/batches', { method: 'POST', body: valid() })).response.status).toBe(401);
      const worker = await raw(ctx, '/batches', { method: 'POST', token: ctx.worker, body: valid() });
      expect(worker.response.status, 'worker create batch').toBe(403);
      if (worker.response.status === 201) await raw(ctx, `/batches/${flockId(worker.data)}`, { method: 'DELETE', token: ctx.owner });
    });

    it('update validation: PATCH rejects bad enum / negative numbers', async () => {
      const created = await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, body: valid() });
      const id = flockId(created.data);
      batchId = id;
      expect((await raw(ctx, `/batches/${id}`, { method: 'PATCH', token: ctx.owner, body: { type: 'Alien' } })).response.status).toBe(400);
      expect((await raw(ctx, `/batches/${id}`, { method: 'PATCH', token: ctx.owner, body: { intake_count: -1 } })).response.status).toBe(400);
      expect((await raw(ctx, '/batches/nope', { token: ctx.owner })).response.status).toBe(404);
    });
  });

  describe('batch logs (all kinds)', () => {
    const kinds: Array<{ kind: string; path: string; body: any; badPatch: any }> = [
      { kind: 'feed', path: 'feed-logs', body: { date: '2026-09-05', feed_type: 'Starter', quantity_kg: 25, rate_rs_per_kg: 200 }, badPatch: { quantity_kg: -2 } },
      { kind: 'mortality', path: 'mortality-logs', body: { date: '2026-09-05', count: 3, reason: `matrix ${S}` }, badPatch: { count: -1 } },
      { kind: 'expense', path: 'expense-logs', body: { date: '2026-09-05', category: 'Medicine', detail: `matrix expense ${S}`, amount: 1500 }, badPatch: { amount: -100 } },
      { kind: 'sale', path: 'sales-logs', body: { date: '2026-09-06', count: 10, rate_per_bird: 900 }, badPatch: { count: -4 } },
      { kind: 'egg', path: 'egg-logs', body: { date: '2026-09-06', collected: 120, broken: 5 }, badPatch: { collected: -9 } },
      { kind: 'weight', path: 'weight-logs', body: { date: '2026-09-06', avg_weight_g: 1800, sample_size: 20 }, badPatch: { avg_weight_g: -1 } },
      { kind: 'vaccination', path: 'vaccination-logs', body: { date: '2026-09-06', vaccine_name: `matrix vacc ${S}`, count: 100 }, badPatch: { count: -2 } },
    ];

    for (const k of kinds) {
      it(`${k.kind}: create → invalid rejected → delete → gone`, async () => {
        const created = await raw(ctx, `/batches/${batchId}/${k.path}`, { method: 'POST', token: ctx.owner, body: k.body });
        expect(created.response.status, `create ${k.kind} log`).toBe(201);
        const logId = logIdOf(created.data);
        expect(logId).toBeTruthy();
        const bad = await raw(ctx, `/batches/${batchId}/${k.path}`, { method: 'POST', token: ctx.owner, body: { ...k.body, ...k.badPatch } });
        expect(bad.response.status, `${k.kind} negative value`).toBe(400);
        const empty = await raw(ctx, `/batches/${batchId}/${k.path}`, { method: 'POST', token: ctx.owner, body: {} });
        expect(empty.response.status, `${k.kind} empty body`).toBe(400);
        const del = await raw(ctx, `/batches/logs/${k.kind}/${logId}`, { method: 'DELETE', token: ctx.owner });
        expect(del.response.status, `delete ${k.kind} log`).toBe(200);
        const delAgain = await raw(ctx, `/batches/logs/${k.kind}/${logId}`, { method: 'DELETE', token: ctx.owner });
        expect(delAgain.response.status, `double-delete ${k.kind} log`).toBe(404);
      });
    }

    it('logs on a nonexistent batch are rejected', async () => {
      const r = await raw(ctx, '/batches/no-such-batch/feed-logs', { method: 'POST', token: ctx.owner, body: { date: '2026-09-05', feed_type: 'Starter', quantity_kg: 5, rate_rs_per_kg: 100 } });
      expect(r.response.status).not.toBe(201);
      expect([400, 404]).toContain(r.response.status);
    });

    it('intake adds birds; closed batch rejects new logs', async () => {
      const before = await raw(ctx, `/batches/${batchId}`, { token: ctx.owner });
      const beforeCount = Number(before.data.intake_count ?? before.data.batch?.intake_count ?? 0);
      const intake = await raw(ctx, `/batches/${batchId}/intake`, { method: 'POST', token: ctx.owner, body: { date: '2026-09-07', count: 50, rate_per_bird: 130 } });
      expect([200, 201]).toContain(intake.response.status);
      const after = await raw(ctx, `/batches/${batchId}`, { token: ctx.owner });
      expect(Number(after.data.intake_count ?? after.data.batch?.intake_count ?? 0)).toBe(beforeCount + 50);
      const badIntake = await raw(ctx, `/batches/${batchId}/intake`, { method: 'POST', token: ctx.owner, body: { date: '2026-09-07', count: -10 } });
      expect(badIntake.response.status, 'negative intake').toBe(400);

      const close = await raw(ctx, `/batches/${batchId}/close`, { method: 'PATCH', token: ctx.owner, body: {} });
      expect([200, 201]).toContain(close.response.status);
      const late = await raw(ctx, `/batches/${batchId}/feed-logs`, { method: 'POST', token: ctx.owner, body: { date: '2026-09-08', feed_type: 'Starter', quantity_kg: 5, rate_rs_per_kg: 100 } });
      expect(late.response.status, 'feed log on closed batch').toBe(400);
    });
  });

  describe('/data buckets', () => {
    for (const key of ['birds', 'eggs', 'feed', 'settings', 'diary']) {
      it(`${key}: round-trip works; wrong-type value rejected`, async () => {
        const read = await raw(ctx, `/data/${key}`, { token: ctx.owner });
        expect(read.response.status).toBe(200);
        const put = await raw(ctx, `/data/${key}`, { method: 'PUT', token: ctx.owner, body: { value: read.data.value, baseVersion: read.data.version ?? 0 } });
        expect(put.response.status, `valid PUT ${key}`).toBe(200);
        const wrong = await raw(ctx, `/data/${key}`, { method: 'PUT', token: ctx.owner, body: { value: 'a-plain-string', baseVersion: (read.data.version ?? 0) + 1 } });
        expect(wrong.response.status, `${key} accepts plain-string value`).toBe(400);
        // restore whatever the wrong-type write may have landed
        const now = await raw(ctx, `/data/${key}`, { token: ctx.owner });
        await raw(ctx, `/data/${key}`, { method: 'PUT', token: ctx.owner, body: { value: read.data.value, baseVersion: now.data.version ?? 0 } });
      });
    }

    it('unknown bucket keys are rejected; worker cannot write settings', async () => {
      expect((await raw(ctx, '/data/not-a-real-key', { token: ctx.owner })).response.status).toBe(400);
      const read = await raw(ctx, '/data/settings', { token: ctx.owner });
      const put = await raw(ctx, '/data/settings', { method: 'PUT', token: ctx.worker, body: { value: read.data.value, baseVersion: read.data.version ?? 0 } });
      expect(put.response.status).toBe(403);
    });

    it('stale-version writes conflict (409)', async () => {
      const read = await raw(ctx, '/data/birds', { token: ctx.owner });
      const v = read.data.version ?? 0;
      const ok = await raw(ctx, '/data/birds', { method: 'PUT', token: ctx.owner, body: { value: read.data.value, baseVersion: v } });
      expect(ok.response.status).toBe(200);
      const stale = await raw(ctx, '/data/birds', { method: 'PUT', token: ctx.owner, body: { value: read.data.value, baseVersion: v } });
      expect(stale.response.status).toBe(409);
    });
  });

  it('batch counts in list reflect create/delete', async () => {
    const before = rowsOf((await raw(ctx, '/batches', { token: ctx.owner })).data).length;
    const created = await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, body: { name: `Count Batch ${S}`, type: 'Layer', start_date: '2026-09-02', intake_count: 10, cost_per_bird: 50 } });
    const id = flockId(created.data);
    expect(rowsOf((await raw(ctx, '/batches', { token: ctx.owner })).data).length).toBe(before + 1);
    await raw(ctx, `/batches/${id}`, { method: 'DELETE', token: ctx.owner });
    expect(rowsOf((await raw(ctx, '/batches', { token: ctx.owner })).data).length).toBe(before);
  });
});
