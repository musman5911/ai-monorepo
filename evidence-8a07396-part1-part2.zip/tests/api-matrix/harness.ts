import { spawn } from 'node:child_process';
import { createServer } from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
export const S = `mx${Date.now().toString(36)}`;

async function reservePort() {
  const server = createServer();
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  const port = (server.address() as { port: number }).port;
  await new Promise((resolve, reject) => server.close((e) => (e ? reject(e) : resolve(undefined))));
  return port;
}

export interface Ctx { base: string; proc: ReturnType<typeof spawn>; owner: string; worker: string }

export async function raw(ctx: { base: string }, route: string, { method = 'GET', token, body, farmId, form }: any = {}) {
  const headers: Record<string, string> = {};
  if (token) headers.Authorization = `Bearer ${token}`;
  if (farmId) headers['X-Farm-Id'] = farmId;
  let payload: any;
  if (form) { headers['Content-Type'] = 'application/x-www-form-urlencoded'; payload = new URLSearchParams(form); }
  else if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  const response = await fetch(`${ctx.base}/api${route}`, { method, headers, body: payload });
  const text = await response.text();
  let data: any = null; try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  return { response, data };
}

async function login(name: string, ctx: { base: string }, u: string, p: string) {
  const r = name === 'agri'
    ? await raw(ctx, '/login', { method: 'POST', form: { username: u, password: p } })
    : await raw(ctx, '/auth/login', { method: 'POST', body: { username: u, password: p } });
  if (r.response.status !== 200) throw new Error(`${name} login ${u}: ${r.response.status}`);
  return r.data?.token || r.data?.access_token;
}

export async function startApp(name: string, dir: string): Promise<Ctx> {
  const port = await reservePort();
  const base = `http://127.0.0.1:${port}`;
  const proc = spawn(process.execPath, ['server.js'], {
    cwd: path.join(repoRoot, dir),
    env: { ...process.env, PORT: String(port), NODE_ENV: 'test', MEMORY_MODE: '1', MONGO_URI: '', MONGODB_URI: '', JWT_SECRET: '[SECURITY_DATA]', TELEGRAM_BOT_TOKEN: '', DISABLE_INTERNAL_SCHEDULER: '1', LOG_REQUESTS: '0' },
    stdio: 'ignore',
  });
  const ctx: Ctx = { base, proc, owner: '', worker: '' };
  const deadline = Date.now() + 40_000;
  for (;;) {
    if (proc.exitCode !== null) throw new Error(`${name} exited ${proc.exitCode}`);
    try { const r = await fetch(`${base}/api/farms`); if (r.status === 401 || r.status === 200) break; } catch { /* wait */ }
    if (Date.now() > deadline) throw new Error(`${name} not ready`);
    await new Promise((r) => setTimeout(r, 300));
  }
  ctx.owner = await login(name, ctx, 'admin', 'admin123');
  ctx.worker = await login(name, ctx, 'worker', 'worker123');
  return ctx;
}

export async function stopApp(ctx: Ctx) {
  if (ctx.proc.exitCode === null) {
    ctx.proc.kill('SIGTERM');
    await new Promise((r) => setTimeout(r, 300));
    if (ctx.proc.exitCode === null) ctx.proc.kill('SIGKILL');
  }
}

/** Extract the created record's id across the apps' response shapes. */
export function idOf(data: any): string {
  const rec = data?.record || data?.item || data?.crop || data?.batch || data?.task || data;
  return String(rec?._id || rec?.id || rec?.batch_id || '');
}

/** Rows from any list response shape. */
export function rowsOf(data: any): any[] {
  if (Array.isArray(data)) return data;
  for (const key of ['items', 'data', 'rows', 'results', 'batches', 'crops', 'records']) {
    if (Array.isArray(data?.[key])) return data[key];
  }
  return [];
}
