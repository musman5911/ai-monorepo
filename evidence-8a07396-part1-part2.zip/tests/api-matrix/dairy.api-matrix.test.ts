/**
 * Dairy backend — API field-matrix (NO app fixes; failures = findings).
 * For every resource: full CRUD plus a per-field invalid-input matrix
 * (missing/empty/wrong-type/negative/bad-enum/bad-date/huge/oversized/
 * script payloads). Expected behaviour: writes validate and reject
 * bad input with 400, deletes remove, reads-after-delete 404.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, rowsOf, S, startApp, stopApp, type Ctx } from './harness';

let ctx: Ctx;
let cowId = '';

interface Res {
  name: string;
  base: string;
  valid: () => Record<string, any>;
  required: string[];
  update: Record<string, any>;
  numeric: string[];
  workerCreate?: number; // expected status for worker create (default 403)
  workerValid?: () => Record<string, any>; // distinct body avoiding unique clashes
}

const LONG = 'x'.repeat(10_000);
const SCRIPT = '<script>alert(1)</script>';

function resources(): Res[] {
  return [
    {
      name: 'cows', base: '/cows',
      valid: () => ({ name: `Matrix Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active', ageYears: 4, weight: 320, purchasePrice: 150000 }),
      required: ['name', 'breed'], update: { name: `Matrix Cow Renamed ${S}` }, numeric: ['ageYears', 'weight', 'purchasePrice'],
    },
    {
      name: 'milk', base: '/milk',
      valid: () => ({ cowId, date: '2026-09-03', morning: 6, evening: 5 }),
      required: ['cowId', 'date'], update: { morning: 9 }, numeric: ['morning', 'evening'], workerCreate: 201,
      workerValid: () => ({ cowId, date: '2026-09-21', morning: 3, evening: 3 }),
    },
    {
      name: 'expenses', base: '/expenses',
      valid: () => ({ date: '2026-09-04', type: 'feed', amount: 4500, note: `matrix ${S}` }),
      required: ['amount'], update: { amount: 5200 }, numeric: ['amount'], workerCreate: 201,
    },
    {
      name: 'health', base: '/health',
      valid: () => ({ cowId, date: '2026-09-05', type: 'vaccination', description: `matrix vacc ${S}`, cost: 700 }),
      required: ['cowId', 'date'], update: { cost: 950 }, numeric: ['cost'], workerCreate: 201,
    },
    {
      name: 'buyers', base: '/buyers',
      valid: () => ({ name: `Matrix Buyer ${S}`, phone: '03001112223' }),
      required: ['name'], update: { name: `Matrix Buyer Renamed ${S}` }, numeric: [],
    },
    {
      name: 'suppliers', base: '/suppliers',
      valid: () => ({ name: `Matrix Supplier ${S}`, phone: '03001112224' }),
      required: ['name'], update: { name: `Matrix Supplier Renamed ${S}` }, numeric: [],
    },
    {
      name: 'labor workers', base: '/labor/workers',
      valid: () => ({ name: `Matrix Worker ${S}`, dailyWage: 1000 }),
      required: ['name'], update: { name: `Matrix Worker ${S}`, dailyWage: 1200 }, numeric: ['dailyWage'],
    },
  ];
}

describe.sequential('Dairy API field matrix', () => {
  beforeAll(async () => {
    ctx = await startApp('dairy', 'dairy_farm/backend');
    const cow = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { name: `Matrix Host Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    cowId = idOf(cow.data);
    expect(cowId).toBeTruthy();
  }, 120_000);
  afterAll(async () => { await stopApp(ctx); }, 30_000);

  for (const res of resources()) {
    describe(res.name, () => {
      it('full CRUD: create → read → update → delete → 404', async () => {
        const created = await raw(ctx, res.base, { method: 'POST', token: ctx.owner, body: res.valid() });
        expect(created.response.status, `create ${res.name}`).toBe(201);
        const id = idOf(created.data);
        expect(id, `id for ${res.name}`).toBeTruthy();

        const one = await raw(ctx, `${res.base}/${id}`, { token: ctx.owner });
        expect([200, 404]).toContain(one.response.status); // some resources are list-only
        if (one.response.status === 200) expect(String(one.data._id || one.data.id)).toBe(id);

        const updated = await raw(ctx, `${res.base}/${id}`, { method: 'PUT', token: ctx.owner, body: res.update });
        expect(updated.response.status, `update ${res.name}`).toBe(200);
        const [field, value] = Object.entries(res.update)[0];
        const afterOne = await raw(ctx, `${res.base}/${id}`, { token: ctx.owner });
        if (afterOne.response.status === 200) expect(String(afterOne.data[field])).toBe(String(value));

        const list = await raw(ctx, `${res.base}?limit=500`, { token: ctx.owner });
        expect(list.response.status).toBe(200);

        const del = await raw(ctx, `${res.base}/${id}`, { method: 'DELETE', token: ctx.owner });
        expect(del.response.status, `delete ${res.name}`).toBe(200);
        const gone = await raw(ctx, `${res.base}/${id}`, { token: ctx.owner });
        expect(gone.response.status, `read-after-delete ${res.name}`).toBe(404);
        const delAgain = await raw(ctx, `${res.base}/${id}`, { method: 'DELETE', token: ctx.owner });
        expect(delAgain.response.status, `double-delete ${res.name}`).toBe(404);
      });

      it('rejects empty body and missing required fields', async () => {
        expect((await raw(ctx, res.base, { method: 'POST', token: ctx.owner, body: {} })).response.status).toBe(400);
        for (const field of res.required) {
          const body = res.valid();
          delete body[field];
          const r = await raw(ctx, res.base, { method: 'POST', token: ctx.owner, body });
          expect(r.response.status, `${res.name} missing ${field}`).toBe(400);
        }
      });

      it('rejects negative and non-numeric numbers', async () => {
        for (const field of res.numeric) {
          const neg = await raw(ctx, res.base, { method: 'POST', token: ctx.owner, body: { ...res.valid(), [field]: -5 } });
          expect(neg.response.status, `${res.name}.${field} negative`).toBe(400);
          const str = await raw(ctx, res.base, { method: 'POST', token: ctx.owner, body: { ...res.valid(), [field]: 'abc' } });
          expect(str.response.status, `${res.name}.${field} string`).toBe(400);
        }
      });

      it('rejects huge numbers and oversized strings', async () => {
        for (const field of res.numeric) {
          const huge = await raw(ctx, res.base, { method: 'POST', token: ctx.owner, body: { ...res.valid(), [field]: 1e15 } });
          expect(huge.response.status, `${res.name}.${field} huge`).toBe(400);
        }
        const textField = res.required.find((f) => typeof res.valid()[f] === 'string');
        if (textField) {
          const long = await raw(ctx, res.base, { method: 'POST', token: ctx.owner, body: { ...res.valid(), [textField]: LONG } });
          expect(long.response.status, `${res.name}.${textField} 10k chars`).toBe(400);
        }
      });

      it('does not store script payloads verbatim', async () => {
        const textField = res.required.find((f) => typeof res.valid()[f] === 'string');
        if (!textField) return;
        const created = await raw(ctx, res.base, { method: 'POST', token: ctx.owner, body: { ...res.valid(), [textField]: SCRIPT } });
        if (created.response.status === 201) {
          const id = idOf(created.data);
          const one = await raw(ctx, `${res.base}/${id}`, { token: ctx.owner });
          const stored = String(one.data?.[textField] ?? created.data?.[textField] ?? '');
          expect(stored, `${res.name}.${textField} stores <script> verbatim`).not.toContain('<script>');
          await raw(ctx, `${res.base}/${id}`, { method: 'DELETE', token: ctx.owner });
        } else {
          expect(created.response.status).toBe(400);
        }
      });

      it('rejects unauthenticated writes; worker create policy', async () => {
        const anon = await raw(ctx, res.base, { method: 'POST', body: res.valid() });
        expect(anon.response.status, `${res.name} anon create`).toBe(401);
        const worker = await raw(ctx, res.base, { method: 'POST', token: ctx.worker, body: res.workerValid ? res.workerValid() : res.valid() });
        expect(worker.response.status, `${res.name} worker create`).toBe(res.workerCreate ?? 403);
        if (worker.response.status === 201) {
          await raw(ctx, `${res.base}/${idOf(worker.data)}`, { method: 'DELETE', token: ctx.owner });
        }
      });
    });
  }

  it('cows: rejects bad enums and bad dates on create AND update', async () => {
    const base = { name: `Enum Cow ${S}`, breed: 'Jersey' };
    expect((await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { ...base, gender: 'alien' } })).response.status).toBe(400);
    expect((await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { ...base, status: 'flying' } })).response.status).toBe(400);
    expect((await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { ...base, birthDate: '24-13-45' } })).response.status).toBe(400);
    expect((await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { ...base, birthDate: 'not-a-date' } })).response.status).toBe(400);
    const ok = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { ...base, gender: 'female', status: 'active' } });
    const id = idOf(ok.data);
    expect((await raw(ctx, `/cows/${id}`, { method: 'PUT', token: ctx.owner, body: { gender: 'alien' } })).response.status).toBe(400);
    expect((await raw(ctx, `/cows/${id}`, { method: 'PUT', token: ctx.owner, body: { weight: -1 } })).response.status).toBe(400);
    // Immutable identity: trying to move the record to another id must not work.
    const moved = await raw(ctx, `/cows/${id}`, { method: 'PUT', token: ctx.owner, body: { _id: 'forged-id', id: 'forged-id' } });
    if (moved.response.status === 200) {
      const check = await raw(ctx, `/cows/${id}`, { token: ctx.owner });
      expect(String(check.data._id || check.data.id)).toBe(id);
    }
    await raw(ctx, `/cows/${id}`, { method: 'DELETE', token: ctx.owner });
  });

  it('ghost foreign keys are rejected (milk/health for nonexistent cow)', async () => {
    const milk = await raw(ctx, '/milk', { method: 'POST', token: ctx.owner, body: { cowId: 'no-such-cow', date: '2026-09-03', morning: 5 } });
    expect([400, 404]).toContain(milk.response.status);
    expect(milk.response.status).not.toBe(201);
    const health = await raw(ctx, '/health', { method: 'POST', token: ctx.owner, body: { cowId: 'no-such-cow', date: '2026-09-03', type: 'vaccination', description: 'ghost' } });
    expect(health.response.status).not.toBe(201);
  });

  it('bulk milk import: valid rows land; invalid rows rejected atomically', async () => {
    const ok = await raw(ctx, '/milk/bulk', { method: 'POST', token: ctx.owner, body: { entries: [
      { cowId, date: '2026-09-07', morning: 5, evening: 4 },
      { cowId, date: '2026-09-08', morning: 6, evening: 4 },
    ] } });
    expect([200, 201]).toContain(ok.response.status);
    const before = rowsOf((await raw(ctx, '/milk?limit=500', { token: ctx.owner })).data).length;
    const mixed = await raw(ctx, '/milk/bulk', { method: 'POST', token: ctx.owner, body: { entries: [
      { cowId, date: '2026-09-09', morning: 5, evening: 4 },
      { cowId, date: '2026-09-09', morning: -3, evening: 4 },
    ] } });
    expect(mixed.response.status).toBe(400);
    const after = rowsOf((await raw(ctx, '/milk?limit=500', { token: ctx.owner })).data).length;
    expect(after, 'invalid bulk must not partially land').toBe(before);
    const empty = await raw(ctx, '/milk/bulk', { method: 'POST', token: ctx.owner, body: { entries: [] } });
    expect(empty.response.status).toBe(400);
  });
});
