/**
 * Agri backend — API field-matrix (NO app fixes; failures = findings).
 * Every resource: full CRUD plus per-field invalid-input matrix.
 * Agri single-record POST/PUT are the known-weak surface (bulk twins
 * validate) — this file pins down exactly which fields slip through.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, rowsOf, S, startApp, stopApp, type Ctx } from './harness';

let ctx: Ctx;
let cropId = '';

const LONG = 'x'.repeat(10_000);
const SCRIPT = '<script>alert(1)</script>';

interface Res {
  name: string; base: string;
  valid: () => Record<string, any>;
  required: string[];
  update: Record<string, any>;
  updateMethod?: string;
  numeric: string[];
  idFrom?: (data: any) => string;
}

function resources(): Res[] {
  return [
    {
      name: 'crops', base: '/crops',
      valid: () => ({ name: `Matrix Wheat ${S}`, status: 'Growing', plant_date: '2026-09-01', area_acres: 5 }),
      required: ['name'], update: { name: `Matrix Wheat Renamed ${S}`, status: 'Growing', plant_date: '2026-09-01' }, numeric: ['area_acres'],
    },
    {
      name: 'tasks', base: '/tasks',
      valid: () => ({ title: `Matrix Task ${S}`, assigned_to: 'worker', priority: 'High', due_date: '2026-09-20' }),
      required: ['title'], update: { title: `Matrix Task Renamed ${S}` }, updateMethod: 'PUT', numeric: [],
    },
    {
      name: 'finance', base: '/finance',
      valid: () => ({ category: `Matrix Seed ${S}`, type: 'expense', amount: 9000, date: '2026-09-04', notes: `matrix ${S}` }),
      required: ['amount', 'date'], update: { category: `Matrix Seed ${S}`, type: 'expense', amount: 11000, date: '2026-09-04' }, numeric: ['amount'],
    },
    {
      name: 'inventory', base: '/inventory',
      valid: () => ({ name: `Matrix Urea ${S}`, quantity: 20, unit: 'bags' }),
      required: ['name'], update: { name: `Matrix Urea ${S}`, quantity: 35, unit: 'bags' }, numeric: ['quantity'],
    },
    {
      name: 'suppliers', base: '/suppliers',
      valid: () => ({ name: `Matrix Supplier ${S}`, phone: '03002223334' }),
      required: ['name'], update: { name: `Matrix Supplier Renamed ${S}` }, numeric: [],
    },
    {
      name: 'liabilities', base: '/liabilities',
      valid: () => ({ creditor: `Matrix Creditor ${S}`, amount_owed: 7000, due_date: '2026-10-01' }),
      required: ['creditor', 'amount_owed'], update: { amount_owed: 8000 }, numeric: ['amount_owed'],
    },
    {
      name: 'laborers', base: '/laborers',
      valid: () => ({ name: `Matrix Laborer ${S}`, daily_wage: 1200 }),
      required: ['name'], update: { name: `Matrix Laborer ${S}`, daily_wage: 1500 }, numeric: ['daily_wage'],
    },
  ];
}

/** Agri finance/tasks creates return {status:'ok'} without the new id —
 *  resolve it from the list by the unique marker field instead. */
async function resolveId(res: Res, created: any): Promise<string> {
  const direct = idOf(created.data);
  if (direct) return direct;
  const list = await raw(ctx, `${res.base}?skip=0&limit=500`, { token: ctx.owner });
  const probe = Object.entries(res.valid()).find(([, v]) => typeof v === 'string' && String(v).includes(S));
  if (!probe) return '';
  const row = rowsOf(list.data).find((r: any) => String(r[probe[0]]) === String(probe[1]));
  return row ? String(row._id || row.id) : '';
}

describe.sequential('Agri API field matrix', () => {
  beforeAll(async () => {
    ctx = await startApp('agri', 'agri_farm/backend');
    const crop = await raw(ctx, '/crops', { method: 'POST', token: ctx.owner, body: { name: `Matrix Host Crop ${S}`, status: 'Growing', plant_date: '2026-09-01' } });
    cropId = idOf(crop.data);
  }, 120_000);
  afterAll(async () => { await stopApp(ctx); }, 30_000);

  for (const res of resources()) {
    describe(res.name, () => {
      it('full CRUD: create → update → delete → gone', async () => {
        const created = await raw(ctx, res.base, { method: 'POST', token: ctx.owner, body: res.valid() });
        expect(created.response.status, `create ${res.name}`).toBe(201);
        const id = await resolveId(res, created);
        expect(id, `id for ${res.name}`).toBeTruthy();

        const updated = await raw(ctx, `${res.base}/${id}`, { method: res.updateMethod || 'PUT', token: ctx.owner, body: res.update });
        expect(updated.response.status, `update ${res.name}`).toBe(200);
        const list = await raw(ctx, `${res.base}?skip=0&limit=500`, { token: ctx.owner });
        expect(list.response.status).toBe(200);
        const row = rowsOf(list.data).find((r: any) => String(r._id || r.id) === id);
        expect(row, `${res.name} row still listed after update`).toBeTruthy();
        const [field, value] = Object.entries(res.update)[0];
        if (row) expect(String(row[field])).toBe(String(value));

        const del = await raw(ctx, `${res.base}/${id}`, { method: 'DELETE', token: ctx.owner });
        expect(del.response.status, `delete ${res.name}`).toBe(200);
        const after = await raw(ctx, `${res.base}?skip=0&limit=500`, { token: ctx.owner });
        expect(rowsOf(after.data).some((r: any) => String(r._id || r.id) === id), `${res.name} gone from list`).toBe(false);
        const delAgain = await raw(ctx, `${res.base}/${id}`, { method: 'DELETE', token: ctx.owner });
        expect(delAgain.response.status, `double-delete ${res.name}`).toBe(404);
      });

      it('rejects empty body and missing required fields', async () => {
        expect((await raw(ctx, res.base, { method: 'POST', token: ctx.owner, body: {} })).response.status, `${res.name} empty body`).toBe(400);
        for (const field of res.required) {
          const body = res.valid();
          delete body[field];
          const r = await raw(ctx, res.base, { method: 'POST', token: ctx.owner, body });
          expect(r.response.status, `${res.name} missing ${field}`).toBe(400);
          if (r.response.status === 201) await raw(ctx, `${res.base}/${idOf(r.data)}`, { method: 'DELETE', token: ctx.owner });
        }
      });

      it('rejects negative / string / huge numbers', async () => {
        for (const field of res.numeric) {
          for (const [label, value] of [['negative', -5], ['string', 'abc'], ['huge', 1e15]] as const) {
            const r = await raw(ctx, res.base, { method: 'POST', token: ctx.owner, body: { ...res.valid(), [field]: value } });
            expect(r.response.status, `${res.name}.${field} ${label}`).toBe(400);
            if (r.response.status === 201) await raw(ctx, `${res.base}/${idOf(r.data)}`, { method: 'DELETE', token: ctx.owner });
          }
        }
      });

      it('rejects oversized strings; does not store script verbatim', async () => {
        const textField = res.required.find((f) => typeof res.valid()[f] === 'string') || Object.keys(res.valid()).find((f) => typeof res.valid()[f] === 'string');
        if (!textField) return;
        const long = await raw(ctx, res.base, { method: 'POST', token: ctx.owner, body: { ...res.valid(), [textField]: LONG } });
        expect(long.response.status, `${res.name}.${textField} 10k chars`).toBe(400);
        if (long.response.status === 201) await raw(ctx, `${res.base}/${idOf(long.data)}`, { method: 'DELETE', token: ctx.owner });

        const created = await raw(ctx, res.base, { method: 'POST', token: ctx.owner, body: { ...res.valid(), [textField]: SCRIPT } });
        if (created.response.status === 201) {
          const list = await raw(ctx, `${res.base}?skip=0&limit=500`, { token: ctx.owner });
          const row = rowsOf(list.data).find((r: any) => String(r._id || r.id) === idOf(created.data));
          expect(String(row?.[textField] ?? ''), `${res.name}.${textField} stores <script> verbatim`).not.toContain('<script>');
          await raw(ctx, `${res.base}/${idOf(created.data)}`, { method: 'DELETE', token: ctx.owner });
        } else expect(created.response.status).toBe(400);
      });

      it('update rejects invalid values too', async () => {
        const created = await raw(ctx, res.base, { method: 'POST', token: ctx.owner, body: res.valid() });
        const id = await resolveId(res, created);
        for (const field of res.numeric) {
          const r = await raw(ctx, `${res.base}/${id}`, { method: res.updateMethod || 'PUT', token: ctx.owner, body: { ...res.valid(), [field]: -9 } });
          expect(r.response.status, `${res.name} update ${field} negative`).toBe(400);
        }
        const bad = await raw(ctx, `${res.base}/${id}`, { method: res.updateMethod || 'PUT', token: ctx.owner, body: {} });
        expect(bad.response.status, `${res.name} empty update`).toBe(400);
        await raw(ctx, `${res.base}/${id}`, { method: 'DELETE', token: ctx.owner });
      });

      it('rejects unauthenticated writes; worker create → 403', async () => {
        expect((await raw(ctx, res.base, { method: 'POST', body: res.valid() })).response.status, `${res.name} anon`).toBe(401);
        const worker = await raw(ctx, res.base, { method: 'POST', token: ctx.worker, body: res.valid() });
        expect(worker.response.status, `${res.name} worker create`).toBe(403);
        if (worker.response.status === 201) await raw(ctx, `${res.base}/${idOf(worker.data)}`, { method: 'DELETE', token: ctx.owner });
      });
    });
  }

  it('crops: rejects bad status enum and bad plant_date on create and update', async () => {
    expect((await raw(ctx, '/crops', { method: 'POST', token: ctx.owner, body: { name: `Bad ${S}`, status: 'Flying', plant_date: '2026-09-01' } })).response.status).toBe(400);
    expect((await raw(ctx, '/crops', { method: 'POST', token: ctx.owner, body: { name: `Bad ${S}`, status: 'Growing', plant_date: 'Sep 1 2026' } })).response.status).toBe(400);
    const ok = await raw(ctx, '/crops', { method: 'POST', token: ctx.owner, body: { name: `Enum Crop ${S}`, status: 'Growing', plant_date: '2026-09-01' } });
    const id = idOf(ok.data);
    expect((await raw(ctx, `/crops/${id}`, { method: 'PUT', token: ctx.owner, body: { status: 'Flying' } })).response.status).toBe(400);
    await raw(ctx, `/crops/${id}`, { method: 'DELETE', token: ctx.owner });
  });

  it('tasks: rejects bad priority enum', async () => {
    expect((await raw(ctx, '/tasks', { method: 'POST', token: ctx.owner, body: { title: `Bad ${S}`, priority: 'Whenever' } })).response.status).toBe(400);
  });

  it('crop logs: irrigation/spray validation + ghost crop', async () => {
    expect((await raw(ctx, '/irrigation', { method: 'POST', token: ctx.owner, body: { crop_id: cropId, hours: 0 } })).response.status).toBe(400);
    expect((await raw(ctx, '/irrigation', { method: 'POST', token: ctx.owner, body: { crop_id: cropId, hours: -2 } })).response.status).toBe(400);
    expect((await raw(ctx, '/irrigation', { method: 'POST', token: ctx.owner, body: { crop_id: 'no-such-crop', hours: 2 } })).response.status).not.toBe(201);
    const ok = await raw(ctx, '/irrigation', { method: 'POST', token: ctx.owner, body: { crop_id: cropId, hours: 2, tubewell: 'own', date: '2026-09-11' } });
    expect(ok.response.status).toBe(201);
    const logId = idOf(ok.data);
    expect((await raw(ctx, `/irrigation/${logId}`, { method: 'DELETE', token: ctx.owner })).response.status).toBe(200);
    expect((await raw(ctx, `/irrigation/${logId}`, { method: 'DELETE', token: ctx.owner })).response.status, 'double-delete irrigation').toBe(404);

    expect((await raw(ctx, '/spray', { method: 'POST', token: ctx.owner, body: {} })).response.status).toBe(400);
    const spray = await raw(ctx, '/spray', { method: 'POST', token: ctx.owner, body: { crop_id: cropId, chemical: `Matrix Spray ${S}`, date: '2026-09-11' } });
    expect(spray.response.status).toBe(201);
    const sprayId = idOf(spray.data);
    expect((await raw(ctx, '/spray', { method: 'POST', token: ctx.owner, body: { crop_id: cropId, chemical: `X ${S}`, quantity: -1 } })).response.status, 'spray negative quantity').toBe(400);
    expect((await raw(ctx, `/spray/${sprayId}`, { method: 'DELETE', token: ctx.owner })).response.status).toBe(200);
  });

  it('bulk twins validate (contrast with single-record creates)', async () => {
    const fin = await raw(ctx, '/finance/bulk', { method: 'POST', token: ctx.owner, body: { entries: [{ category: 'X', type: 'expense', amount: -5, date: '2026-09-04' }] } });
    expect(fin.response.status, 'finance bulk negative').toBe(400);
    const task = await raw(ctx, '/tasks/bulk', { method: 'POST', token: ctx.owner, body: { entries: [{}] } });
    expect(task.response.status, 'tasks bulk empty row').toBe(400);
  });
});
