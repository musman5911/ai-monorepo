/**
 * Backup / restore (import) / export across all three backends
 * (NO app fixes; failures = findings):
 *  - owner can download a backup; worker cannot
 *  - backup is valid JSON containing the seeded collections
 *  - junk restore bodies are rejected (400), backup stays intact
 *  - a real backup restores into a FRESH backend instance and the
 *    data round-trips (export → import verification)
 *  - Flock batch export-all responds; farm-summary cross-app gate
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { raw, rowsOf, S, startApp, stopApp, type Ctx } from './harness';

const apps: Record<string, Ctx> = {};
const fresh: Record<string, Ctx> = {};

function backupOf(ctx: Ctx) {
  return raw(ctx, '/backup', { token: ctx.owner });
}

describe.sequential('Backup / import / export (all apps)', () => {
  beforeAll(async () => {
    apps.dairy = await startApp('dairy', 'dairy_farm/backend');
    apps.flock = await startApp('flock', 'flock_farm/backend');
    apps.agri = await startApp('agri', 'agri_farm/backend');
  }, 180_000);
  afterAll(async () => {
    for (const ctx of [...Object.values(apps), ...Object.values(fresh)]) await stopApp(ctx);
  }, 60_000);

  for (const name of ['dairy', 'flock', 'agri']) {
    describe(name, () => {
      it('owner downloads a structured backup; worker is forbidden', async () => {
        const ctx = apps[name];
        const backup = await backupOf(ctx);
        expect(backup.response.status).toBe(200);
        expect(typeof backup.data).toBe('object');
        const keys = Object.keys(backup.data || {});
        expect(keys.length, `${name} backup has sections`).toBeGreaterThan(2);
        const worker = await raw(ctx, '/backup', { token: ctx.worker });
        expect(worker.response.status, `${name} worker backup`).toBe(403);
        const anon = await raw(ctx, '/backup');
        expect(anon.response.status).toBe(401);
      });

      it('junk restore is rejected and data survives', async () => {
        const ctx = apps[name];
        const restorePath = name === 'dairy' ? '/backup/restore' : '/restore';
        for (const junk of [{}, { backup: 'nope' }, { version: 999 }, 'not json at all']) {
          const r = await raw(ctx, restorePath, { method: 'POST', token: ctx.owner, body: junk as any });
          expect(r.response.status, `${name} junk restore ${JSON.stringify(junk).slice(0, 20)}`).toBe(400);
        }
        const worker = await raw(ctx, restorePath, { method: 'POST', token: ctx.worker, body: {} });
        expect(worker.response.status, `${name} worker restore`).toBe(403);
        const backup = await backupOf(ctx);
        expect(backup.response.status).toBe(200);
      });

      it('export → restore into a fresh instance round-trips the marker record', async () => {
        const ctx = apps[name];
        // Plant a unique marker record through the normal API first.
        let listRoute = '';
        if (name === 'dairy') {
          await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { name: `Backup Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
          listRoute = '/cows?limit=500';
        } else if (name === 'flock') {
          await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, body: { name: `Backup Batch ${S}`, type: 'Layer', start_date: '2026-09-01', intake_count: 10, cost_per_bird: 50 } });
          listRoute = '/batches';
        } else {
          await raw(ctx, '/crops', { method: 'POST', token: ctx.owner, body: { name: `Backup Crop ${S}`, status: 'Growing', plant_date: '2026-09-01' } });
          listRoute = '/crops?skip=0&limit=500';
        }
        const backup = await backupOf(ctx);
        expect(backup.response.status).toBe(200);
        expect(JSON.stringify(backup.data), `${name} backup contains marker`).toContain(S);

        fresh[name] = await startApp(name, `${name}_farm/backend`);
        const restorePath = name === 'dairy' ? '/backup/restore' : '/restore';
        const restored = await raw(fresh[name], restorePath, { method: 'POST', token: fresh[name].owner, body: backup.data });
        expect(restored.response.status, `${name} restore into fresh instance`).toBe(200);

        // Restored data lives under the restored farm(s): scan every
        // farm the fresh owner can see, not just the default context.
        const farmsData = (await raw(fresh[name], '/farms', { token: fresh[name].owner })).data;
        const farmList: any[] = farmsData?.farms || farmsData || [];
        let found = false;
        for (const farm of [null, ...farmList]) {
          const farmId = farm ? String(farm.id || farm._id) : undefined;
          const list = await raw(fresh[name], listRoute, { token: fresh[name].owner, ...(farmId ? { farmId } : {}) });
          if (rowsOf(list.data).some((r: any) => String(r.name || '').includes(S))) { found = true; break; }
        }
        expect(found, `${name} marker visible after restore`).toBe(true);
      });
    });
  }

  it('flock: batch export-all endpoint responds with export data', async () => {
    const r = await raw(apps.flock, '/batches/export-all', { token: apps.flock.owner });
    expect(r.response.status).toBe(200);
    expect(JSON.stringify(r.data).length).toBeGreaterThan(50);
    expect((await raw(apps.flock, '/batches/export-all', { token: apps.flock.worker })).response.status).not.toBe(500);
  });

  it('cross-app farm-summary gate rejects wrong keys everywhere', async () => {
    for (const name of ['dairy', 'flock', 'agri']) {
      const r = await raw(apps[name], '/farm-summary?key=definitely-wrong');
      expect([401, 403, 404], `${name} farm-summary wrong key`).toContain(r.response.status);
    }
  });
});
