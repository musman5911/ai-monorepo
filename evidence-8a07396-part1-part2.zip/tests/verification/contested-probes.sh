#!/usr/bin/env bash
# Contested-item verification probes — run from repo root. Memory mode, local.
# Usage: bash tests/verification/contested-probes.sh
set -u
cd "$(dirname "$0")/../.."
export MEMORY_MODE=1 JWT_SECRET=[SECURITY_DATA] DISABLE_INTERNAL_SCHEDULER=1

start() { # dir port logfile extra-env...
  local dir=$1 port=$2 log=$3; shift 3
  (cd "$dir" && env "$@" PORT=$port node server.js >"$log" 2>&1 & echo $! > "/tmp/vp-$port.pid")
  for i in $(seq 1 30); do curl -s -o /dev/null "http://127.0.0.1:$port/api/farms" && break || sleep 0.5; done
}
stop() { kill "$(cat /tmp/vp-$1.pid)" 2>/dev/null; }

echo "================ A4: Set-Cookie on login ================"
start agri_farm/backend 18401 /tmp/vp-agri.log
echo "-- Agri POST /api/login (form):"
curl -s -D- -o /dev/null -X POST http://127.0.0.1:18401/api/login -d 'username=admin&password=[SECURITY_DATA]' | grep -i "set-cookie" || echo "(no Set-Cookie header)"
stop 18401
start flock_farm/backend 18402 /tmp/vp-flock.log
echo "-- Flock POST /api/auth/login (json):"
curl -s -D- -o /dev/null -X POST http://127.0.0.1:18402/api/auth/login -H 'Content-Type: application/json' -d '{"username":"admin","password":"admin123"}' | grep -i "set-cookie" || echo "(no Set-Cookie header)"
stop 18402
start dairy_farm/backend 18403 /tmp/vp-dairy.log
echo "-- Dairy POST /api/auth/login (json):"
curl -s -D- -o /dev/null -X POST http://127.0.0.1:18403/api/auth/login -H 'Content-Type: application/json' -d '{"username":"admin","password":"admin123"}' | grep -i "set-cookie" || echo "(no Set-Cookie header)"

echo "================ C2: CORS reflection by environment ================"
echo "-- Dairy, NODE_ENV=test (harness default), no FRONTEND_URL:"
curl -s -D- -o /dev/null http://127.0.0.1:18403/api/farms -H "Origin: https://evil.example" | grep -i "access-control-allow" || echo "(no ACAO)"
stop 18403
start dairy_farm/backend 18404 /tmp/vp-dairy-prod.log NODE_ENV=production
echo "-- Dairy, NODE_ENV=production, no FRONTEND_URL:"
curl -s -D- -o /dev/null http://127.0.0.1:18404/api/farms -H "Origin: https://evil.example" | grep -i "access-control-allow" || echo "(no ACAO)"
stop 18404

echo "================ E11: Agri automations role test ================"
start agri_farm/backend 18405 /tmp/vp-agri2.log
TOK=$(curl -s -X POST http://127.0.0.1:18405/api/login -H 'Content-Type: application/json' -d '{"username":"admin","password":"admin123"}' | python3 -c "import sys,json;print(json.load(sys.stdin).get('access_token',''))")
WTOK=$(curl -s -X POST http://127.0.0.1:18405/api/login -H 'Content-Type: application/json' -d '{"username":"worker","password":"worker123"}' | python3 -c "import sys,json;print(json.load(sys.stdin).get('access_token',''))")
echo "-- worker PUT /api/settings/automations:"
curl -s -o /dev/null -w "%{http_code}\n" -X PUT http://127.0.0.1:18405/api/settings/automations -H "Authorization: Bearer $WTOK" -H 'Content-Type: application/json' -d '{"garbage":"payload","nested":{"x":1}}'
echo "-- owner PUT /api/settings/automations with garbage payload:"
curl -s -o /dev/null -w "%{http_code}\n" -X PUT http://127.0.0.1:18405/api/settings/automations -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' -d '{"garbage":"payload","nested":{"x":1}}'
echo "-- owner GET /api/settings/automations (was garbage stored?):"
curl -s http://127.0.0.1:18405/api/settings/automations -H "Authorization: Bearer $TOK" | head -c 200; echo
stop 18405

echo "================ N1/D4: Dairy double-delete semantics ================"
start dairy_farm/backend 18406 /tmp/vp-dairy2.log
DTOK=$(curl -s -X POST http://127.0.0.1:18406/api/auth/login -H 'Content-Type: application/json' -d '{"username":"admin","password":"admin123"}' | python3 -c "import sys,json;print(json.load(sys.stdin).get('token',''))")
COW=$(curl -s -X POST http://127.0.0.1:18406/api/cows -H "Authorization: Bearer $DTOK" -H 'Content-Type: application/json' -d '{"name":"VerifyCow","breed":"Jersey","gender":"female","status":"active"}' | python3 -c "import sys,json;print(json.load(sys.stdin).get('_id',''))")
HID=$(curl -s -X POST http://127.0.0.1:18406/api/health -H "Authorization: Bearer $DTOK" -H 'Content-Type: application/json' -d "{\"cowId\":\"$COW\",\"date\":\"2026-09-05\",\"type\":\"vaccination\",\"description\":\"v\",\"cost\":700}" | python3 -c "import sys,json;print(json.load(sys.stdin).get('_id',''))")
echo "-- DELETE /api/health/$HID (first):"
curl -s -o /dev/null -w "%{http_code}\n" -X DELETE "http://127.0.0.1:18406/api/health/$HID" -H "Authorization: Bearer $DTOK"
echo "-- DELETE same id again (double-delete):"
curl -s -w " %{http_code}\n" -X DELETE "http://127.0.0.1:18406/api/health/$HID" -H "Authorization: Bearer $DTOK"
stop 18406
echo "DONE"
