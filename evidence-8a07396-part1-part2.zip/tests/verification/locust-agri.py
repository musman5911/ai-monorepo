from locust import HttpUser, task, between
class AgriUser(HttpUser):
    wait_time = between(0.05, 0.2)
    def on_start(self):
        r = self.client.post("/api/login", json={"username": "admin", "password": "admin123"})
        self.h = {"Authorization": f"Bearer {r.json().get('access_token','')}"}
    @task(3)
    def crops(self): self.client.get("/api/crops?limit=10", headers=self.h, name="crops")
    @task(2)
    def fields(self): self.client.get("/api/fields", headers=self.h, name="fields")
    @task(1)
    def summary(self): self.client.get("/api/analytics/summary", headers=self.h, name="summary")
