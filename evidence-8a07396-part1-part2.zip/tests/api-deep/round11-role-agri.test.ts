/** ROUND 11B (Phase 7, agri live — dairy/flock blocked by P7-0 boot bug): role system scope on crops/fields/users/telegram. NO fixes. */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

describe.sequential('ROUND 11B: role system (agri)', () => {
  let ctx: Ctx;
  let farmA = ''; let farmB = '';
  let mgrA = ''; let mgrAId = ''; let mgrB = '';

  const loginAs = async (u: string, p: string) => {
    const r = await raw(ctx, '/login', { method: 'POST', body: { username: u, password: p } });
    expect(r.response.status, `login ${u} → ${r.response.status} ${JSON.stringify(r.data).slice(0, 100)}`).toBe(200);
    return String((r.data as any)?.access_token || (r.data as any)?.token || '');
  };
  const mkUser = async (username: string, role: string, farmIds: string[]) => {
    const r = await raw(ctx, '/signup', { method: 'POST', token: ctx.owner, body: { username, password: 'RoleTest123!', role, email: `${username}@test.local`, farmIds } });
    expect([200, 201], `create ${username} → ${r.response.status} ${JSON.stringify(r.data).slice(0, 140)}`).toContain(r.response.status);
    return String((r.data as any)?.id || (r.data as any)?._id || idOf(r.data));
  };

  beforeAll(async () => {
    ctx = await startApp('agri', 'agri_farm/backend');
    const farms = await raw(ctx, '/farms', { token: ctx.owner });
    const list = (farms.data as any)?.farms || [];
    farmA = String(list[0]?.id || list[0]?._id || '');
    const fb = await raw(ctx, '/farms', { method: 'POST', token: ctx.owner, body: { name: `R11B FarmB ${S}` } });
    farmB = String((fb.data as any)?.id || idOf(fb.data));
    expect(farmA && farmB && farmA !== farmB).toBeTruthy();
    mgrAId = await mkUser(`r11bmgra${S}`, 'manager', [farmA]);
    await mkUser(`r11bmgrb${S}`, 'manager', [farmB]);
    mgrA = await loginAs(`r11bmgra${S}`, 'RoleTest123!');
    mgrB = await loginAs(`r11bmgrb${S}`, 'RoleTest123!');
  }, 180_000);
  afterAll(async () => { await stopApp(ctx); }, 60_000);

  it('owner: all-mode, any-farm access, summary, farm creation all work', async () => {
    expect((await raw(ctx, '/crops?limit=5', { token: ctx.owner, farmId: 'all' })).response.status).toBe(200);
    expect((await raw(ctx, '/super-admin/farm-summary', { token: ctx.owner })).response.status).toBe(200);
    expect((await raw(ctx, '/backup', { token: ctx.owner })).response.status).toBe(200);
  });

  it('manager: farm list = assigned only; unassigned header 403; B data invisible in all-mode', async () => {
    const farms = await raw(ctx, '/farms', { token: mgrA });
    const ids = ((farms.data as any)?.farms || []).map((f: any) => String(f.id || f._id));
    expect(ids).toContain(farmA);
    expect(ids).not.toContain(farmB);
    const forb = await raw(ctx, '/crops?limit=5', { token: mgrA, farmId: farmB });
    expect(forb.response.status, `mgr A + farm B header → ${forb.response.status}`).toBe(403);
    const cropB = await raw(ctx, '/crops', { method: 'POST', token: ctx.owner, farmId: farmB, body: { name: `R11B BCrop ${S}`, status: 'Growing', plant_date: '2026-10-01' } });
    expect([200, 201]).toContain(cropB.response.status);
    const all = await raw(ctx, '/crops?limit=100', { token: mgrA, farmId: 'all' });
    expect(JSON.stringify(all.data), 'mgr A all-mode leaks B crop').not.toContain(`R11B BCrop ${S}`);
    const inB = await raw(ctx, '/crops?limit=100', { token: mgrB, farmId: farmB });
    expect(JSON.stringify(inB.data), 'mgr B cannot see own crop').toContain(`R11B BCrop ${S}`);
  });

  it('manager: writes in all-mode 400; body farmId smuggle stays in assigned farm; fields admin ops work only in scope', async () => {
    const w = await raw(ctx, '/crops', { method: 'POST', token: mgrA, farmId: 'all', body: { name: `R11B AllW ${S}`, status: 'Growing', plant_date: '2026-10-01' } });
    expect(w.response.status, `mgr write all-mode → ${w.response.status}`).toBe(400);
    const smug = await raw(ctx, '/crops', { method: 'POST', token: mgrA, farmId: farmA, body: { name: `R11B Smuggle ${S}`, status: 'Growing', plant_date: '2026-10-01', farmId: farmB } as any });
    expect([200, 201], `smuggle create → ${smug.response.status}`).toContain(smug.response.status);
    const inB = await raw(ctx, '/crops?limit=100', { token: ctx.owner, farmId: farmB });
    expect(JSON.stringify(inB.data), 'smuggled crop in B').not.toContain(`R11B Smuggle ${S}`);
    const fieldB = await raw(ctx, '/fields', { method: 'POST', token: mgrA, farmId: farmB, body: { name: `R11B F ${S}`, acres: 1 } });
    expect([400, 403], `mgr create field in B → ${fieldB.response.status}`).toContain(fieldB.response.status);
  });

  it('manager cannot administer: farm create/archive/delete, manager creation, super-admin summary', async () => {
    expect([401, 403]).toContain((await raw(ctx, '/farms', { method: 'POST', token: mgrA, body: { name: `R11B MF ${S}` } })).response.status);
    expect([401, 403]).toContain((await raw(ctx, `/farms/${farmA}/archive`, { method: 'POST', token: mgrA, body: {} })).response.status);
    const mkMgr = await raw(ctx, '/signup', { method: 'POST', token: mgrA, body: { username: `r11bevil${S}`, password: 'RoleTest123!', role: 'manager', email: `e${S}@t.local`, farmIds: [farmA] } });
    expect([401, 403], `mgr creates manager → ${mkMgr.response.status}`).toContain(mkMgr.response.status);
    expect([401, 403]).toContain((await raw(ctx, '/super-admin/farm-summary', { token: mgrA })).response.status);
  });

  it('manager scope on backup: full-DB export must not leak farm B (or must be forbidden)', async () => {
    const bak = await raw(ctx, '/backup', { token: mgrA });
    if (bak.response.status === 200) {
      expect(JSON.stringify(bak.data), 'manager backup leaks B crop').not.toContain(`R11B BCrop ${S}`);
    } else {
      expect([401, 403]).toContain(bak.response.status);
    }
  });

  it('escalation: manager cannot widen own farms/role via user edit endpoints', async () => {
    const attempts: Array<[string, string, any]> = [
      ['PATCH', `/users/${mgrAId}/edit`, { role: 'owner' }],
      ['PATCH', `/users/${mgrAId}/edit`, { farmIds: [farmA, farmB] }],
      ['PUT', '/users/me', { role: 'owner', farmIds: [farmA, farmB] }],
    ];
    for (const [m, path, body] of attempts) {
      const r = await raw(ctx, path, { method: m, token: mgrA, body });
      if (r.response.status < 300) {
        const probe = await raw(ctx, '/crops?limit=5', { token: mgrA, farmId: farmB });
        expect(probe.response.status, `${m} ${path} widened access`).toBe(403);
      }
    }
    const me = await raw(ctx, '/users/me', { token: mgrA });
    expect(JSON.stringify(me.data), 'manager became owner').not.toContain('"role":"owner"');
  });

  it('worker (seeded): cannot create users/farms, cannot reach farm B, cannot open summary/backup', async () => {
    expect([401, 403]).toContain((await raw(ctx, '/farms', { method: 'POST', token: ctx.worker, body: { name: `R11B WF ${S}` } })).response.status);
    expect([401, 403]).toContain((await raw(ctx, '/super-admin/farm-summary', { token: ctx.worker })).response.status);
    expect([401, 403]).toContain((await raw(ctx, '/backup', { token: ctx.worker })).response.status);
    const mkU = await raw(ctx, '/signup', { method: 'POST', token: ctx.worker, body: { username: `r11bwk${S}`, password: 'RoleTest123!', role: 'worker', farmIds: [farmA] } });
    expect([401, 403], `worker creates user → ${mkU.response.status}`).toContain(mkU.response.status);
  });

  it('telegram scope: manager cannot read/push telegram for farm B; summary push restricted', async () => {
    const stB = await raw(ctx, '/telegram/settings', { token: mgrA, farmId: farmB });
    expect([401, 403, 404], `mgr telegram settings farm B → ${stB.response.status}`).toContain(stB.response.status);
    const pushB = await raw(ctx, '/telegram/send-summary', { method: 'POST', token: mgrA, farmId: farmB, body: {} });
    expect([401, 403, 404], `mgr telegram push farm B → ${pushB.response.status}`).toContain(pushB.response.status);
    const pushAll = await raw(ctx, '/telegram/send-summary', { method: 'POST', token: mgrA, farmId: 'all', body: {} });
    if (pushAll.response.status === 200) {
      const farmsHit = (pushAll.data as any)?.farms || (pushAll.data as any)?.results || [];
      const ids = JSON.stringify(farmsHit);
      expect(ids, 'mgr all-mode telegram pushed to farm B').not.toContain(farmB);
    }
  });
});
