/** ROUND R4 (post-186-pull): backup/restore with new models (breeding events, fields) + large image restore. NO fixes. */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

describe.sequential('ROUND R4: backup/restore new-model coverage', () => {
  let dairy: Ctx;
  let flock: Ctx;
  beforeAll(async () => {
    dairy = await startApp('dairy', 'dairy_farm/backend');
    flock = await startApp('flock', 'flock_farm/backend');
  }, 180_000);
  afterAll(async () => { await stopApp(dairy); await stopApp(flock); }, 60_000);

  it('dairy: breeding events are inside backup and come back on restore', async () => {
    const mkCow = async (name: string, gender: string): Promise<string> => {
      const r = await raw(dairy, '/cows', { method: 'POST', token: dairy.owner, body: { name, breed: 'Jersey', gender, status: 'active' } });
      expect([200, 201], `cow ${name} -> ${r.response.status}`).toContain(r.response.status);
      return String((r.data as any)?._id || (r.data as any)?.id || '');
    };
    const bullId = await mkCow(`R4 Bull ${S}`, 'male');
    const cowId = await mkCow(`R4 Cow ${S}`, 'female');
    expect(bullId && cowId).toBeTruthy();
    const ev = await raw(dairy, '/breeding/events', {
      method: 'POST',
      token: dairy.owner,
      body: { cowId, type: 'service', date: '2026-10-04', sireSource: 'farm_bull', bullId },
    });
    expect(ev.response.status, `event -> ${ev.response.status} ${JSON.stringify(ev.data).slice(0, 120)}`).toBeLessThan(300);
    const backup = await raw(dairy, '/backup', { token: dairy.owner });
    expect(backup.response.status).toBe(200);
    expect(JSON.stringify(backup.data), 'backup omits breeding events (bull id absent)').toContain(bullId);
    const evId = String((ev.data as any)?._id || (ev.data as any)?.id || '');
    expect(evId).toBeTruthy();
    const del = await raw(dairy, `/breeding/events/${evId}`, { method: 'DELETE', token: dairy.owner });
    expect(del.response.status, `delete event -> ${del.response.status}`).toBeLessThan(300);
    const empty = await raw(dairy, '/breeding/events?limit=100', { token: dairy.owner });
    expect(JSON.stringify(empty.data), 'event still listed after delete').not.toContain(bullId);
    const restore = await raw(dairy, '/backup/restore', { method: 'POST', token: dairy.owner, body: backup.data });
    expect([200, 201, 204], `restore -> ${restore.response.status}`).toContain(restore.response.status);
    const back = await raw(dairy, '/breeding/events?limit=100', { token: dairy.owner });
    expect(JSON.stringify(back.data), 'breeding event missing after restore').toContain(bullId);
  });

  it('flock: restore accepts a large embedded image (moved-bucket fix b09f9d3)', async () => {
    const backup = await raw(flock, '/backup', { token: flock.owner });
    expect(backup.response.status).toBe(200);
    const blob = JSON.parse(JSON.stringify(backup.data));
    const big = 'data:image/png;base64,' + 'A'.repeat(1_500_000);
    let injected = false;
    const walk = (o: any, depth = 0): void => {
      if (injected || depth > 6 || !o || typeof o !== 'object') return;
      for (const k of Object.keys(o)) {
        if (/image|photo|avatar/i.test(k) && typeof o[k] === 'string') { o[k] = big; injected = true; return; }
        walk(o[k], depth + 1);
      }
    };
    walk(blob);
    if (!injected) blob.images = [{ name: `r4-big-${S}.png`, data: big }];
    const restore = await raw(flock, '/backup/restore', { method: 'POST', token: flock.owner, body: blob });
    expect([200, 201, 204], `large-image restore -> ${restore.response.status}`).toContain(restore.response.status);
  });
});
