/**
 * DEEP round 1 — robustness fuzzing (NO fixes; failures = findings).
 * Every write endpoint receives hostile bodies: arrays, strings, null,
 * nested objects in scalar fields, Mongo operator injection,
 * __proto__ pollution, NaN/Infinity, unicode/control chars.
 * Contract: never 500, never pollute prototypes, never crash the API.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const apps: Record<string, Ctx> = {};
let dairyCow = '';

const HOSTILE: Array<[string, any]> = [
  ['array body', [1, 2, 3]],
  ['string body', 'hello'],
  ['null field', null],
  ['nested object in name-ish field', { __nested: true }],
  ['mongo $gt operator', { $gt: '' }],
  ['mongo $where', { $where: 'sleep(1000)' }],
  ['proto pollution', JSON.parse(String.raw`{"__proto__":{"polluted":"yes"}}`)],
  ['constructor pollution', JSON.parse(String.raw`{"constructor":{"prototype":{"polluted":"yes"}}}`)],
];

interface Target { app: string; route: string; valid: () => any; textField?: string }

function targets(): Target[] {
  return [
    { app: 'dairy', route: '/cows', valid: () => ({ name: `Fuzz Cow ${S}`, breed: 'Jersey' }), textField: 'name' },
    { app: 'dairy', route: '/expenses', valid: () => ({ date: '2026-09-04', type: 'feed', amount: 100, note: `fz ${S}` }), textField: 'note' },
    { app: 'dairy', route: '/buyers', valid: () => ({ name: `Fuzz Buyer ${S}` }), textField: 'name' },
    { app: 'dairy', route: '/labor/workers', valid: () => ({ name: `Fuzz Worker ${S}`, dailyWage: 900 }), textField: 'name' },
    { app: 'flock', route: '/batches', valid: () => ({ name: `Fuzz Batch ${S}`, type: 'Broiler', start_date: '2026-09-01', intake_count: 10, cost_per_bird: 50 }), textField: 'name' },
    { app: 'agri', route: '/crops', valid: () => ({ name: `Fuzz Crop ${S}`, status: 'Growing', plant_date: '2026-09-01' }), textField: 'name' },
    { app: 'agri', route: '/tasks', valid: () => ({ title: `Fuzz Task ${S}`, priority: 'High' }), textField: 'title' },
    { app: 'agri', route: '/finance', valid: () => ({ category: `Fuzz ${S}`, type: 'expense', amount: 100, date: '2026-09-04' }), textField: 'category' },
    { app: 'agri', route: '/inventory', valid: () => ({ name: `Fuzz Item ${S}`, quantity: 3, unit: 'bags' }), textField: 'name' },
    { app: 'agri', route: '/suppliers', valid: () => ({ name: `Fuzz Supplier ${S}` }), textField: 'name' },
  ];
}

describe.sequential('DEEP: hostile-body fuzzing (no 500s, no pollution)', () => {
  beforeAll(async () => {
    apps.dairy = await startApp('dairy', 'dairy_farm/backend');
    apps.flock = await startApp('flock', 'flock_farm/backend');
    apps.agri = await startApp('agri', 'agri_farm/backend');
    const cow = await raw(apps.dairy, '/cows', { method: 'POST', token: apps.dairy.owner, body: { name: `Fuzz Host ${S}`, breed: 'Jersey' } });
    dairyCow = String(cow.data?._id);
  }, 180_000);
  afterAll(async () => { for (const c of Object.values(apps)) await stopApp(c); }, 60_000);

  for (const t of targets()) {
    it(`${t.app} POST ${t.route}: hostile bodies never 500`, async () => {
      const ctx = apps[t.app];
      for (const [label, hostile] of HOSTILE) {
        const body = t.textField && hostile && typeof hostile === 'object' && !Array.isArray(hostile)
          ? { ...t.valid(), [t.textField]: hostile }
          : hostile;
        const r = await raw(ctx, t.route, { method: 'POST', token: ctx.owner, body });
        expect(r.response.status, `${t.app}${t.route} ${label}`).toBeLessThan(500);
      }
    });
  }

  it('malformed JSON and wrong content-type never produce HTML 500 pages', async () => {
    for (const [name, ctx] of Object.entries(apps)) {
      const port = new URL(ctx.base).port;
      void port;
      const res = await fetch(`${ctx.base}/api${name === 'agri' ? '/crops' : name === 'flock' ? '/batches' : '/cows'}`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${ctx.owner}`, 'Content-Type': 'application/json' },
        body: '{definitely not json',
      });
      const text = await res.text();
      expect(res.status, `${name} malformed JSON status`).toBe(400);
      expect(text, `${name} malformed JSON leaks HTML stack page`).not.toMatch(/<html|SyntaxError:|at .*node_modules/);
    }
  });

  it('oversized body (11MB) is rejected as 4xx JSON, not a stack page', async () => {
    for (const [name, ctx] of Object.entries(apps)) {
      const route = name === 'agri' ? '/crops' : name === 'flock' ? '/batches' : '/cows';
      const res = await fetch(`${ctx.base}/api${route}`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${ctx.owner}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: 'x'.repeat(11 * 1024 * 1024) }),
      });
      const text = await res.text();
      expect(res.status, `${name} 11MB status`).toBeGreaterThanOrEqual(400);
      expect(res.status, `${name} 11MB status`).toBeLessThan(500);
      expect(text).not.toMatch(/<html|PayloadTooLargeError:/);
    }
  });

  it('query-param fuzz: operators & junk pagination never 500', async () => {
    const routes: Array<[string, string]> = [
      ['dairy', '/cows?limit[$gt]=1'], ['dairy', '/cows?limit=abc&skip=-9'], ['dairy', '/cows?search[$ne]=x'],
      ['dairy', '/cows?search=' + encodeURIComponent('.*'.repeat(200))], ['dairy', '/expenses?amount[$gte]=0'],
      ['flock', '/batches?limit=abc'], ['flock', '/batches?status[$ne]=x'],
      ['agri', '/crops?limit=abc&skip=-1'], ['agri', '/finance?amount[$gt]=0'], ['agri', '/crops?search[$regex]=.*'],
    ];
    for (const [name, route] of routes) {
      const r = await raw(apps[name], route, { token: apps[name].owner });
      expect(r.response.status, `${name} ${route}`).toBeLessThan(500);
      expect(r.response.status).not.toBe(401);
    }
  });

  it('prototype pollution did not stick on any server', async () => {
    for (const [name, ctx] of Object.entries(apps)) {
      const route = name === 'agri' ? '/crops?limit=1' : name === 'flock' ? '/batches' : '/cows?limit=1';
      const r = await raw(ctx, route, { token: ctx.owner });
      expect(JSON.stringify(r.data), `${name} responses carry polluted key`).not.toContain('"polluted":"yes"');
    }
    expect(({} as any).polluted).toBeUndefined();
  });

  it('deep-nesting and special numbers in JSON never 500', async () => {
    let deep: any = { name: `deep ${S}` };
    let cur = deep;
    for (let i = 0; i < 60; i++) { cur.a = { b: {} }; cur = cur.a; }
    const r = await raw(apps.dairy, '/cows', { method: 'POST', token: apps.dairy.owner, body: { ...deep, breed: 'Jersey' } });
    expect(r.response.status).toBeLessThan(500);
    // NaN/Infinity are not JSON-representable; test via raw string body
    const res = await fetch(`${apps.dairy.base}/api/expenses`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${apps.dairy.owner}`, 'Content-Type': 'application/json' },
      body: '{"date":"2026-09-04","type":"feed","amount":1e999}',
    });
    expect(res.status).toBeLessThan(500);
    expect(dairyCow).toBeTruthy();
  });
});
