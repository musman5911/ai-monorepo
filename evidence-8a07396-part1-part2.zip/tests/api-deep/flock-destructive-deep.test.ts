/**
 * ROUND 21 — Flock destructive + transfer surfaces on the
 * pulled tree: wipe-all, export/import-all scoping, monthly
 * auto-backup with image chunks, egg-log bulk invariants.
 * NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, rowsOf, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const TINY_PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');

describe.sequential('ROUND 21: flock destructive/transfer surfaces', () => {
  let ctx: Ctx; let batchId = '';
  beforeAll(async () => { ctx = await startApp('flock', 'flock_farm/backend'); }, 120_000);
  afterAll(async () => { await stopApp(ctx); }, 60_000);

  it('setup batch + worker cannot wipe-all or import-all', async () => {
    const b = await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, body: { name: `R21 Batch ${S}`, type: 'Layer', start_date: '2026-09-01', intake_count: 100, cost_per_bird: 10 } });
    expect(b.response.status).toBe(201);
    batchId = String((b.data as any)?.batch?.batch_id || (b.data as any)?.batch_id || idOf(b.data));
    const wipe = await raw(ctx, '/batches/wipe-all', { method: 'DELETE', token: ctx.worker });
    expect([401, 403], `worker wipe-all → ${wipe.response.status}`).toContain(wipe.response.status);
    const imp = await raw(ctx, '/batches/import-all', { method: 'POST', token: ctx.worker, body: { batches: [] } });
    expect([401, 403], `worker import-all → ${imp.response.status}`).toContain(imp.response.status);
    const still = await raw(ctx, `/batches/${batchId}`, { token: ctx.owner });
    expect(still.response.status).toBe(200);
  });

  it('egg-log bulk: broken eggs cannot exceed collected; totals stay consistent', async () => {
    const one = await raw(ctx, `/batches/${batchId}/egg-logs`, { method: 'POST', token: ctx.owner, body: { date: '2026-10-02', collected: 50, broken: 5 } });
    expect(one.response.status, `egg-log → ${one.response.status} ${JSON.stringify(one.data).slice(0, 120)}`).toBeLessThan(300);
    const bad = await raw(ctx, `/batches/${batchId}/egg-logs/bulk`, { method: 'POST', token: ctx.owner, body: { logs: [{ date: '2026-10-03', collected: 10, broken: 999 }] } });
    const after = await raw(ctx, `/batches/${batchId}`, { token: ctx.owner });
    const text = JSON.stringify(after.data);
    expect(text, 'broken(999) > collected(10) was persisted via bulk egg-logs').not.toContain('"broken":999');
    expect([200, 201, 400, 422], `bulk broken>collected → ${bad.response.status}`).toContain(bad.response.status);
  });

  it('export-all → wipe-all (owner) → import-all restores the batch', async () => {
    const exp = await raw(ctx, '/batches/export-all', { token: ctx.owner });
    expect(exp.response.status).toBe(200);
    expect(JSON.stringify(exp.data)).toContain(`R21 Batch ${S}`);
    const wipe = await raw(ctx, '/batches/wipe-all', { method: 'DELETE', token: ctx.owner });
    expect(wipe.response.status, `owner wipe-all → ${wipe.response.status}`).toBeLessThan(300);
    const gone = await raw(ctx, `/batches/${batchId}`, { token: ctx.owner });
    expect(gone.response.status).toBe(404);
    const imp = await raw(ctx, '/batches/import-all', { method: 'POST', token: ctx.owner, body: exp.data });
    expect(imp.response.status, `import-all → ${imp.response.status} ${JSON.stringify(imp.data).slice(0, 120)}`).toBeLessThan(300);
    const list = await raw(ctx, '/batches', { token: ctx.owner });
    expect(rowsOf(list.data).length, 'import-all restored nothing').toBeGreaterThan(0);
    expect(JSON.stringify(list.data)).toContain(`R21 Batch ${S}`);
  });

  it('monthly auto-backup preserves image bytes through restore-auto', async () => {
    const form = new FormData();
    form.append('image', new Blob([TINY_PNG], { type: 'image/png' }), 'tiny.png');
    const up = await fetch(`${ctx.base}/api/uploads/image?kind=bird`, { method: 'POST', headers: { Authorization: `Bearer ${ctx.owner}` }, body: form });
    expect(up.status).toBe(201);
    const { path } = await up.json() as { path: string };
    const run = await raw(ctx, '/backup/auto/run', { method: 'POST', token: ctx.owner });
    expect(run.response.status, `auto/run → ${run.response.status} ${JSON.stringify(run.data).slice(0, 120)}`).toBeLessThan(300);
    const restore = await raw(ctx, '/backup/restore-auto', { method: 'POST', token: ctx.owner });
    expect(restore.response.status, `restore-auto → ${restore.response.status}`).toBeLessThan(300);
    const img = await fetch(`${ctx.base}${path}`, { headers: { Authorization: `Bearer ${ctx.owner}` } });
    expect(img.status, 'image lost after monthly restore-auto').toBe(200);
    expect(Buffer.from(await img.arrayBuffer()).equals(TINY_PNG), 'image bytes corrupted by monthly chunk restore').toBe(true);
  });
});
