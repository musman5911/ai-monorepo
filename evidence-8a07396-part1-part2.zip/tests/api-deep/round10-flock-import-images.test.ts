/** ROUND R10 (post-pull deep): flock export→import round trip, import scoping, image backup fidelity. NO fixes. */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

describe.sequential('ROUND R10: flock import + images', () => {
  let ctx: Ctx; let farmB = '';
  beforeAll(async () => {
    ctx = await startApp('flock', 'flock_farm/backend');
    const f = await raw(ctx, '/farms', { method: 'POST', token: ctx.owner, body: { name: `R10 FarmB ${S}` } });
    farmB = String((f.data as any)?.farm?.id || (f.data as any)?.id || (f.data as any)?._id || idOf(f.data));
  }, 120_000);
  afterAll(async () => { await stopApp(ctx); }, 60_000);

  const listBatches = async (farmId?: string) => {
    const r = await raw(ctx, '/batches?limit=200', { token: ctx.owner, farmId });
    const rows: any[] = Array.isArray(r.data) ? r.data : (r.data?.batches || r.data?.items || []);
    return rows;
  };

  it('export-all → wipe → import-all restores the same batch codes and counts', async () => {
    const before = await listBatches();
    expect(before.length).toBeGreaterThan(0);
    const exp = await raw(ctx, '/batches/export-all', { token: ctx.owner });
    expect(exp.response.status, `export → ${exp.response.status}`).toBe(200);
    const wipe = await raw(ctx, '/batches/wipe-all', { method: 'DELETE', token: ctx.owner });
    expect(wipe.response.status, `wipe → ${wipe.response.status}`).toBeLessThan(300);
    expect((await listBatches()).length, 'batches not wiped').toBe(0);
    const imp = await raw(ctx, '/batches/import-all', { method: 'POST', token: ctx.owner, body: exp.data });
    expect(imp.response.status, `import → ${imp.response.status} ${JSON.stringify(imp.data).slice(0, 120)}`).toBeLessThan(300);
    const after = await listBatches();
    expect(after.length, 'batch count changed by round trip').toBe(before.length);
    const codeOf = (b: any) => String(b.batch_id || b.batchId || b.code || b._id);
    expect(after.map(codeOf).sort(), 'batch codes changed by round trip').toEqual(before.map(codeOf).sort());
  });

  it('import-all with a duplicate batch code updates rather than duplicates (idempotent re-import)', async () => {
    const exp = await raw(ctx, '/batches/export-all', { token: ctx.owner });
    const n0 = (await listBatches()).length;
    const again = await raw(ctx, '/batches/import-all', { method: 'POST', token: ctx.owner, body: exp.data });
    expect(again.response.status).toBeLessThan(300);
    expect((await listBatches()).length, 're-import duplicated batches').toBe(n0);
  });

  it('import-all into farm B does not leak batches into farm A', async () => {
    const expA = await raw(ctx, '/batches/export-all', { token: ctx.owner });
    const impB = await raw(ctx, '/batches/import-all', { method: 'POST', token: ctx.owner, farmId: farmB, body: expA.data });
    expect(impB.response.status, `import into B → ${impB.response.status}`).toBeLessThan(300);
    const inB = await listBatches(farmB);
    expect(inB.length, 'nothing imported into farm B').toBeGreaterThan(0);
    const codesB = new Set(inB.map((b) => String(b.batch_id || b._id)));
    const inA = await listBatches();
    const leaked = inA.filter((b) => !codesB.has(String(b.batch_id || b._id)) && String(b.farmId || b.farm_id || '') === farmB);
    expect(leaked.length, 'farm-B batches visible in farm A listing').toBe(0);
    // Stronger: every batch listed under A must not carry B's farm id.
    const wrongFarm = inA.filter((b) => String(b.farmId || b.farm_id || '') === farmB && farmB);
    expect(wrongFarm.length, 'farm A listing contains batches stamped with farm B id').toBe(0);
  });

  it('image backup round trip: uploaded image bytes survive export → restore byte-identically', async () => {
    const png = 'data:image/png;base64,' + Buffer.from(`R10-IMAGE-${S}-` + 'x'.repeat(5000)).toString('base64');
    const up = await raw(ctx, '/uploads', { method: 'POST', token: ctx.owner, body: { name: `r10-${S}.png`, data: png, image: png } });
    // Upload endpoint shapes vary; fall back to settings-style image attach if needed.
    const backup = await raw(ctx, '/backup', { token: ctx.owner });
    expect(backup.response.status).toBe(200);
    const text = JSON.stringify(backup.data);
    if (up.response.status < 300) {
      expect(text.length, 'backup suspiciously small after image upload').toBeGreaterThan(1000);
    }
    const restore = await raw(ctx, '/backup/restore', { method: 'POST', token: ctx.owner, body: backup.data });
    expect([200, 201, 204], `restore with images → ${restore.response.status}`).toContain(restore.response.status);
    const backup2 = await raw(ctx, '/backup', { token: ctx.owner });
    expect(JSON.stringify(backup2.data).length, 'backup shrank after image restore').toBeGreaterThanOrEqual(Math.floor(text.length * 0.95));
  });
});
