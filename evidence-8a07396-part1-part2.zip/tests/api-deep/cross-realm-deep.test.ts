/**
 * ROUND 4 — cross-app token replay (all apps share one JWT secret
 * in .env), restricted-worker farm escape, lost-update conflicts,
 * HTTP method/header smuggling. NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, rowsOf, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const apps: Record<string, Ctx> = {};
const LIST: Record<string, string> = { dairy: '/cows?limit=3', flock: '/batches', agri: '/crops?limit=3' };

async function firstFarmId(ctx: Ctx) {
  const r = await raw(ctx, '/farms', { token: ctx.owner });
  const rows = rowsOf(r.data).length ? rowsOf(r.data) : (r.data?.farms || []);
  return rows[0] ? String(rows[0]._id || rows[0].id) : '';
}
async function loginDirect(name: string, ctx: Ctx, u: string, p: string) {
  for (let i = 0; i < 8; i++) {
    const r = name === 'agri'
      ? await raw(ctx, '/login', { method: 'POST', form: { username: u, password: p } })
      : await raw(ctx, '/auth/login', { method: 'POST', body: { username: u, password: p } });
    const token = r.data?.token || r.data?.access_token || ''; if (!token) console.log('LDFAIL', r.response.status, JSON.stringify(r.data).slice(0,150));
    if (token) return token;
    await new Promise((res) => setTimeout(res, 400));
  }
  return '';
}

describe.sequential('ROUND 4: cross-realm + smuggling', () => {
  beforeAll(async () => {
    apps.dairy = await startApp('dairy', 'dairy_farm/backend');
    apps.flock = await startApp('flock', 'flock_farm/backend');
    apps.agri = await startApp('agri', 'agri_farm/backend');
  }, 180_000);
  afterAll(async () => { for (const c of Object.values(apps)) await stopApp(c); }, 60_000);

  it('cross-app token replay: a token from one app is rejected by the other two', async () => {
    const names = ['dairy', 'flock', 'agri'] as const;
    for (const from of names) {
      for (const to of names) {
        if (from === to) continue;
        const r = await raw(apps[to], LIST[to], { token: apps[from].owner });
        expect(r.response.status, `${from} owner token used on ${to}`).toBe(401);
      }
    }
  });

  it('dairy: worker assigned to Farm A cannot reach Farm B via X-Farm-Id', async () => {
    const ctx = apps.dairy;
    const farmA = await firstFarmId(ctx);
    // Farm B + a cow that lives only in Farm B
    const farmBRes = await raw(ctx, '/farms', { method: 'POST', token: ctx.owner, body: { name: `Realm Farm B ${S}` } });
    const farmB = String(farmBRes.data?.farm?.id || farmBRes.data?.id || farmBRes.data?.farm?._id || farmBRes.data?._id);
    expect(farmB).toBeTruthy();
    const cowB = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, farmId: farmB, body: { name: `Realm Cow B ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    const cowBId = idOf(cowB.data);
    expect(cowBId).toBeTruthy();

    // seeded worker was assigned only the default farm at seed time;
    // Farm B was created afterwards, so it must be out of their scope.
    const wtoken = ctx.worker;
    const listB = await raw(ctx, '/cows?limit=100', { token: wtoken, farmId: farmB });
    expect(JSON.stringify(listB.data), 'restricted worker listed Farm B cows').not.toContain(cowBId);
    const readB = await raw(ctx, `/cows/${cowBId}`, { token: wtoken, farmId: farmB });
    expect([403, 404], 'restricted worker read Farm B cow by id').toContain(readB.response.status);
    const updB = await raw(ctx, `/cows/${cowBId}`, { method: 'PUT', token: wtoken, farmId: farmB, body: { name: 'Escaped' } });
    expect([403, 404]).toContain(updB.response.status);

    await raw(ctx, `/cows/${cowBId}`, { method: 'DELETE', token: ctx.owner, farmId: farmB });
  });

  it('lost update: stale writer cannot silently overwrite (dairy)', async () => {
    const dctx = apps.dairy;
    const cow = await raw(dctx, '/cows', { method: 'POST', token: dctx.owner, body: { name: `LU Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    const cowId = idOf(cow.data);
    await raw(dctx, `/cows/${cowId}`, { method: 'PUT', token: dctx.owner, body: { name: `Writer One ${S}` } });
    const stale = await raw(dctx, `/cows/${cowId}`, { method: 'PUT', token: dctx.owner, body: { name: `Writer Two ${S}` } });
    expect(stale.response.status, 'dairy silent lost-update (no version/conflict check)').toBe(409);
    await raw(dctx, `/cows/${cowId}`, { method: 'DELETE', token: dctx.owner });
  });

  it('lost update: stale writer cannot silently overwrite (agri)', async () => {
    const actx = apps.agri;
    const crop = await raw(actx, '/crops', { method: 'POST', token: actx.owner, body: { name: `LU Crop ${S}`, status: 'Growing', plant_date: '2026-09-01' } });
    const cropId = idOf(crop.data);
    await raw(actx, `/crops/${cropId}`, { method: 'PUT', token: actx.owner, body: { name: `Writer One ${S}`, status: 'Growing', plant_date: '2026-09-01' } });
    const stale2 = await raw(actx, `/crops/${cropId}`, { method: 'PUT', token: actx.owner, body: { name: `Writer Two ${S}`, status: 'Growing', plant_date: '2026-09-01' } });
    expect(stale2.response.status, 'agri silent lost-update (no version/conflict check)').toBe(409);
    await raw(actx, `/crops/${cropId}`, { method: 'DELETE', token: actx.owner });
  });

  it('method smuggling: override headers/verbs cannot turn a POST into a DELETE', async () => {
    const ctx = apps.dairy;
    const cow = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { name: `SM Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    const cowId = idOf(cow.data);
    // X-HTTP-Method-Override
    const res1 = await fetch(`${ctx.base}/api/cows/${cowId}`, { method: 'POST', headers: { Authorization: `Bearer ${ctx.owner}`, 'Content-Type': 'application/json', 'X-HTTP-Method-Override': 'DELETE' }, body: '{}' });
    expect(res1.status).toBeLessThan(500);
    // _method in body
    await raw(ctx, `/cows/${cowId}`, { method: 'POST', token: ctx.owner, body: { _method: 'DELETE' } });
    const still = await raw(ctx, `/cows/${cowId}`, { token: ctx.owner });
    expect(still.response.status, 'record was deleted via method-override smuggling').toBe(200);
    // collection-level verbs
    for (const method of ['PUT', 'DELETE', 'PATCH']) {
      const r = await raw(ctx, '/cows', { method, token: ctx.owner, body: method === 'DELETE' ? undefined : {} });
      expect(r.response.status, `${method} /cows (no id)`).toBeLessThan(500);
      expect(r.response.status, `${method} /cows (no id) must not succeed`).not.toBe(200);
    }
    await raw(ctx, `/cows/${cowId}`, { method: 'DELETE', token: ctx.owner });
  });

  it('header smuggling: bogus X-Farm-Id does not unlock a merged all-farms view', async () => {
    for (const name of ['dairy', 'agri'] as const) {
      const ctx = apps[name];
      const r = await raw(ctx, LIST[name], { token: ctx.owner, farmId: 'nonexistent-farm-xyz' });
      expect([400, 403, 404], `${name} accepted bogus X-Farm-Id with ${r.response.status}`).toContain(r.response.status);
    }
    const ctx = apps.dairy;
    const huge = await fetch(`${ctx.base}/api/cows?limit=3`, { headers: { Authorization: `Bearer ${ctx.owner}`, 'X-Farm-Id': 'x'.repeat(8000) } });
    expect(huge.status).toBeLessThan(500);
  });

  it('content-type confusion: JSON body sent as text/plain is not processed as a create', async () => {
    const ctx = apps.dairy;
    const before = rowsOf((await raw(ctx, '/cows?limit=500', { token: ctx.owner })).data).length;
    const res = await fetch(`${ctx.base}/api/cows`, { method: 'POST', headers: { Authorization: `Bearer ${ctx.owner}`, 'Content-Type': 'text/plain' }, body: JSON.stringify({ name: `CT Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' }) });
    expect(res.status, `text/plain create returned ${res.status}`).toBeGreaterThanOrEqual(400);
    const after = rowsOf((await raw(ctx, '/cows?limit=500', { token: ctx.owner })).data).length;
    expect(after).toBe(before);
  });
});
