/**
 * ROUND 20 — Agri analytics summary exactness, all-farms
 * behaviour, and cross-farm bulk-import isolation (b6efc64).
 * NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

describe.sequential('ROUND 20: agri analytics + bulk isolation', () => {
  let ctx: Ctx;
  beforeAll(async () => { ctx = await startApp('agri', 'agri_farm/backend'); }, 120_000);
  afterAll(async () => { await stopApp(ctx); }, 60_000);

  async function farmB() {
    const r = await raw(ctx, '/farms', { method: 'POST', token: ctx.owner, body: { name: `R20 FarmB ${S}-${Math.random().toString(36).slice(2,8)}` } });
    expect([200, 201]).toContain(r.response.status);
    return String(r.data?.farm?.id || r.data?.id || r.data?.farm?._id || r.data?._id);
  }

  it('summary totals equal the ledger sums for the active farm only', async () => {
    const b = await farmB();
    const mk = (farmId: string, amount: number, type: string) => raw(ctx, '/finance', {
      method: 'POST', token: ctx.owner, farmId,
      body: { type, amount, category: `R20CAT${S}`, date: '2026-10-05', description: `R20 ${S}` },
    });
    expect((await mk(ctx.farmIdA, 1111, 'income')).response.status).toBeLessThan(300);
    expect((await mk(ctx.farmIdA, 2222, 'expense')).response.status).toBeLessThan(300);
    expect((await mk(b, 777777, 'income')).response.status).toBeLessThan(300);
    const sum = await raw(ctx, '/analytics/summary', { token: ctx.owner, farmId: ctx.farmIdA });
    expect(sum.response.status).toBe(200);
    const text = JSON.stringify(sum.data);
    expect(text, 'farm A income missing from its own summary').toContain('1111');
    expect(text, 'farm B income leaked into farm A summary').not.toContain('777777');
    const sumB = await raw(ctx, '/analytics/summary', { token: ctx.owner, farmId: b });
    expect(JSON.stringify(sumB.data), 'farm B summary missing its income').toContain('777777');
    expect(JSON.stringify(sumB.data), 'farm A income leaked into farm B summary').not.toContain('1111');
  });

  it('all-farms summary: owner gets a combined (read) view or a clean scope, worker gets assigned-only', async () => {
    const ownerAll = await raw(ctx, '/analytics/summary', { token: ctx.owner, farmId: 'all' });
    expect(ownerAll.response.status, `owner all-farms summary → ${ownerAll.response.status}`).toBe(200);
    const workerAll = await raw(ctx, '/analytics/summary', { token: ctx.worker, farmId: 'all' });
    expect(workerAll.response.status).toBe(200);
    expect(JSON.stringify(workerAll.data), 'worker all-farms summary contains farm totals').not.toContain('777777');
    expect(JSON.stringify(workerAll.data), 'worker all-farms summary contains income marker').not.toContain('1111');
  });

  it('cross-farm bulk import: finance rows naming a farm-B crop cannot be planted from farm A', async () => {
    const b = await farmB();
    const cropB = await raw(ctx, '/crops', { method: 'POST', token: ctx.owner, farmId: b, body: { name: `R20 CropB ${S}`, status: 'Growing', plant_date: '2026-10-01' } });
    const cropBId = idOf(cropB.data);
    expect(cropBId, `cropB create → ${cropB.response.status} ${JSON.stringify(cropB.data).slice(0, 140)} farm=${b}`).toBeTruthy();
    const bulk = await raw(ctx, '/finance/bulk', {
      method: 'POST', token: ctx.owner, farmId: ctx.farmIdA,
      body: { rows: [{ type: 'expense', amount: 31337, category: `R20X${S}`, date: '2026-10-06', crop_id: cropBId, description: `R20X ${S}` }] },
    });
    const listB = await raw(ctx, '/finance?limit=50', { token: ctx.owner, farmId: b });
    expect(JSON.stringify(listB.data), 'bulk row cross-planted into farm B').not.toContain('31337');
    const listA = await raw(ctx, '/finance?limit=50', { token: ctx.owner, farmId: ctx.farmIdA });
    const inA = JSON.stringify(listA.data).includes('31337');
    if (inA) {
      // Row landed in A but still references B's crop → dangling cross-farm link.
      expect(JSON.stringify(listA.data), 'farm A row keeps a farm-B crop_id (cross-farm link)').not.toContain(cropBId);
    }
    expect([200, 201, 400, 422], `bulk → ${bulk.response.status}`).toContain(bulk.response.status);
  });

  it('summary never echoes photo blobs or secrets', async () => {
    const sum = await raw(ctx, '/analytics/summary', { token: ctx.owner });
    const text = JSON.stringify(sum.data);
    expect(text).not.toMatch(/data:image|password|secret|token/i);
  });
});
