/**
 * ROUND 15 — Telegram bot write-path (dairy): link lifecycle,
 * fabricated/reused codes, bot-created milk/expense records,
 * unbounded bot expense amounts. Server spawned with a known
 * TELEGRAM_WEBHOOK_SECRET via process env (harness passes env
 * through). NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, rowsOf, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const WH = 'round15-webhook-secret';
let ctx: Ctx;

async function hook(chatId: number, text: string, secret = WH) {
  const res = await fetch(`${ctx.base}/api/telegram/webhook/${secret}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message: { chat: { id: chatId }, from: { first_name: 'Probe' }, text } }),
  });
  expect(res.status).toBeLessThan(500);
  // bot replies are sent server->Telegram (unobservable); give handlers a beat
  await new Promise((r) => setTimeout(r, 350));
}
async function expensesWith(notePart: string) {
  const list = await raw(ctx, '/expenses?limit=500', { token: ctx.owner });
  return rowsOf(list.data).filter((e: any) => String(e.note || '').includes(notePart));
}

describe.sequential('ROUND 15: telegram bot write-path', () => {
  beforeAll(async () => {
    process.env.TELEGRAM_WEBHOOK_SECRET = WH;
    ctx = await startApp('dairy', 'dairy_farm/backend');
  }, 120_000);
  afterAll(async () => { await stopApp(ctx); delete process.env.TELEGRAM_WEBHOOK_SECRET; }, 60_000);

  it('bot is live: owner can mint a link code for a laborer', async () => {
    const worker = await raw(ctx, '/labor/workers', { method: 'POST', token: ctx.owner, body: { name: `TG Worker ${S}`, dailyWage: 1000 } });
    expect([200, 201]).toContain(worker.response.status);
    const workerId = idOf(worker.data);
    expect(workerId).toBeTruthy();
    (globalThis as any).__tgWorker = workerId;
    const code = await raw(ctx, '/telegram/link-code', { method: 'POST', token: ctx.owner, body: { laborerId: workerId } });
    expect(code.response.status, `link-code → ${code.response.status} ${JSON.stringify(code.data).slice(0, 120)}`).toBe(200);
    expect(String(code.data.code)).toMatch(/^\d{4,8}$/);
    (globalThis as any).__tgCode = String(code.data.code);
    const workerMint = await raw(ctx, '/telegram/link-code', { method: 'POST', token: ctx.worker, body: { laborerId: workerId } });
    expect([401, 403]).toContain(workerMint.response.status);
  });

  it('unlinked chat cannot write data, even with the correct webhook secret', async () => {
    await hook(900001, 'kharcha 555 uniquemarker-unlinked');
    const found = await expensesWith('uniquemarker-unlinked');
    expect(found.length, 'unlinked telegram chat created an expense').toBe(0);
  });

  it('fabricated link code does not link a chat', async () => {
    await hook(900002, '/start 000000');
    await hook(900002, 'kharcha 556 uniquemarker-fakecode');
    expect((await expensesWith('uniquemarker-fakecode')).length).toBe(0);
  });

  it('properly linked chat CAN log an expense and milk via the bot', async () => {
    const code = (globalThis as any).__tgCode as string;
    await hook(900003, `/start ${code}`);
    await hook(900003, 'kharcha 777 uniquemarker-linked');
    const found = await expensesWith('uniquemarker-linked');
    expect(found.length, 'linked chat expense not recorded').toBe(1);
    expect(Number(found[0].amount)).toBe(777);

    const cow = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { name: `BellaTG${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    const cowId = idOf(cow.data);
    await hook(900003, `doodh BellaTG${S} 9`);
    const milk = rowsOf((await raw(ctx, `/milk?cowId=${cowId}&limit=100`, { token: ctx.owner })).data);
    const total = milk.reduce((a: number, m: any) => a + Number(m.morning || 0) + Number(m.evening || 0), 0);
    expect(total, 'bot milk entry missing').toBe(9);
    (globalThis as any).__tgCow = cowId;
  });

  it('a consumed link code cannot be reused by a second chat', async () => {
    const code = (globalThis as any).__tgCode as string;
    await hook(900004, `/start ${code}`);
    await hook(900004, 'kharcha 558 uniquemarker-reused');
    expect((await expensesWith('uniquemarker-reused')).length, 'reused link code linked a second chat').toBe(0);
  });

  it('bot expense amounts are bounded (no crore-scale single message)', async () => {
    await hook(900003, 'kharcha 999999999 uniquemarker-huge');
    const found = await expensesWith('uniquemarker-huge');
    expect(found.length, 'bot accepted a 999,999,999 expense from one chat message').toBe(0);
  });

  it('wrong webhook secret performs no writes', async () => {
    await hook(900005, 'kharcha 559 uniquemarker-wrongsecret', 'totally-wrong-secret');
    expect((await expensesWith('uniquemarker-wrongsecret')).length).toBe(0);
  });
});
