/** ROUND 12 (Phase 9): Cloudinary/photo storage — fallback (no Cloudinary env) + fake-configured mode. Dairy+Agri /photos, Flock /uploads+/images. NO fixes. */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const PNG_1PX = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
const SVG_EVIL = 'data:image/svg+xml;base64,' + Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>').toString('base64');
const HTML_AS_PNG = 'data:image/png;base64,' + Buffer.from('<html><script>alert(1)</script></html>').toString('base64');
// Minimal JPEG: SOI + APP1 Exif segment carrying a GPS marker string + EOI.
const jpegExif = Buffer.concat([
  Buffer.from([0xff, 0xd8, 0xff, 0xe1, 0x00, 0x22]),
  Buffer.from('Exif\0\0GPSMARKER-31.5204-74.3587-PADDING', 'latin1'),
  Buffer.from([0xff, 0xd9]),
]);
const JPEG_EXIF = 'data:image/jpeg;base64,' + jpegExif.toString('base64');

async function makeManager(ctx: Ctx, app: string, farmId: string, tag: string): Promise<string> {
  const uname = `p12${tag}${S}`;
  const body = app === 'agri'
    ? { username: uname, password: '[SECURITY_DATA]', role: 'manager', email: `${uname}@t.local`, farmIds: [farmId] }
    : { username: uname, password: '[SECURITY_DATA]', role: 'manager', email: `${uname}@t.local`, farmIds: [farmId], displayName: uname };
  const path = app === 'agri' ? '/signup' : '/auth/users';
  const r = await raw(ctx, path, { method: 'POST', token: ctx.owner, body });
  expect([200, 201], `create manager ${tag} → ${r.response.status} ${JSON.stringify(r.data).slice(0, 120)}`).toContain(r.response.status);
  const loginPath = app === 'agri' ? '/login' : '/auth/login';
  const l = await raw(ctx, loginPath, { method: 'POST', body: { username: uname, password: '[SECURITY_DATA]' } });
  return String((l.data as any)?.token || (l.data as any)?.access_token || '');
}

for (const app of ['dairy', 'agri'] as const) {
  describe.sequential(`ROUND 12: photos (${app}, fallback mode)`, () => {
    let ctx: Ctx; let farmA = ''; let farmB = ''; let mgrA = ''; let photoA = ''; let photoB = '';
    beforeAll(async () => {
      ctx = await startApp(app, `${app}_farm/backend`);
      const farms = await raw(ctx, '/farms', { token: ctx.owner });
      farmA = String(((farms.data as any)?.farms || [])[0]?.id || '');
      const fb = await raw(ctx, '/farms', { method: 'POST', token: ctx.owner, body: { name: `P12 FarmB ${S} ${app}` } });
      farmB = String((fb.data as any)?.id || idOf(fb.data));
      mgrA = await makeManager(ctx, app, farmA, `mgr${app}`);
      const upA = await raw(ctx, '/photos', { method: 'POST', token: ctx.owner, farmId: farmA, body: { data: PNG_1PX } });
      expect(upA.response.status, `upload A → ${upA.response.status} ${JSON.stringify(upA.data).slice(0, 120)}`).toBe(201);
      photoA = String((upA.data as any)?.id || '');
      const upB = await raw(ctx, '/photos', { method: 'POST', token: ctx.owner, farmId: farmB, body: { data: PNG_1PX } });
      photoB = String((upB.data as any)?.id || '');
      expect(photoA && photoB).toBeTruthy();
    }, 180_000);
    afterAll(async () => { await stopApp(ctx); }, 60_000);

    it('unauthenticated photo read gets no bytes and no cloud URL leak', async () => {
      const res = await fetch(`${ctx.base}/api/photos/${photoA}`);
      const body = await res.text();
      expect([401, 403], `unauth GET photo → ${res.status}`).toContain(res.status);
      expect(body).not.toContain('cloudinary');
      expect(res.headers.get('location') || '').not.toContain('cloudinary');
    });

    it('farm isolation: manager of A cannot read or delete farm B photo (403/404)', async () => {
      const read = await raw(ctx, `/photos/${photoB}`, { token: mgrA });
      expect([403, 404], `mgrA read photoB → ${read.response.status}`).toContain(read.response.status);
      const del = await raw(ctx, `/photos/${photoB}`, { method: 'DELETE', token: mgrA });
      expect([403, 404], `mgrA delete photoB → ${del.response.status}`).toContain(del.response.status);
      const stillThere = await raw(ctx, `/photos/${photoB}`, { token: ctx.owner, farmId: farmB });
      expect(stillThere.response.status, 'photoB gone after foreign delete attempt').toBe(200);
    });

    it('cache headers: photo responses are private, never public', async () => {
      const res = await fetch(`${ctx.base}/api/photos/${photoA}`, { headers: { Authorization: `Bearer ${ctx.owner}`, 'X-Farm-Id': farmA } });
      expect(res.status).toBe(200);
      const cc = (res.headers.get('cache-control') || '').toLowerCase();
      expect(cc, `cache-control: ${cc}`).toContain('private');
      expect(cc).not.toContain('public');
      expect(res.headers.get('content-type') || '').toContain('image');
    });

    it('upload validation: SVG, HTML-as-PNG, empty, wrong field all rejected 4xx', async () => {
      for (const [name, body] of [
        ['svg', { data: SVG_EVIL }],
        ['html-as-png', { data: HTML_AS_PNG }],
        ['empty-data', { data: 'data:image/png;base64,' }],
        ['wrong-field', { image: PNG_1PX }],
        ['text-html', { data: 'data:text/html;base64,SGVsbG8=' }],
      ] as const) {
        const r = await raw(ctx, '/photos', { method: 'POST', token: ctx.owner, farmId: farmA, body });
        expect(r.response.status, `${name} → ${r.response.status} ${JSON.stringify(r.data).slice(0, 80)}`).toBeGreaterThanOrEqual(400);
        expect(r.response.status).toBeLessThan(500);
      }
    });

    it('EXIF/GPS: uploaded JPEG bytes are served back — is EXIF stripped?', async () => {
      const up = await raw(ctx, '/photos', { method: 'POST', token: ctx.owner, farmId: farmA, body: { data: JPEG_EXIF } });
      expect(up.response.status, `jpeg exif upload → ${up.response.status}`).toBeLessThan(300);
      const id = String((up.data as any)?.id || '');
      const res = await fetch(`${ctx.base}/api/photos/${id}`, { headers: { Authorization: `Bearer ${ctx.owner}`, 'X-Farm-Id': farmA } });
      const buf = Buffer.from(await res.arrayBuffer());
      expect(buf.includes('GPSMARKER'), 'EXIF GPS marker still present in served bytes (not stripped)').toBe(false);
    });

    it('role checks: worker upload/delete behaviour is explicit', async () => {
      const up = await raw(ctx, '/photos', { method: 'POST', token: ctx.worker, farmId: farmA, body: { data: PNG_1PX } });
      // Any logged-in user may upload in current design; record either way but deletion must be fenced.
      const wid = String((up.data as any)?.id || photoA);
      const del = await raw(ctx, `/photos/${wid}`, { method: 'DELETE', token: ctx.worker });
      expect([403, 404], `worker delete photo → ${del.response.status}`).toContain(del.response.status);
      void up;
    });

    it('delete integrity: referenced photo blocked (409); orphan cleanup removes only orphans', async () => {
      if (app === 'dairy') {
        const cow = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, farmId: farmA, body: { name: `P12 Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active', image: `/api/photos/${photoA}` } });
        expect([200, 201]).toContain(cow.response.status);
        const del = await raw(ctx, `/photos/${photoA}`, { method: 'DELETE', token: ctx.owner, farmId: farmA });
        expect(del.response.status, `delete referenced photo → ${del.response.status}`).toBe(409);
      }
      const orphans = await raw(ctx, '/photos/orphans', { token: ctx.owner, farmId: farmB });
      expect(orphans.response.status, `orphans list → ${orphans.response.status}`).toBe(200);
      const before = await raw(ctx, `/photos/${photoB}`, { token: ctx.owner, farmId: farmB });
      expect(before.response.status, 'photoB should survive orphan listing').toBe(200);
    });

    it('photos survive backup? dairy/agri backup must contain the photo or its bytes', async () => {
      const path = app === 'agri' ? '/backup' : '/backup';
      const bak = await raw(ctx, path, { token: ctx.owner });
      expect(bak.response.status).toBe(200);
      const text = JSON.stringify(bak.data);
      expect(text.includes(photoA), 'photo id absent from backup (photos lost on restore)').toBe(true);
    });

    it('id guessing: random/malformed photo ids → 404, never bytes', async () => {
      for (const bad of ['000000000000000000000000', 'not-an-id', '../../etc/passwd', photoA.slice(0, 12)]) {
        const r = await raw(ctx, `/photos/${bad}`, { token: ctx.owner, farmId: farmA });
        expect([400, 404], `GET /photos/${bad} → ${r.response.status}`).toContain(r.response.status);
      }
    });
  });
}

describe.sequential('ROUND 12: photos with FAKE Cloudinary config (configured-mode error paths)', () => {
  it('dairy: upload with unreachable Cloudinary fails cleanly and leaks no secret', async () => {
    const { spawn } = await import('node:child_process');
    const port = 18511;
    const proc = spawn(process.execPath, ['server.js'], {
      cwd: 'dairy_farm/backend',
      env: { ...process.env, PORT: String(port), MEMORY_MODE: '1', JWT_SECRET: 'testingcake987', DISABLE_INTERNAL_SCHEDULER: '1', NODE_ENV: 'test', CLOUDINARY_CLOUD_NAME: 'testcloud', CLOUDINARY_API_KEY: '[SECURITY_DATA]', CLOUDINARY_API_SECRET: '[SECURITY_DATA]' },
      stdio: 'ignore',
    });
    try {
      const base = `http://127.0.0.1:${port}/api`;
      for (let i = 0; i < 40; i++) { try { const r = await fetch(`${base}/farms`); if (r.status) break; } catch { await new Promise((r) => setTimeout(r, 400)); } }
      const login = await (await fetch(`${base}/auth/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'admin', password: 'admin123' }) })).json() as any;
      const res = await fetch(`${base}/photos`, { method: 'POST', headers: { Authorization: `Bearer ${login.token}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ data: PNG_1PX }) });
      const text = await res.text();
      expect(text, 'cloudinary secret leaked in error response').not.toContain('sekrit-test-987');
      expect(text).not.toContain('123456789');
      expect(res.status, `configured-broken upload → ${res.status} ${text.slice(0, 120)}`).toBeGreaterThanOrEqual(400);
    } finally { proc.kill('SIGTERM'); }
  }, 120_000);
});
