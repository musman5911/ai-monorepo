/**
 * ROUND 24 — mass-assignment farm transfer: can a create/
 * update body smuggle a record into ANOTHER farm by naming
 * its farm id, bypassing the X-Farm-Id scope? Agri focus
 * (raw insertMany/$set routes) + dairy cow control.
 * NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

describe.sequential('ROUND 24: farm-transfer mass assignment', () => {
  let agri: Ctx; let dairy: Ctx; let farmB = '';
  beforeAll(async () => {
    agri = await startApp('agri', 'agri_farm/backend');
    dairy = await startApp('dairy', 'dairy_farm/backend');
    const r = await raw(agri, '/farms', { method: 'POST', token: agri.owner, body: { name: `R24 FarmB ${S}` } });
    farmB = String(r.data?.farm?.id || r.data?.id || r.data?.farm?._id || r.data?._id);
    expect(farmB).toBeTruthy();
  }, 180_000);
  afterAll(async () => { await stopApp(agri); await stopApp(dairy); }, 60_000);

  it('agri inventory PUT cannot move an item into farm B via body farmId', async () => {
    const c = await raw(agri, '/inventory', { method: 'POST', token: agri.owner, body: { name: `R24 Item ${S}`, quantity: 3, unit: 'bags' } });
    const itemId = idOf(c.data);
    expect(itemId).toBeTruthy();
    await raw(agri, `/inventory/${itemId}`, { method: 'PUT', token: agri.owner, body: { farmId: farmB, farm_id: farmB } });
    const inB = await raw(agri, '/inventory', { token: agri.owner, farmId: farmB });
    expect(JSON.stringify(inB.data), 'inventory item was transferred into farm B by body farmId').not.toContain(`R24 Item ${S}`);
    const inA = await raw(agri, '/inventory', { token: agri.owner });
    expect(JSON.stringify(inA.data), 'inventory item vanished from farm A').toContain(`R24 Item ${S}`);
  });

  it('agri liability CREATE with body farmId of farm B stays in the active farm', async () => {
    const c = await raw(agri, '/liabilities', { method: 'POST', token: agri.owner, body: { creditor: `R24 Cred ${S}`, amount_owed: 123, farmId: farmB, farm_id: farmB } });
    expect(c.response.status).toBe(201);
    const inB = await raw(agri, '/liabilities', { token: agri.owner, farmId: farmB });
    expect(JSON.stringify(inB.data), 'liability was planted into farm B by body farmId').not.toContain(`R24 Cred ${S}`);
  });

  it('agri crop CREATE with body farmId of farm B stays in the active farm', async () => {
    const c = await raw(agri, '/crops', { method: 'POST', token: agri.owner, body: { name: `R24 Crop ${S}`, status: 'Growing', plant_date: '2026-10-01', farmId: farmB, farm_id: farmB } });
    expect([200, 201]).toContain(c.response.status);
    const inB = await raw(agri, '/crops?limit=50', { token: agri.owner, farmId: farmB });
    expect(JSON.stringify(inB.data), 'crop was planted into farm B by body farmId').not.toContain(`R24 Crop ${S}`);
  });

  it('dairy cow CREATE with body farmId of another farm stays in the active farm (control)', async () => {
    const f = await raw(dairy, '/farms', { method: 'POST', token: dairy.owner, body: { name: `R24 DairyB ${S}` } });
    const dB = String(f.data?.farm?.id || f.data?.id || f.data?.farm?._id || f.data?._id);
    const c = await raw(dairy, '/cows', { method: 'POST', token: dairy.owner, body: { name: `R24 Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active', farmId: dB, farm_id: dB } });
    expect([200, 201]).toContain(c.response.status);
    const inB = await raw(dairy, '/cows?limit=50', { token: dairy.owner, farmId: dB });
    expect(JSON.stringify(inB.data), 'cow was planted into farm B by body farmId').not.toContain(`R24 Cow ${S}`);
  });
});
