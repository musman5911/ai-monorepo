/** ROUND 11 (Phase 7): farms/manager/admin/worker role system — owner omnipotence, manager assigned-farm scope, escalation. NO fixes. */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

describe.sequential('ROUND 11: role system (dairy deep)', () => {
  let ctx: Ctx;
  let farmA = ''; let farmB = '';
  let mgrA = ''; let mgrAId = ''; let mgrB = '';

  const loginAs = async (u: string, p: string) => {
    const r = await raw(ctx, '/auth/login', { method: 'POST', body: { username: u, password: p } });
    expect(r.response.status, `login ${u} → ${r.response.status}`).toBe(200);
    return String((r.data as any)?.token || '');
  };
  const mkUser = async (username: string, role: string, farmIds: string[]) => {
    const r = await raw(ctx, '/auth/users', { method: 'POST', token: ctx.owner, body: { username, password: 'RoleTest123!', role, email: `${username}@test.local`, farmIds, displayName: username } });
    expect([200, 201], `create ${username} → ${r.response.status} ${JSON.stringify(r.data).slice(0, 140)}`).toContain(r.response.status);
    return String((r.data as any)?.user?.id || (r.data as any)?.user?._id || idOf((r.data as any)?.user || r.data));
  };

  beforeAll(async () => {
    ctx = await startApp('dairy', 'dairy_farm/backend');
    const farms = await raw(ctx, '/farms', { token: ctx.owner });
    const list = (farms.data as any)?.farms || [];
    farmA = String(list[0]?.id || list[0]?._id || '');
    const fb = await raw(ctx, '/farms', { method: 'POST', token: ctx.owner, body: { name: `R11 FarmB ${S}` } });
    farmB = String((fb.data as any)?.id || idOf(fb.data));
    expect(farmA && farmB && farmA !== farmB).toBeTruthy();
    mgrAId = await mkUser(`r11mgra${S}`, 'manager', [farmA]);
    await mkUser(`r11mgrb${S}`, 'manager', [farmB]);
    await mkUser(`r11wrka${S}`, 'worker', [farmA]);
    mgrA = await loginAs(`r11mgra${S}`, 'RoleTest123!');
    mgrB = await loginAs(`r11mgrb${S}`, 'RoleTest123!');
  }, 180_000);
  afterAll(async () => { await stopApp(ctx); }, 60_000);

  it('owner can do everything: farms, users of any role, all-farm mode, summary, backup', async () => {
    const all = await raw(ctx, '/cows?limit=5', { token: ctx.owner, farmId: 'all' });
    expect(all.response.status, `owner all-mode → ${all.response.status}`).toBe(200);
    const sum = await raw(ctx, '/super-admin/farm-summary', { token: ctx.owner });
    expect(sum.response.status).toBe(200);
    const bak = await raw(ctx, '/backup', { token: ctx.owner });
    expect(bak.response.status).toBe(200);
  });

  it('manager sees only assigned farms in GET /farms; unassigned farm header → 403', async () => {
    const farms = await raw(ctx, '/farms', { token: mgrA });
    const list = (farms.data as any)?.farms || [];
    const ids = list.map((f: any) => String(f.id || f._id));
    expect(ids, `manager farm list ${ids} should contain A`).toContain(farmA);
    expect(ids).not.toContain(farmB);
    const forbidden = await raw(ctx, '/cows?limit=5', { token: mgrA, farmId: farmB });
    expect(forbidden.response.status, `manager with farm-B header → ${forbidden.response.status}`).toBe(403);
  });

  it('manager data scope: B cows never leak; all-mode limited to assigned; writes in all-mode → 400', async () => {
    const cowB = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, farmId: farmB, body: { name: `R11 BCow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    expect([200, 201]).toContain(cowB.response.status);
    const inB = await raw(ctx, '/cows?limit=100', { token: mgrB, farmId: farmB });
    expect(JSON.stringify(inB.data)).toContain(`R11 BCow ${S}`);
    const mgrAAll = await raw(ctx, '/cows?limit=100', { token: mgrA, farmId: 'all' });
    expect(mgrAAll.response.status).toBe(200);
    expect(JSON.stringify(mgrAAll.data), 'manager A all-mode leaks farm B cow').not.toContain(`R11 BCow ${S}`);
    const writeAll = await raw(ctx, '/cows', { method: 'POST', token: mgrA, farmId: 'all', body: { name: `R11 AllWrite ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    expect(writeAll.response.status, `manager write in all-mode → ${writeAll.response.status}`).toBe(400);
  });

  it('manager writes land in assigned farm even when body smuggles farmId of farm B', async () => {
    const c = await raw(ctx, '/cows', { method: 'POST', token: mgrA, farmId: farmA, body: { name: `R11 Smuggle ${S}`, breed: 'Jersey', gender: 'female', status: 'active', farmId: farmB } as any });
    expect([200, 201], `manager create cow → ${c.response.status}`).toContain(c.response.status);
    const inB = await raw(ctx, '/cows?limit=100', { token: ctx.owner, farmId: farmB });
    expect(JSON.stringify(inB.data), 'smuggled cow landed in farm B').not.toContain(`R11 Smuggle ${S}`);
    const inA = await raw(ctx, '/cows?limit=100', { token: mgrA, farmId: farmA });
    expect(JSON.stringify(inA.data), 'manager cow missing from farm A').toContain(`R11 Smuggle ${S}`);
  });

  it('manager cannot administer: create/archive/delete farm, create manager, super-admin summary', async () => {
    const mkFarm = await raw(ctx, '/farms', { method: 'POST', token: mgrA, body: { name: `R11 MgrFarm ${S}` } });
    expect([401, 403], `manager create farm → ${mkFarm.response.status}`).toContain(mkFarm.response.status);
    const arch = await raw(ctx, `/farms/${farmA}/archive`, { method: 'POST', token: mgrA, body: {} });
    expect([401, 403], `manager archive farm → ${arch.response.status}`).toContain(arch.response.status);
    const delFarm = await raw(ctx, `/farms/${farmB}`, { method: 'DELETE', token: mgrA, body: { confirmName: `R11 FarmB ${S}`, deleteData: true } });
    expect([401, 403], `manager delete farm → ${delFarm.response.status}`).toContain(delFarm.response.status);
    const mkMgr = await raw(ctx, '/auth/users', { method: 'POST', token: mgrA, body: { username: `r11evil${S}`, password: 'RoleTest123!', role: 'manager', email: `evil${S}@test.local`, farmIds: [farmA] } });
    expect([401, 403], `manager creates manager → ${mkMgr.response.status}`).toContain(mkMgr.response.status);
    const sum = await raw(ctx, '/super-admin/farm-summary', { token: mgrA });
    expect([401, 403], `manager super-admin summary → ${sum.response.status}`).toContain(sum.response.status);
  });

  it('manager manages workers of own farm only: create worker in A ok; B-only worker impossible', async () => {
    const wOk = await raw(ctx, '/auth/users', { method: 'POST', token: mgrA, body: { username: `r11wok${S}`, password: 'RoleTest123!', role: 'worker', farmIds: [farmA] } });
    expect([200, 201], `manager creates worker in A → ${wOk.response.status} ${JSON.stringify(wOk.data).slice(0, 120)}`).toContain(wOk.response.status);
    const wB = await raw(ctx, '/auth/users', { method: 'POST', token: mgrA, body: { username: `r11wbad${S}`, password: 'RoleTest123!', role: 'worker', farmIds: [farmB] } });
    if (wB.response.status < 300) {
      const tok = await loginAs(`r11wbad${S}`, 'RoleTest123!');
      const probe = await raw(ctx, '/cows?limit=5', { token: tok, farmId: farmB });
      expect(probe.response.status, 'manager-created B worker can access farm B').toBe(403);
    } else {
      expect([400, 403]).toContain(wB.response.status);
    }
  });

  it('escalation: manager cannot raise own role or widen own farmIds (PATCH self)', async () => {
    const selfRole = await raw(ctx, `/auth/users/${mgrAId}`, { method: 'PATCH', token: mgrA, body: { adminPassword: 'RoleTest123!', role: 'owner' } });
    expect(selfRole.response.status, `manager self role-escalation → ${selfRole.response.status}`).toBeGreaterThanOrEqual(400);
    const selfFarms = await raw(ctx, `/auth/users/${mgrAId}`, { method: 'PATCH', token: mgrA, body: { adminPassword: 'RoleTest123!', farmIds: [farmA, farmB] } });
    if (selfFarms.response.status < 300) {
      const probe = await raw(ctx, '/cows?limit=5', { token: mgrA, farmId: farmB });
      expect(probe.response.status, 'manager widened own farmIds to B').toBe(403);
    }
    const me = await raw(ctx, '/auth/me', { token: mgrA });
    expect(JSON.stringify(me.data), 'manager role changed to owner').not.toContain('"role":"owner"');
  });

  it('CRITICAL scope check: manager backup must not expose other farms; restore blocked or scoped', async () => {
    const bak = await raw(ctx, '/backup', { token: mgrA });
    if (bak.response.status === 200) {
      expect(JSON.stringify(bak.data), 'manager backup contains farm B cow (unscoped full-DB export)').not.toContain(`R11 BCow ${S}`);
    } else {
      expect([401, 403], `manager backup → ${bak.response.status}`).toContain(bak.response.status);
    }
    const restore = await raw(ctx, '/backup/restore', { method: 'POST', token: mgrA, body: {} });
    expect([400, 401, 403, 422], `manager restore junk → ${restore.response.status}`).toContain(restore.response.status);
  });
});
