/**
 * ROUND 6 (Tier C) — ID traversal fuzz, sort/filter injection,
 * Unicode round-trip integrity, Flock upload abuse (SVG/script).
 * NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, rowsOf, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const apps: Record<string, Ctx> = {};

describe.sequential('ROUND 6: ids, unicode, uploads', () => {
  beforeAll(async () => {
    apps.dairy = await startApp('dairy', 'dairy_farm/backend');
    apps.flock = await startApp('flock', 'flock_farm/backend');
    apps.agri = await startApp('agri', 'agri_farm/backend');
  }, 180_000);
  afterAll(async () => { for (const c of Object.values(apps)) await stopApp(c); }, 60_000);

  it('id traversal fuzz: weird ids are clean 404s, never 500 or cross-resource data', async () => {
    const weird = ['..%2ffarms', '%2e%2e%2ffarms', '..;/farms', '0', '-1', 'null', 'undefined', '507f1f77bcf86cd799439011', '%00', 'a'.repeat(200)];
    const targets: Array<[string, string]> = [
      ['dairy', '/cows/'], ['dairy', '/milk/'], ['agri', '/crops/'], ['flock', '/batches/'],
    ];
    for (const [name, base] of targets) {
      for (const id of weird) {
        const r = await raw(apps[name], `${base}${id}`, { token: apps[name].owner });
        expect(r.response.status, `${name} GET ${base}${id}`).toBe(404);
        const d = await raw(apps[name], `${base}${id}`, { method: 'DELETE', token: apps[name].owner });
        expect(d.response.status, `${name} DELETE ${base}${id}`).toBeLessThan(500);
      }
    }
  });

  it('sort/filter query injection never 500s and never leaks credential fields', async () => {
    const attacks = [
      '/cows?sort=password', '/cows?sort=-password', '/cows?sort[$ne]=x',
      '/cows?name[$regex]=.*', '/cows?$where=1', '/cows?filter[password][$gt]=',
      '/cows?limit=10&skip=0&search[$gt]=', '/cows?order=asc;DROP',
    ];
    for (const route of attacks) {
      const r = await raw(apps.dairy, route, { token: apps.dairy.owner });
      expect(r.response.status, `dairy ${route}`).toBeLessThan(500);
      expect(JSON.stringify(r.data), `dairy ${route} leaked password field`).not.toMatch(/"\$2[aby]\$|"passwordHash"/);
    }
    const agriAttacks = ['/finance?sort=password', '/finance?amount[$gt]=-999999999', '/crops?status[$ne]=x'];
    for (const route of agriAttacks) {
      const r = await raw(apps.agri, route, { token: apps.agri.owner });
      expect(r.response.status, `agri ${route}`).toBeLessThan(500);
    }
  });

  it('unicode integrity: emoji + Urdu + combining chars round-trip byte-identical', async () => {
    const ctx = apps.dairy;
    const name = `Ganga 🐄 ڈیری فارم e\u0301 ZWJ👨‍🌾 ${S}`;
    const cow = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { name, breed: 'Jersey', gender: 'female', status: 'active' } });
    expect(cow.response.status).toBe(201);
    const id = idOf(cow.data);
    const got = await raw(ctx, `/cows/${id}`, { token: ctx.owner });
    expect(got.data.name, 'unicode name mutated in storage').toBe(name);
    // control chars stripped or safe (no 500)
    const ctrl = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { name: `Bad\u0000Name\u001b[31m ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    expect(ctrl.response.status).toBeLessThan(500);
    if (ctrl.response.status === 201) await raw(ctx, `/cows/${idOf(ctrl.data)}`, { method: 'DELETE', token: ctx.owner });
    await raw(ctx, `/cows/${id}`, { method: 'DELETE', token: ctx.owner });
  });

  it('flock upload: script-bearing SVG cannot be stored and served back as active content', async () => {
    const ctx = apps.flock;
    const svg = `<svg xmlns="http://www.w3.org/2000/svg"><script>globalThis.__xss=1</script></svg>`;
    const form = new FormData();
    form.append('image', new Blob([svg], { type: 'image/svg+xml' }), 'evil.svg');
    const up = await fetch(`${ctx.base}/api/uploads/image?kind=bird`, { method: 'POST', headers: { Authorization: `Bearer ${ctx.owner}` }, body: form });
    if (up.status === 201) {
      const { path } = await up.json();
      const served = await fetch(`${ctx.base}${path}`, { headers: { Authorization: `Bearer ${ctx.owner}` } });
      const ct = served.headers.get('content-type') || '';
      const body = await served.text();
      const active = ct.includes('svg') && body.includes('<script>');
      expect(active, `SVG script served back as active content (${ct})`).toBe(false);
      const cd = served.headers.get('content-disposition') || '';
      expect(ct.includes('svg') || cd.includes('attachment'), 'svg served inline without attachment disposition').toBe(false);
    } else {
      expect([400, 415], `svg upload rejected with ${up.status}`).toContain(up.status);
    }
  });

  it('flock upload: non-image, empty and worker uploads are rejected', async () => {
    const ctx = apps.flock;
    const htmlForm = new FormData();
    htmlForm.append('image', new Blob(['<html><script>1</script></html>'], { type: 'text/html' }), 'x.html');
    const up1 = await fetch(`${ctx.base}/api/uploads/image?kind=bird`, { method: 'POST', headers: { Authorization: `Bearer ${ctx.owner}` }, body: htmlForm });
    expect([400, 415, 500], `html upload → ${up1.status}`).toContain(up1.status);
    expect(up1.status).not.toBe(201);

    const pngForm = new FormData();
    pngForm.append('image', new Blob([Uint8Array.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])], { type: 'image/png' }), 'ok.png');
    const upWorker = await fetch(`${ctx.base}/api/uploads/image?kind=bird`, { method: 'POST', headers: { Authorization: `Bearer ${ctx.worker}` }, body: pngForm });
    expect([401, 403], `worker upload → ${upWorker.status}`).toContain(upWorker.response?.status ?? upWorker.status);

    const noFile = await fetch(`${ctx.base}/api/uploads/image?kind=bird`, { method: 'POST', headers: { Authorization: `Bearer ${ctx.owner}`, 'Content-Type': 'application/json' }, body: '{}' });
    expect(noFile.status).toBeLessThan(500);
    const badKind = new FormData();
    badKind.append('image', new Blob([Uint8Array.from([1, 2, 3])], { type: 'image/png' }), 'ok.png');
    const upKind = await fetch(`${ctx.base}/api/uploads/image?kind=executable`, { method: 'POST', headers: { Authorization: `Bearer ${ctx.owner}` }, body: badKind });
    expect(upKind.status).toBe(400);
  });
});
