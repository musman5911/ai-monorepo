/** ROUND R9 (post-pull deep): backup integrity — tampered amounts, cross-app restores, malformed payloads. NO fixes. */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

describe.sequential('ROUND R9: backup integrity', () => {
  let dairy: Ctx; let agri: Ctx; let flock: Ctx;
  beforeAll(async () => {
    dairy = await startApp('dairy', 'dairy_farm/backend');
    agri = await startApp('agri', 'agri_farm/backend');
    flock = await startApp('flock', 'flock_farm/backend');
  }, 240_000);
  afterAll(async () => { for (const c of [dairy, agri, flock]) await stopApp(c); }, 60_000);

  it('tampered backup: editing an amount inside the backup changes restored data (integrity check?)', async () => {
    const backup = await raw(dairy, '/backup', { token: dairy.owner });
    expect(backup.response.status).toBe(200);
    const blob = JSON.parse(JSON.stringify(backup.data));
    // Find the expenses collection and bump one amount to a sentinel.
    const keys = Object.keys(blob || {});
    const expKey = keys.find((k) => /expense/i.test(k)) || '';
    const rows = Array.isArray(blob[expKey]) ? blob[expKey] : [];
    expect(rows.length, `no expenses in dairy backup (keys: ${keys.join(',')})`).toBeGreaterThan(0);
    const target = rows[0];
    target.amount = 987654321;
    const restore = await raw(dairy, '/backup/restore', { method: 'POST', token: dairy.owner, body: blob });
    expect([200, 201, 204], `tampered restore → ${restore.response.status}`).toContain(restore.response.status);
    const after = await raw(dairy, '/backup', { token: dairy.owner });
    const blob2 = after.data as any;
    const rows2 = Array.isArray(blob2[expKey]) ? blob2[expKey] : [];
    const hit = rows2.find((r: any) => Number(r.amount) === 987654321);
    // A backup system with integrity protection would reject or flag this.
    expect(hit, 'tampered amount silently restored (no integrity/signature check)').toBeFalsy();
  });

  it('cross-app restore: agri backup into dairy (and flock backup into agri) is rejected, data untouched', async () => {
    const agriBackup = await raw(agri, '/backup', { token: agri.owner });
    expect(agriBackup.response.status).toBe(200);
    const before = await raw(dairy, '/backup', { token: dairy.owner });
    const r1 = await raw(dairy, '/backup/restore', { method: 'POST', token: dairy.owner, body: agriBackup.data });
    expect([400, 409, 422], `agri backup → dairy restore → ${r1.response.status}`).toContain(r1.response.status);
    const after = await raw(dairy, '/backup', { token: dairy.owner });
    expect(JSON.stringify(after.data).length, 'dairy data changed by cross-app restore').toBe(JSON.stringify(before.data).length);
    const flockBackup = await raw(flock, '/backup', { token: flock.owner });
    const r2 = await raw(agri, '/restore', { method: 'POST', token: dairy.owner, body: flockBackup.data });
    expect([400, 409, 422], `flock backup → agri restore → ${r2.response.status}`).toContain(r2.response.status);
  });

  it('malformed restores never 500 and never wipe existing data (all apps)', async () => {
    const cases: Array<[string, Ctx, string]> = [['dairy', dairy, '/backup/restore'], ['agri', agri, '/restore'], ['flock', flock, '/backup/restore']];
    for (const [n, c, path] of cases) {
      const before = await raw(c, n === 'agri' ? '/backup' : '/backup', { token: c.owner });
      const beforeLen = JSON.stringify(before.data || {}).length;
      for (const bad of [{}, { cows: 'not-an-array' }, { version: 999 }, [], null, { data: { cows: [{ _id: 123 }] } }]) {
        const r = await raw(c, path, { method: 'POST', token: c.owner, body: bad as any });
        expect(r.response.status, `${n} malformed restore ${JSON.stringify(bad).slice(0, 40)} → ${r.response.status}`).toBeLessThan(500);
      }
      const after = await raw(c, '/backup', { token: c.owner });
      expect(JSON.stringify(after.data || {}).length, `${n} data shrank after malformed restores`).toBeGreaterThanOrEqual(Math.floor(beforeLen * 0.9));
    }
  });

  it('restore with another owner\'s farm ids inside does not adopt foreign farms', async () => {
    const backup = await raw(dairy, '/backup', { token: dairy.owner });
    const blob = JSON.parse(JSON.stringify(backup.data));
    const keys = Object.keys(blob || {});
    const farmKey = keys.find((k) => /^farms$/i.test(k)) || '';
    if (farmKey && Array.isArray(blob[farmKey]) && blob[farmKey].length) {
      blob[farmKey][0].name = `R9 Hijack ${S}`;
      blob[farmKey][0].ownerId = 'nonexistent-owner-000';
      blob[farmKey][0].userId = 'nonexistent-owner-000';
      const r = await raw(dairy, '/backup/restore', { method: 'POST', token: dairy.owner, body: blob });
      expect(r.response.status).toBeLessThan(500);
      const farms = await raw(dairy, '/farms', { token: dairy.owner });
      const mine = JSON.stringify(farms.data);
      // Renaming own farm via own backup is acceptable; adopting an owner id that breaks access is not.
      const sum = await raw(dairy, '/super-admin/farm-summary', { token: dairy.owner });
      expect(sum.response.status, 'owner lost summary access after restore with foreign owner ids').toBe(200);
      void mine;
    } else {
      expect(true).toBe(true); // no farms collection in backup; nothing to adopt
    }
  });
});
