/**
 * ROUND 19 — backup media fidelity on the pulled tree:
 * Agri diary media in backups (ff24217) and Flock image
 * bytes in backups (8f471b2). NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const TINY_PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const JPEG_B64 = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0, 16, 0x4a, 0x46, 0x49, 0x46, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0xff, 0xd9]).toString('base64');

describe.sequential('ROUND 19: backup media fidelity', () => {
  let agri: Ctx; let flock: Ctx;
  beforeAll(async () => {
    agri = await startApp('agri', 'agri_farm/backend');
    flock = await startApp('flock', 'flock_farm/backend');
  }, 180_000);
  afterAll(async () => { await stopApp(agri); await stopApp(flock); }, 60_000);

  it('agri: diary media photo survives backup → wipe → restore', async () => {
    const date = '2026-09-14';
    const photoId = `ph-${S}`;
    const put = await raw(agri, `/diary-media/${date}`, {
      method: 'PUT', token: agri.owner,
      body: { photos: [{ id: photoId, data: `data:image/jpeg;base64,${JPEG_B64}` }] },
    });
    expect([200, 201], `diary PUT → ${put.response.status} ${JSON.stringify(put.data).slice(0, 120)}`).toContain(put.response.status);
    const backup = await raw(agri, '/backup', { token: agri.owner });
    expect(backup.response.status).toBe(200);
    expect(JSON.stringify(backup.data), 'backup omits diary media photo').toContain(photoId);
    const wipe = await raw(agri, `/diary-media/${date}`, { method: 'PUT', token: agri.owner, body: { photos: [] } });
    expect([200, 201]).toContain(wipe.response.status);
    const restore = await raw(agri, '/restore', { method: 'POST', token: agri.owner, body: backup.data });
    expect([200, 201], `restore → ${restore.response.status}`).toContain(restore.response.status);
    const after = await raw(agri, `/diary-media/${date}`, { token: agri.owner });
    expect(JSON.stringify(after.data), 'diary photo gone after restore').toContain(photoId);
  });

  it('flock: uploaded image bytes are inside the backup and survive restore', async () => {
    const form = new FormData();
    form.append('image', new Blob([TINY_PNG], { type: 'image/png' }), 'tiny.png');
    const up = await fetch(`${flock.base}/api/uploads/image?kind=bird`, {
      method: 'POST', headers: { Authorization: `Bearer ${flock.owner}` }, body: form,
    });
    expect(up.status, 'image upload failed').toBe(201);
    const upData = await up.json() as { path?: string };
    expect(upData.path).toBeTruthy();
    const backup = await raw(flock, '/backup', { token: flock.owner });
    expect(backup.response.status).toBe(200);
    expect(JSON.stringify(backup.data).length, 'backup has no image payload').toBeGreaterThan(TINY_PNG.length);
    expect(JSON.stringify(backup.data), 'backup omits uploaded images').toMatch(/images/);
    const restore = await raw(flock, '/backup/restore', { method: 'POST', token: flock.owner, body: backup.data });
    expect([200, 201], `flock restore → ${restore.response.status}`).toContain(restore.response.status);
    const img = await fetch(`${flock.base}${upData.path}`, { headers: { Authorization: `Bearer ${flock.owner}` } });
    expect(img.status, 'image unreadable after restore').toBe(200);
    const bytes = Buffer.from(await img.arrayBuffer());
    expect(bytes.equals(TINY_PNG), 'image bytes corrupted by backup/restore').toBe(true);
  });

  it('agri + flock: worker cannot download a backup', async () => {
    const a = await raw(agri, '/backup', { token: agri.worker });
    expect([401, 403], `agri worker backup → ${a.response.status}`).toContain(a.response.status);
    const f = await raw(flock, '/backup', { token: flock.worker });
    expect([401, 403], `flock worker backup → ${f.response.status}`).toContain(f.response.status);
  });
});
