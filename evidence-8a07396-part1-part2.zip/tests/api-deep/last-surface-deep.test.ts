/**
 * ROUND 14 — last surfaces: farm-summary key gate, first-run
 * setup re-entry, token-in-URL auth, agri public worker card.
 * NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const apps: Record<string, Ctx> = {};
const LIST: Record<string, string> = { dairy: '/cows?limit=3', flock: '/batches', agri: '/crops?limit=3' };

describe.sequential('ROUND 14: last surfaces', () => {
  beforeAll(async () => {
    apps.dairy = await startApp('dairy', 'dairy_farm/backend');
    apps.flock = await startApp('flock', 'flock_farm/backend');
    apps.agri = await startApp('agri', 'agri_farm/backend');
  }, 180_000);
  afterAll(async () => { for (const c of Object.values(apps)) await stopApp(c); }, 60_000);

  it('farm-summary refuses callers without the cross-farm key (all apps)', async () => {
    for (const name of ['dairy', 'flock', 'agri'] as const) {
      const ctx = apps[name];
      const noKey = await fetch(`${ctx.base}/api/farm-summary`);
      expect([401, 403, 404], `${name} farm-summary without key → ${noKey.status}`).toContain(noKey.status);
      const badKey = await fetch(`${ctx.base}/api/farm-summary?key=wrong-${S}`);
      expect([401, 403, 404], `${name} farm-summary wrong key → ${badKey.status}`).toContain(badKey.status);
      const body = await badKey.text();
      expect(body, `${name} farm-summary leaked stats`).not.toMatch(/Active animals|totalBirds|netProfit/i);
    }
  });

  it('first-run setup cannot be re-entered after seeding (dairy)', async () => {
    const ctx = apps.dairy;
    const r = await raw(ctx, '/auth/setup', { method: 'POST', body: { username: `setupbackdoor${S.slice(-6)}`, password: '[SECURITY_DATA]' } });
    expect([400, 403, 404, 409], `setup re-entry → ${r.response.status}`).toContain(r.response.status);
    // and if it did create the account, it must not be able to log in as admin
    if (r.response.status < 300) {
      const login = await raw(ctx, '/auth/login', { method: 'POST', body: { username: `setupbackdoor${S.slice(-6)}`, password: '[SECURITY_DATA]' } });
      expect(login.response.status).toBe(401);
    }
    const check = await raw(ctx, '/auth/check-setup', {});
    if (check.response.status === 200) {
      expect(JSON.stringify(check.data)).toMatch(/false|setupComplete|needsSetup":false/i);
    }
  });

  it('tokens in the URL query string are never accepted as auth (all apps)', async () => {
    for (const name of ['dairy', 'flock', 'agri'] as const) {
      const ctx = apps[name];
      const sep = LIST[name].includes('?') ? '&' : '?';
      for (const param of ['token', 'access_token', 'jwt', 'auth']) {
        const r = await raw(ctx, `${LIST[name]}${sep}${param}=${ctx.owner}`, {});
        expect(r.response.status, `${name} accepted ?${param}= token`).toBe(401);
      }
    }
  });

  it('agri public worker card does not expose wages/advances to unauthenticated visitors', async () => {
    const ctx = apps.agri;
    const lab = await raw(ctx, '/laborers', { method: 'POST', token: ctx.owner, body: { name: `Card Worker ${S}`, daily_wage: 1777, phone: '0321-9998877' } });
    const id = idOf(lab.data) || (() => { throw new Error(`laborer create ${lab.response.status}`); })();
    const res = await fetch(`${ctx.base}/api/cards/worker/${id}`);
    expect(res.status).toBe(200);
    const html = await res.text();
    expect(html, 'public worker card leaks daily wage').not.toContain('1,777');
    expect(html, 'public worker card leaks phone').not.toContain('0321-9998877');
    await raw(ctx, `/laborers/${id}`, { method: 'DELETE', token: ctx.owner });
  });
});
