/** ROUND 11C (Phase 7, flock): role system — owner/manager/worker scope on batches, users, backup, telegram. NO fixes. */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

describe.sequential('ROUND 11C: role system (flock)', () => {
  let ctx: Ctx;
  let farmA = ''; let farmB = '';
  let mgrA = ''; let mgrAId = ''; let mgrB = '';

  const loginAs = async (u: string, p: string) => {
    const r = await raw(ctx, '/auth/login', { method: 'POST', body: { username: u, password: p } });
    expect(r.response.status, `login ${u} → ${r.response.status} ${JSON.stringify(r.data).slice(0, 100)}`).toBe(200);
    return String((r.data as any)?.token || (r.data as any)?.access_token || '');
  };
  const mkUser = async (username: string, role: string, farmIds: string[]) => {
    const r = await raw(ctx, '/auth/users', { method: 'POST', token: ctx.owner, body: { username, password: 'RoleTest123!', role, email: `${username}@test.local`, farmIds, name: username } });
    expect([200, 201], `create ${username} → ${r.response.status} ${JSON.stringify(r.data).slice(0, 160)}`).toContain(r.response.status);
    return String((r.data as any)?.user?.id || (r.data as any)?.user?._id || (r.data as any)?.id || idOf((r.data as any)?.user || r.data));
  };
  const batches = async (token: string, farmId?: string) => {
    const r = await raw(ctx, '/batches?limit=200', { token, farmId });
    const rows: any[] = Array.isArray(r.data) ? r.data : (r.data?.batches || r.data?.items || []);
    return { status: r.response.status, rows, raw: r };
  };

  beforeAll(async () => {
    ctx = await startApp('flock', 'flock_farm/backend');
    const farms = await raw(ctx, '/farms', { token: ctx.owner });
    const list = (farms.data as any)?.farms || [];
    farmA = String(list[0]?.id || list[0]?._id || '');
    const fb = await raw(ctx, '/farms', { method: 'POST', token: ctx.owner, body: { name: `R11C FarmB ${S}` } });
    farmB = String((fb.data as any)?.id || idOf(fb.data));
    expect(farmA && farmB && farmA !== farmB).toBeTruthy();
    mgrAId = await mkUser(`r11cmgra${S}`, 'manager', [farmA]);
    const mgrBRes = await raw(ctx, '/auth/users', { method: 'POST', token: ctx.owner, farmId: farmB, body: { username: `r11cmgrb${S}`, password: 'RoleTest123!', role: 'manager', email: `r11cmgrb${S}@test.local`, farmIds: [farmB], name: 'mgrB' } });
    expect([200, 201], `create mgrB → ${mgrBRes.response.status}`).toContain(mgrBRes.response.status);
    mgrA = await loginAs(`r11cmgra${S}`, 'RoleTest123!');
    mgrB = await loginAs(`r11cmgrb${S}`, 'RoleTest123!');
  }, 180_000);
  afterAll(async () => { await stopApp(ctx); }, 60_000);

  it('owner: all-mode, any farm, summary, backup, user creation all work', async () => {
    expect((await batches(ctx.owner, 'all')).status).toBe(200);
    expect((await raw(ctx, '/super-admin/farm-summary', { token: ctx.owner })).response.status).toBe(200);
    expect((await raw(ctx, '/backup', { token: ctx.owner })).response.status).toBe(200);
  });

  it('ROLE-F1: user creation honors the requested farmIds (not the creator current farm)', async () => {
    const r = await raw(ctx, '/auth/users', { method: 'POST', token: ctx.owner, body: { username: `r11cf1${S}`, password: 'RoleTest123!', role: 'manager', email: `r11cf1${S}@test.local`, farmIds: [farmB] } });
    expect([200, 201]).toContain(r.response.status);
    const got = ((r.data as any)?.user?.farmIds || []).map(String);
    expect(got, `requested farmIds [B] but user got ${JSON.stringify(got)}`).toEqual([farmB]);
  });

  it('manager: farm list = assigned only; other-farm header 403; B batches invisible in all-mode', async () => {
    const farms = await raw(ctx, '/farms', { token: mgrA });
    const ids = ((farms.data as any)?.farms || []).map((f: any) => String(f.id || f._id));
    expect(ids).toContain(farmA);
    expect(ids).not.toContain(farmB);
    const forb = await batches(mgrA, farmB);
    expect(forb.status, `mgr A + farm B header → ${forb.status}`).toBe(403);
    const mk = await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, farmId: farmB, body: { batch_id: `R11C-B-${S}`, name: `R11C BBird ${S}`, type: 'Layer', start_date: '2026-10-01', intake_count: 50 } });
    expect([200, 201], `owner create B batch → ${mk.response.status} ${JSON.stringify(mk.data).slice(0, 120)}`).toContain(mk.response.status);
    const inB = await batches(mgrB, farmB);
    expect(JSON.stringify(inB.rows), 'mgr B cannot see own batch').toContain(`R11C BBird ${S}`);
    const allA = await batches(mgrA, 'all');
    expect(JSON.stringify(allA.rows), 'mgr A all-mode leaks B batch').not.toContain(`R11C BBird ${S}`);
  });

  it('manager: write in all-mode blocked; body farmId smuggle stays in assigned farm', async () => {
    const w = await raw(ctx, '/batches', { method: 'POST', token: mgrA, farmId: 'all', body: { batch_id: `R11C-ALL-${S}`, name: 'AllWrite', type: 'Layer', start_date: '2026-10-01', intake_count: 10 } });
    expect([400, 403], `mgr write all-mode → ${w.response.status}`).toContain(w.response.status);
    const smug = await raw(ctx, '/batches', { method: 'POST', token: mgrA, farmId: farmA, body: { batch_id: `R11C-SMG-${S}`, name: 'Smuggle', type: 'Layer', start_date: '2026-10-01', intake_count: 10, farmId: farmB } as any });
    expect([200, 201], `smuggle create → ${smug.response.status}`).toContain(smug.response.status);
    const inB = await batches(ctx.owner, farmB);
    expect(JSON.stringify(inB.rows), 'smuggled batch in B').not.toContain('Smuggle');
    const inA = await batches(mgrA, farmA);
    expect(JSON.stringify(inA.rows), 'mgr batch missing in A').toContain('Smuggle');
  });

  it('manager cannot administer: farm create/archive/delete, manager creation, summary, user PATCH/DELETE (owner-only in flock)', async () => {
    expect([401, 403]).toContain((await raw(ctx, '/farms', { method: 'POST', token: mgrA, body: { name: `R11C MF ${S}` } })).response.status);
    expect([401, 403]).toContain((await raw(ctx, `/farms/${farmA}/archive`, { method: 'POST', token: mgrA, body: {} })).response.status);
    const mkMgr = await raw(ctx, '/auth/users', { method: 'POST', token: mgrA, body: { username: `r11cevil${S}`, password: 'RoleTest123!', role: 'manager', email: `e${S}@t.local`, farmIds: [farmA] } });
    expect([401, 403], `mgr creates manager → ${mkMgr.response.status}`).toContain(mkMgr.response.status);
    expect([401, 403]).toContain((await raw(ctx, '/super-admin/farm-summary', { token: mgrA })).response.status);
    const patch = await raw(ctx, `/auth/users/${mgrAId}`, { method: 'PATCH', token: mgrA, body: { role: 'owner' } });
    expect([400, 401, 403], `mgr PATCH user → ${patch.response.status}`).toContain(patch.response.status);
  });

  it('manager: backup/import must not expose or overwrite other farms', async () => {
    const bak = await raw(ctx, '/backup', { token: mgrA });
    if (bak.response.status === 200) {
      expect(JSON.stringify(bak.data), 'manager backup leaks B batch').not.toContain(`R11C BBird ${S}`);
    } else {
      expect([401, 403]).toContain(bak.response.status);
    }
    const imp = await raw(ctx, '/batches/import-all', { method: 'POST', token: mgrA, farmId: farmB, body: { batches: [] } });
    expect([400, 401, 403], `mgr import into farm B → ${imp.response.status}`).toContain(imp.response.status);
  });

  it('escalation: manager cannot widen own role/farms via /auth/me PATCH or user routes', async () => {
    const me = await raw(ctx, '/auth/me', { method: 'PATCH', token: mgrA, body: { role: 'owner', farmIds: [farmA, farmB] } });
    if (me.response.status < 300) {
      const probe = await batches(mgrA, farmB);
      expect(probe.status, 'me-PATCH widened farm access').toBe(403);
    }
    const after = await raw(ctx, '/auth/me', { token: mgrA });
    expect(JSON.stringify(after.data), 'manager became owner').not.toContain('"role":"owner"');
  });

  it('worker: no user/farm admin, no summary/backup, scoped reads only', async () => {
    expect([401, 403]).toContain((await raw(ctx, '/farms', { method: 'POST', token: ctx.worker, body: { name: `R11C WF ${S}` } })).response.status);
    expect([401, 403]).toContain((await raw(ctx, '/super-admin/farm-summary', { token: ctx.worker })).response.status);
    expect([401, 403]).toContain((await raw(ctx, '/backup', { token: ctx.worker })).response.status);
    const mkU = await raw(ctx, '/auth/users', { method: 'POST', token: ctx.worker, body: { username: `r11cwk${S}`, password: 'RoleTest123!', role: 'worker', farmIds: [farmA] } });
    expect([401, 403], `worker creates user → ${mkU.response.status}`).toContain(mkU.response.status);
    const wb = await batches(ctx.worker, farmB);
    expect([401, 403], `worker reads farm B → ${wb.status}`).toContain(wb.status);
  });

  it('telegram scope: manager cannot read/push telegram for farm B', async () => {
    const stB = await raw(ctx, '/telegram/settings', { token: mgrA, farmId: farmB });
    expect([401, 403, 404], `mgr telegram settings B → ${stB.response.status}`).toContain(stB.response.status);
    const pushB = await raw(ctx, '/telegram/send-summary', { method: 'POST', token: mgrA, farmId: farmB, body: {} });
    expect([401, 403, 404], `mgr telegram push B → ${pushB.response.status}`).toContain(pushB.response.status);
  });
});
