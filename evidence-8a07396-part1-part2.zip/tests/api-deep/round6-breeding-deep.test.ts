/** ROUND R6 (post-pull deep): breeding lifecycle, calf lineage integrity, edit/delete guards, races. NO fixes. */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

describe.sequential('ROUND R6: breeding deep lifecycle', () => {
  let ctx: Ctx; let bull = ''; let cow = ''; let calvingId = ''; let calfId = '';
  const mkCow = async (name: string, gender: string) => {
    const r = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { name, breed: 'Jersey', gender, status: 'active' } });
    expect([200, 201]).toContain(r.response.status);
    return idOf(r.data);
  };
  const getCow = async (id: string) => {
    const r = await raw(ctx, `/cows/${id}`, { token: ctx.owner });
    return r.response.status === 200 ? (r.data as any) : undefined;
  };
  const offspring = async (id: string) => {
    const r = await raw(ctx, `/cows/${id}/offspring`, { token: ctx.owner });
    const rows: any[] = Array.isArray(r.data) ? r.data : (r.data?.calves || r.data?.offspring || r.data?.items || []);
    return rows;
  };
  beforeAll(async () => { ctx = await startApp('dairy', 'dairy_farm/backend'); bull = await mkCow(`R6 Bull ${S}`, 'male'); cow = await mkCow(`R6 Cow ${S}`, 'female'); }, 120_000);
  afterAll(async () => { await stopApp(ctx); }, 60_000);

  it('full lifecycle: heat→service→check→calving creates exactly the live calf with full lineage', async () => {
    const ev = (body: any) => raw(ctx, '/breeding/events', { method: 'POST', token: ctx.owner, body });
    expect((await ev({ cowId: cow, type: 'heat', date: '2026-08-01' })).response.status).toBeLessThan(300);
    expect((await ev({ cowId: cow, type: 'service', date: '2026-08-03', sireSource: 'farm_bull', bullId: bull })).response.status).toBeLessThan(300);
    expect((await ev({ cowId: cow, type: 'pregnancy_check', date: '2026-09-15', result: 'positive' })).response.status).toBeLessThan(300);
    const cal = await ev({ cowId: cow, type: 'calving', date: '2026-10-20', sireSource: 'farm_bull', bullId: bull, calves: [{ gender: 'female', outcome: 'live', earTag: `R6TAG${S}` }, { gender: 'male', outcome: 'stillbirth', earTag: `R6DEAD${S}` }] });
    expect(cal.response.status, `calving → ${cal.response.status} ${JSON.stringify(cal.data).slice(0, 140)}`).toBeLessThan(300);
    calvingId = idOf(cal.data);
    const mine = await offspring(cow);
    expect(mine.length, `calves of mother: ${JSON.stringify(mine).slice(0, 200)}`).toBe(1);
    calfId = String(mine[0]._id);
    expect(String(mine[0].fatherId || '')).toBe(bull);
    expect(String(mine[0].birthDate || '')).toBe('2026-10-20');
    expect(String(mine[0].earTag || '').toUpperCase()).toBe(`R6TAG${S}`.toUpperCase());
    const mother = await getCow(cow);
    expect(String(mother?.calvingDate || ''), 'mother calvingDate not synced').toBe('2026-10-20');
    expect(String(mother?.heatDate || ''), 'mother heatDate not synced').toBe('2026-08-01');
  });

  it('calving with generated calves is edit-locked (409) and delete-locked (409)', async () => {
    const editDate = await raw(ctx, `/breeding/events/${calvingId}`, { method: 'PUT', token: ctx.owner, body: { date: '2026-10-21' } });
    expect(editDate.response.status, `edit calving date → ${editDate.response.status}`).toBe(409);
    const editCalves = await raw(ctx, `/breeding/events/${calvingId}`, { method: 'PUT', token: ctx.owner, body: { calves: [{ gender: 'male', outcome: 'live', earTag: `R6TAG${S}` }] } });
    expect(editCalves.response.status, `edit calving calves → ${editCalves.response.status}`).toBe(409);
    const del = await raw(ctx, `/breeding/events/${calvingId}`, { method: 'DELETE', token: ctx.owner });
    expect(del.response.status, `delete calving w/ calves → ${del.response.status}`).toBe(409);
    const calfDel = await raw(ctx, `/cows/${calfId}`, { method: 'DELETE', token: ctx.owner });
    expect(calfDel.response.status, `delete calf cow → ${calfDel.response.status}`).toBeLessThan(300);
    const del2 = await raw(ctx, `/breeding/events/${calvingId}`, { method: 'DELETE', token: ctx.owner });
    expect(del2.response.status, `delete calving after calf removed → ${del2.response.status}`).toBeLessThan(300);
    const mother = await getCow(cow);
    // Legacy calvingDate: preserved-by-design when no event remains (route comment), so only assert not corrupted to the rejected edit date.
    expect(String(mother?.calvingDate || '')).not.toBe('2026-10-21');
  });

  it('legacy date sync follows edits and deletion fallback (service)', async () => {
    const mk = async (date: string) => raw(ctx, '/breeding/events', { method: 'POST', token: ctx.owner, body: { cowId: cow, type: 'service', date, sireSource: 'outside_bull', bullName: `R6 Ext ${S}` } });
    const a = await mk('2026-11-01'); const b = await mk('2026-12-01');
    const aId = idOf(a.data); const bId = idOf(b.data);
    let mother = await getCow(cow);
    expect(String(mother?.pregnancyDate || '')).toBe('2026-12-01');
    const edit = await raw(ctx, `/breeding/events/${bId}`, { method: 'PUT', token: ctx.owner, body: { date: '2026-12-15' } });
    expect(edit.response.status).toBeLessThan(300);
    mother = await getCow(cow);
    expect(String(mother?.pregnancyDate || ''), 'edit not synced to legacy date').toBe('2026-12-15');
    await raw(ctx, `/breeding/events/${bId}`, { method: 'DELETE', token: ctx.owner });
    mother = await getCow(cow);
    expect(String(mother?.pregnancyDate || ''), 'delete did not fall back to earlier service date').toBe('2026-11-01');
    void aId;
  });

  it('validation depth: pagination abuse, bad types/dates, events on missing-type payloads', async () => {
    const p0 = await raw(ctx, '/breeding/events?page=0', { token: ctx.owner });
    expect([400, 422], `page=0 → ${p0.response.status}`).toContain(p0.response.status);
    const pAbc = await raw(ctx, '/breeding/events?limit=abc', { token: ctx.owner });
    expect([400, 422], `limit=abc → ${pAbc.response.status}`).toContain(pAbc.response.status);
    const badType = await raw(ctx, '/breeding/events', { method: 'POST', token: ctx.owner, body: { cowId: cow, type: 'ultrasound_party', date: '2026-10-01' } });
    expect([400, 422], `bad type → ${badType.response.status}`).toContain(badType.response.status);
    const badDate = await raw(ctx, '/breeding/events', { method: 'POST', token: ctx.owner, body: { cowId: cow, type: 'heat', date: '2026-13-45' } });
    expect([400, 422], `bad date → ${badDate.response.status}`).toContain(badDate.response.status);
    const wPut = await raw(ctx, '/breeding/events', { method: 'POST', token: ctx.worker, body: { cowId: cow, type: 'heat', date: '2026-10-02' } });
    expect(wPut.response.status, `worker create event → ${wPut.response.status}`).toBeLessThan(300);
    const wDelTry = await raw(ctx, `/breeding/events/${idOf(wPut.data)}`, { method: 'DELETE', token: ctx.worker });
    expect([401, 403], `worker delete event → ${wDelTry.response.status}`).toContain(wDelTry.response.status);
  });

  it('race: two parallel calvings with the same ear tag produce exactly one calf with that tag', async () => {
    const cow2 = await mkCow(`R6 Cow2 ${S}`, 'female');
    const body = { cowId: cow2, type: 'calving', date: '2026-10-22', calves: [{ gender: 'female', outcome: 'live', earTag: `R6RACE${S}` }] };
    const [r1, r2] = await Promise.all([
      raw(ctx, '/breeding/events', { method: 'POST', token: ctx.owner, body }),
      raw(ctx, '/breeding/events', { method: 'POST', token: ctx.owner, body }),
    ]);
    const okCount = [r1, r2].filter((r) => r.response.status < 300).length;
    const tagged = (await offspring(cow2)).filter((c) => String(c.earTag || '').toUpperCase() === `R6RACE${S}`.toUpperCase());
    expect(tagged.length, `race created ${tagged.length} calves with same tag (ok responses: ${okCount})`).toBe(1);
    expect(okCount, 'both race requests succeeded (duplicate event + calf)').toBe(1);
  });
});
