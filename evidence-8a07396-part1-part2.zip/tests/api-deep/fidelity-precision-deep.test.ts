/**
 * ROUND 10 (new sweep on updated tree) — backup fidelity across
 * every collection, money precision, date-range boundaries,
 * username/password edges, content negotiation, flock image
 * cross-farm access, search correctness. NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, rowsOf, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const apps: Record<string, Ctx> = {};

describe.sequential('ROUND 10: fidelity + precision', () => {
  beforeAll(async () => {
    apps.dairy = await startApp('dairy', 'dairy_farm/backend');
    apps.flock = await startApp('flock', 'flock_farm/backend');
    apps.agri = await startApp('agri', 'agri_farm/backend');
  }, 180_000);
  afterAll(async () => { for (const c of Object.values(apps)) await stopApp(c); }, 60_000);

  it('dairy backup fidelity: one of EVERY resource survives export → delete → restore', async () => {
    const ctx = apps.dairy;
    const marker = `Fid${S}`;
    const cow = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { name: `${marker} Cow`, breed: 'Jersey', gender: 'female', status: 'active' } });
    const cowId = idOf(cow.data);
    expect(cowId).toBeTruthy();
    const made: Array<[string, string]> = [['cows', cowId]];
    const mk = async (route: string, body: any) => {
      const r = await raw(ctx, route, { method: 'POST', token: ctx.owner, body });
      expect([200, 201], `${route} create → ${r.response.status}`).toContain(r.response.status);
      const id = idOf(r.data);
      if (id) made.push([route.replace(/^\//, ''), id]);
      return id;
    };
    await mk('/milk', { cowId, date: '2026-09-20', morning: 4, evening: 4 });
    await mk('/expenses', { date: '2026-09-20', type: 'feed', note: `${marker} Expense`, amount: 1234 });
    await mk('/health', { cowId, date: '2026-09-20', type: 'checkup', description: `${marker} Checkup`, cost: 500 });
    await mk('/buyers', { name: `${marker} Buyer` });
    await mk('/suppliers', { name: `${marker} Supplier` });
    await mk('/labor/workers', { name: `${marker} Worker`, dailyWage: 1000 });

    const backup = await raw(ctx, '/backup', { token: ctx.owner });
    expect(backup.response.status).toBe(200);
    // delete everything we made
    for (const [coll, id] of made) await raw(ctx, `/${coll}/${id}`, { method: 'DELETE', token: ctx.owner });
    const goneCow = await raw(ctx, `/cows/${cowId}`, { token: ctx.owner });
    expect(goneCow.response.status).toBe(404);

    const restore = await raw(ctx, '/backup/restore', { method: 'POST', token: ctx.owner, body: backup.data });
    expect([200, 201]).toContain(restore.response.status);

    const checks: Array<[string, string]> = [
      ['/cows?limit=500', `${marker} Cow`],
      ['/expenses?limit=500', `${marker} Expense`],
      ['/health?limit=500', `${marker} Checkup`],
      ['/buyers?limit=500', `${marker} Buyer`],
      ['/suppliers?limit=500', `${marker} Supplier`],
      ['/labor/workers?limit=500', `${marker} Worker`],
    ];
    for (const [route, text] of checks) {
      const list = await raw(ctx, route, { token: ctx.owner });
      expect(JSON.stringify(list.data), `${route} lost its record in backup/restore`).toContain(text);
    }
    const milk = await raw(ctx, `/milk?cowId=${cowId}&limit=100`, { token: ctx.owner });
    expect(rowsOf(milk.data).some((m: any) => m.date === '2026-09-20'), 'milk entry lost in backup/restore').toBe(true);
  }, 120_000);

  it('money precision: 2^53+1 and float sums do not silently corrupt', async () => {
    const ctx = apps.agri;
    const big = 9007199254740993; // 2^53 + 1, not representable
    const r = await raw(ctx, '/finance', { method: 'POST', token: ctx.owner, body: { type: 'expense', category: `Precision ${S}`, amount: big, date: '2026-09-21' } });
    expect([200, 201]).toContain(r.response.status);
    const list = rowsOf((await raw(ctx, '/finance?skip=0&limit=500', { token: ctx.owner })).data);
    const mine = list.find((x: any) => x.category === `Precision ${S}`);
    expect(mine, 'precision record missing').toBeTruthy();
    expect(Number(mine.amount), 'amount silently rounded by float53').toBe(big);
    if (mine) await raw(ctx, `/finance/${mine._id || mine.id}`, { method: 'DELETE', token: ctx.owner });

    // 0.1 + 0.2 style drift in summaries
    const dctx = apps.dairy;
    const cow = await raw(dctx, '/cows', { method: 'POST', token: dctx.owner, body: { name: `Float Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    const cowId = idOf(cow.data);
    await raw(dctx, '/expenses', { method: 'POST', token: dctx.owner, body: { date: '2026-09-21', type: 'feed', note: `FloatA ${S}`, amount: 0.1 } });
    await raw(dctx, '/expenses', { method: 'POST', token: dctx.owner, body: { date: '2026-09-21', type: 'feed', note: `FloatB ${S}`, amount: 0.2 } });
    const mine2 = rowsOf((await raw(dctx, '/expenses?limit=500', { token: dctx.owner })).data)
      .filter((x: any) => String(x.note || x.description || '').startsWith('Float'));
    const sum = mine2.reduce((a: number, x: any) => a + Number(x.amount), 0);
    expect(sum, `stored amounts drift: ${sum}`).toBeCloseTo(0.3, 10);
    await raw(dctx, `/cows/${cowId}`, { method: 'DELETE', token: dctx.owner });
  });

  it('date boundaries: first and last day of month are both inside the monthly summary', async () => {
    const ctx = apps.dairy;
    const cow = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { name: `Boundary Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    const cowId = idOf(cow.data);
    await raw(ctx, '/milk', { method: 'POST', token: ctx.owner, body: { cowId, date: '2026-03-01', morning: 1, evening: 0 } });
    await raw(ctx, '/milk', { method: 'POST', token: ctx.owner, body: { cowId, date: '2026-03-31', morning: 2, evening: 0 } });
    await raw(ctx, '/milk', { method: 'POST', token: ctx.owner, body: { cowId, date: '2026-04-01', morning: 4, evening: 0 } });
    const entries = rowsOf((await raw(ctx, `/milk?cowId=${cowId}&limit=100`, { token: ctx.owner })).data);
    const march = entries.filter((m: any) => String(m.date).startsWith('2026-03'));
    expect(march.length, 'boundary milk entries missing from month listing').toBe(2);
    const range = rowsOf((await raw(ctx, `/milk?cowId=${cowId}&from=2026-03-01&to=2026-03-31&limit=100`, { token: ctx.owner })).data);
    if (range.length > 0) {
      expect(range.every((m: any) => String(m.date) >= '2026-03-01' && String(m.date) <= '2026-03-31'), 'date-range filter leaked out-of-range rows').toBe(true);
      expect(range.length, 'date-range filter dropped boundary days').toBe(2);
    }
    await raw(ctx, `/cows/${cowId}`, { method: 'DELETE', token: ctx.owner });
  });

  it('username edges: duplicates and case variants cannot create shadow accounts (dairy)', async () => {
    const ctx = apps.dairy;
    const farms = await raw(ctx, '/farms', { token: ctx.owner });
    const farmId = String((farms.data?.farms || [])[0]?.id || (farms.data?.farms || [])[0]?._id || '');
    const base = `edge${S.slice(-6)}`;
    const first = await raw(ctx, '/auth/users', { method: 'POST', token: ctx.owner, body: { username: base, password: '[SECURITY_DATA]', role: 'worker', farmIds: [farmId] } });
    expect([200, 201]).toContain(first.response.status);
    const dup = await raw(ctx, '/auth/users', { method: 'POST', token: ctx.owner, body: { username: base, password: '[SECURITY_DATA]', role: 'worker', farmIds: [farmId] } });
    expect([400, 409], `exact duplicate username → ${dup.response.status}`).toContain(dup.response.status);
    const caseDup = await raw(ctx, '/auth/users', { method: 'POST', token: ctx.owner, body: { username: base.toUpperCase(), password: '[SECURITY_DATA]', role: 'worker', farmIds: [farmId] } });
    expect([400, 409], `case-variant username → ${caseDup.response.status} (shadow account risk)`).toContain(caseDup.response.status);
    const users = await raw(ctx, '/auth/users', { token: ctx.owner });
    const rows = rowsOf(users.data).length ? rowsOf(users.data) : (users.data?.users || []);
    for (const u of rows.filter((x: any) => String(x.username).toLowerCase() === base)) {
      await raw(ctx, `/auth/users/${u._id || u.id}`, { method: 'DELETE', token: ctx.owner });
    }
  });

  it('content negotiation + HEAD: APIs answer JSON and honor HEAD without bodies', async () => {
    const ctx = apps.dairy;
    const res = await fetch(`${ctx.base}/api/cows?limit=2`, { headers: { Authorization: `Bearer ${ctx.owner}`, Accept: 'text/html' } });
    expect(res.headers.get('content-type') || '', 'API answered HTML to Accept:text/html').toContain('application/json');
    const head = await fetch(`${ctx.base}/api/cows?limit=2`, { method: 'HEAD', headers: { Authorization: `Bearer ${ctx.owner}` } });
    expect(head.status).toBe(200);
    expect(await head.text()).toBe('');
    const gzip = await fetch(`${ctx.base}/api/cows?limit=50`, { headers: { Authorization: `Bearer ${ctx.owner}`, 'Accept-Encoding': 'gzip' } });
    expect(gzip.status).toBe(200);
    await gzip.text(); // must decode cleanly if gzipped
  });

  it('flock image access: an image uploaded under Farm B is not readable by Farm A staff', async () => {
    const ctx = apps.flock;
    const farmBRes = await raw(ctx, '/farms', { method: 'POST', token: ctx.owner, body: { name: `Img Farm B ${S}` } });
    const farmB = String(farmBRes.data?.farm?.id || farmBRes.data?.id || farmBRes.data?.farm?._id || farmBRes.data?._id);
    expect(farmB).toBeTruthy();
    const png = Uint8Array.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 1, 2, 3]);
    const form = new FormData();
    form.append('image', new Blob([png], { type: 'image/png' }), 'probe.png');
    const up = await fetch(`${ctx.base}/api/uploads/image?kind=bird`, { method: 'POST', headers: { Authorization: `Bearer ${ctx.owner}`, 'X-Farm-Id': farmB }, body: form });
    expect(up.status, `farm B upload → ${up.status}`).toBe(201);
    const { path } = await up.json();
    // seeded worker belongs to the default farm only
    const asWorker = await fetch(`${ctx.base}${path}`, { headers: { Authorization: `Bearer ${ctx.worker}` } });
    expect([403, 404], `farm A worker read farm B image → ${asWorker.status}`).toContain(asWorker.status);
    const asOwner = await fetch(`${ctx.base}${path}`, { headers: { Authorization: `Bearer ${ctx.owner}` } });
    expect(asOwner.status).toBe(200);
  });

  it('search correctness: partial + case-insensitive, regex metachars are literal (dairy cows)', async () => {
    const ctx = apps.dairy;
    const cow = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { name: `ZzUnIqUe Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    const id = idOf(cow.data);
    const partial = rowsOf((await raw(ctx, '/cows?search=zzunique&limit=100', { token: ctx.owner })).data);
    expect(partial.length, 'case-insensitive partial search failed').toBe(1);
    const none = rowsOf((await raw(ctx, `/cows?search=no-such-${S}&limit=100`, { token: ctx.owner })).data);
    expect(none.length, 'search for nonexistent name returned rows').toBe(0);
    const regex = rowsOf((await raw(ctx, '/cows?search=.*&limit=500', { token: ctx.owner })).data);
    expect(regex.length, 'search ".*" acted as regex and matched everything').toBe(0);
    const bracket = await raw(ctx, '/cows?search=%5Ba-z%5D&limit=10', { token: ctx.owner });
    expect(bracket.response.status).toBeLessThan(500);
    await raw(ctx, `/cows/${id}`, { method: 'DELETE', token: ctx.owner });
  });
});
