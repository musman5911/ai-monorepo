/**
 * ROUND 9 (Tier E) — protocol exotics: banner disclosure, TRACE,
 * WebSocket upgrade, slow-drip resilience, oversized request lines.
 * Raw sockets where fetch() can't express the probe.
 * NO fixes; failures = findings.
 */
import { connect } from 'node:net';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const apps: Record<string, Ctx> = {};
const LIST: Record<string, string> = { dairy: '/cows?limit=3', flock: '/batches', agri: '/crops?limit=3' };

function rawExchange(port: number, payload: string, waitMs = 2500): Promise<string> {
  return new Promise((resolve) => {
    const sock = connect(port, '127.0.0.1', () => sock.write(payload));
    let data = '';
    const done = () => { try { sock.destroy(); } catch { /* noop */ } resolve(data); };
    sock.on('data', (d) => { data += d.toString(); if (data.length > 4000) done(); });
    sock.on('error', done);
    sock.on('close', () => resolve(data));
    setTimeout(done, waitMs);
  });
}
const portOf = (ctx: Ctx) => Number(new URL(ctx.base).port);

describe.sequential('ROUND 9: protocol exotics', () => {
  beforeAll(async () => {
    apps.dairy = await startApp('dairy', 'dairy_farm/backend');
    apps.flock = await startApp('flock', 'flock_farm/backend');
    apps.agri = await startApp('agri', 'agri_farm/backend');
  }, 180_000);
  afterAll(async () => { for (const c of Object.values(apps)) await stopApp(c); }, 60_000);

  for (const name of ['dairy', 'flock', 'agri'] as const) {
    it(`${name}: no framework banner disclosure (X-Powered-By / Server)`, async () => {
      const ctx = apps[name];
      const res = await fetch(`${ctx.base}/api${LIST[name]}`, { headers: { Authorization: `Bearer ${ctx.owner}` } });
      const powered = res.headers.get('x-powered-by');
      const server = res.headers.get('server');
      expect(powered, `${name} leaks X-Powered-By: ${powered}`).toBeNull();
      expect(server || '', `${name} leaks Server version: ${server}`).not.toMatch(/Express|Node|nginx\/\d|Apache\/\d/);
    });

    it(`${name}: TRACE method is refused`, async () => {
      const ctx = apps[name];
      const res = await rawExchange(portOf(ctx),
        `TRACE /api${LIST[name]} HTTP/1.1\r\nHost: x\r\nAuthorization: Bearer ${ctx.owner}\r\nX-Probe: ${S}\r\n\r\n`);
      const status = Number((res.match(/^HTTP\/1\.1 (\d+)/) || [])[1] || 0);
      expect([400, 404, 405, 501], `${name} TRACE answered ${status}: ` + JSON.stringify(res.slice(0, 120))).toContain(status);
      expect(res, 'TRACE echoed request headers (XST)').not.toContain(`X-Probe: ${S}`);
    }, 30_000);

    it(`${name}: WebSocket upgrade is not silently accepted on the API port`, async () => {
      const ctx = apps[name];
      const res = await rawExchange(portOf(ctx),
        `GET /api${LIST[name]} HTTP/1.1\r\nHost: x\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\nSec-WebSocket-Version: 13\r\nAuthorization: Bearer ${ctx.owner}\r\n\r\n`);
      expect(res.startsWith('HTTP/1.1 101'), `${name} upgraded to websocket: ${JSON.stringify(res.slice(0, 120))}`).toBe(false);
    }, 30_000);
  }

  it('slow-drip: a stalled partial request does not block or crash the dairy server', async () => {
    const ctx = apps.dairy;
    const port = portOf(ctx);
    const drip = connect(port, '127.0.0.1', () => {
      drip.write(`GET /api/cows HTTP/1.1\r\nHost: x\r\nAuthorization: Bearer ${ctx.owner}\r\nX-Drip:`); // never finished
    });
    await new Promise((r) => setTimeout(r, 300));
    const started = Date.now();
    const healthy = await raw(ctx, '/cows?limit=2', { token: ctx.owner });
    expect(healthy.response.status).toBe(200);
    expect(Date.now() - started, 'server blocked by one slow-drip connection').toBeLessThan(3000);
    // keep dripping slowly for a few seconds; server must remain responsive
    drip.write(' still-going');
    await new Promise((r) => setTimeout(r, 1500));
    const still = await raw(ctx, '/cows?limit=2', { token: ctx.owner });
    expect(still.response.status).toBe(200);
    drip.destroy();
  }, 30_000);

  it('oversized request line and header floods get clean 4xx, server stays healthy (dairy)', async () => {
    const ctx = apps.dairy;
    const port = portOf(ctx);
    const longUrl = `GET /api/${'x'.repeat(12000)} HTTP/1.1\r\nHost: x\r\n\r\n`;
    const r1 = await rawExchange(port, longUrl);
    const s1 = Number((r1.match(/^HTTP\/1\.1 (\d+)/) || [])[1] || 0);
    expect([400, 404, 414, 431], `oversized request line → ${s1}`).toContain(s1);

    let headers = 'GET /api/cows HTTP/1.1\r\nHost: x\r\n';
    for (let i = 0; i < 300; i++) headers += `X-Flood-${i}: ${'y'.repeat(60)}\r\n`;
    headers += '\r\n';
    const r2 = await rawExchange(port, headers);
    const s2 = Number((r2.match(/^HTTP\/1\.1 (\d+)/) || [])[1] || 0);
    expect([200, 400, 431], `header flood → ${s2}`).toContain(s2);

    const alive = await raw(ctx, '/cows?limit=1', { token: ctx.owner });
    expect(alive.response.status).toBe(200);
  }, 60_000);
});
