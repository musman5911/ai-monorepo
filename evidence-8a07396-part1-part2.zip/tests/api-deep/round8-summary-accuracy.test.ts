/** ROUND R8 (post-pull deep): farm-summary numbers must match ground truth; legacy key endpoint stays locked. NO fixes. */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const today = new Date().toISOString().slice(0, 10);
const month = today.slice(0, 7);

describe.sequential('ROUND R8: summary accuracy', () => {
  let dairy: Ctx; let agri: Ctx; let flock: Ctx;
  beforeAll(async () => {
    dairy = await startApp('dairy', 'dairy_farm/backend');
    agri = await startApp('agri', 'agri_farm/backend');
    flock = await startApp('flock', 'flock_farm/backend');
  }, 240_000);
  afterAll(async () => { for (const c of [dairy, agri, flock]) await stopApp(c); }, 60_000);

  it('dairy: per-farm summary matches ground truth (animals, milk today/month, expenses month)', async () => {
    const f = await raw(dairy, '/farms', { method: 'POST', token: dairy.owner, body: { name: `R8 Truth Farm ${S}` } });
    const farmId = String((f.data as any)?.farm?.id || (f.data as any)?.id || (f.data as any)?._id || idOf(f.data));
    expect(farmId).toBeTruthy();
    const mkCow = async (name: string) => {
      const r = await raw(dairy, '/cows', { method: 'POST', token: dairy.owner, farmId, body: { name, breed: 'Jersey', gender: 'female', status: 'active' } });
      expect([200, 201]).toContain(r.response.status);
      return idOf(r.data);
    };
    const c1 = await mkCow(`R8 Cow1 ${S}`);
    await mkCow(`R8 Cow2 ${S}`);
    const milk = await raw(dairy, '/milk', { method: 'POST', token: dairy.owner, farmId, body: { cowId: c1, date: today, morning: 11.5, evening: 9.5 } });
    expect(milk.response.status, `milk → ${milk.response.status}`).toBeLessThan(300);
    const exp = await raw(dairy, '/expenses', { method: 'POST', token: dairy.owner, farmId, body: { date: `${month}-05`, amount: 13579, type: 'feed', note: `R8EXP${S}` } });
    expect(exp.response.status, `expense → ${exp.response.status}`).toBeLessThan(300);
    const sum = await raw(dairy, '/super-admin/farm-summary', { token: dairy.owner });
    expect(sum.response.status).toBe(200);
    const entry = ((sum.data as any)?.farms || []).find((x: any) => String(x.farmId) === farmId);
    expect(entry, `farm missing from summary: ${JSON.stringify(sum.data).slice(0, 200)}`).toBeTruthy();
    const stat = (label: string) => (entry.stats || []).find((s: any) => String(s.label).toLowerCase().includes(label));
    expect(Number(stat('active animals')?.value), 'animal count wrong').toBe(2);
    expect(String(stat("today's milk")?.value), 'today milk wrong').toContain('21');
    expect(String(stat('expenses this month')?.value).replace(/[^0-9]/g, ''), 'month expense wrong').toContain('13579');
  });

  it('legacy /api/farm-summary (shared-key path) is not open without the key on any app', async () => {
    for (const [n, c] of [['dairy', dairy], ['agri', agri], ['flock', flock]] as const) {
      const noKey = await fetch(`${c.base}/api/farm-summary`);
      expect([401, 403, 404], `${n} legacy summary no key → ${noKey.status}`).toContain(noKey.status);
      const badKey = await fetch(`${c.base}/api/farm-summary?key=wrong-${S}`);
      expect([401, 403, 404], `${n} legacy summary bad key → ${badKey.status}`).toContain(badKey.status);
    }
  });

  it('summary isolation: a second owner sees none of the first owner\'s farms in summary', async () => {
    // Register a fresh user on dairy and ask for their summary.
    const uname = `r8other${S}`;
    const reg = await raw(dairy, '/auth/users', { method: 'POST', token: dairy.owner, body: { username: uname, password: 'R8pass123!', role: 'owner', name: 'R8 Other' } });
    expect([200, 201, 400, 409], `create second owner → ${reg.response.status}`).toContain(reg.response.status);
    if (reg.response.status < 300) {
      const login = await fetch(`${dairy.base}/api/auth/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: uname, password: 'R8pass123!' }) });
      const lj: any = await login.json().catch(() => ({}));
      const tok = String(lj.token || '');
      expect(tok, 'second owner login failed').toBeTruthy();
      const sum = await fetch(`${dairy.base}/api/super-admin/farm-summary`, { headers: { Authorization: `Bearer ${tok}` } });
      const sj: any = await sum.json().catch(() => ({}));
      expect(sum.status, `second owner summary → ${sum.status}`).toBe(200);
      expect(JSON.stringify(sj), 'second owner sees first owner farm').not.toContain(`R8 Truth Farm ${S}`);
    }
  });

  it('flock + agri summaries respond with per-farm arrays (shape parity with dairy)', async () => {
    for (const [n, c] of [['flock', flock], ['agri', agri]] as const) {
      const sum = await raw(c, '/super-admin/farm-summary', { token: c.owner });
      expect(sum.response.status, `${n} summary → ${sum.response.status}`).toBe(200);
      expect(Array.isArray((sum.data as any)?.farms), `${n} summary lacks farms array`).toBe(true);
    }
  });
});
