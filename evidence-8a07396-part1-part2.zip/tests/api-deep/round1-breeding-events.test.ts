/** ROUND R1 (post-186-pull): Dairy breeding events + calving lineage. NO fixes; failures = findings. */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, rowsOf, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

describe.sequential('ROUND R1: dairy breeding events', () => {
  let ctx: Ctx; let cowId = ''; let bullId = '';
  beforeAll(async () => { ctx = await startApp('dairy', 'dairy_farm/backend'); }, 120_000);
  afterAll(async () => { await stopApp(ctx); }, 60_000);

  async function mkCow(name: string, gender: string, farmId?: string) {
    const r = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, farmId, body: { name, breed: 'Jersey', gender, status: 'active' } });
    expect([200, 201], `cow ${name} → ${r.response.status}`).toContain(r.response.status);
    return idOf(r.data);
  }

  it('service event with in-farm bull works; invalid sires and calf-entries are rejected', async () => {
    cowId = await mkCow(`R1 Cow ${S}`, 'female');
    bullId = await mkCow(`R1 Bull ${S}`, 'male');
    const ok = await raw(ctx, '/breeding/events', { method: 'POST', token: ctx.owner, body: { cowId, type: 'service', date: '2026-09-01', sireSource: 'farm_bull', bullId } });
    expect(ok.response.status, `service event → ${ok.response.status} ${JSON.stringify(ok.data).slice(0, 140)}`).toBeLessThan(300);
    const badSire = await raw(ctx, '/breeding/events', { method: 'POST', token: ctx.owner, body: { cowId, type: 'service', date: '2026-09-02', sireSource: 'farm_bull', bullId: cowId } });
    expect([400, 422], `female as sire → ${badSire.response.status}`).toContain(badSire.response.status);
    const calfOnService = await raw(ctx, '/breeding/events', { method: 'POST', token: ctx.owner, body: { cowId, type: 'service', date: '2026-09-03', calves: [{ gender: 'female', outcome: 'live' }] } });
    expect([400, 422], `calves on service event → ${calfOnService.response.status}`).toContain(calfOnService.response.status);
    const tooMany = await raw(ctx, '/breeding/events', { method: 'POST', token: ctx.owner, body: { cowId, type: 'calving', date: '2026-09-04', calves: Array.from({ length: 5 }, () => ({ gender: 'female', outcome: 'live' })) } });
    expect([400, 422], `5 calves → ${tooMany.response.status}`).toContain(tooMany.response.status);
    const ghost = await raw(ctx, '/breeding/events', { method: 'POST', token: ctx.owner, body: { cowId: '00000000-0000-0000-0000-000000000000', type: 'heat', date: '2026-09-05' } });
    expect([400, 404, 422], `ghost cow event → ${ghost.response.status}`).toContain(ghost.response.status);
  });

  it('bull from another farm cannot sire; event for farm-B cow under farm A is rejected', async () => {
    const farmB = await raw(ctx, '/farms', { method: 'POST', token: ctx.owner, body: { name: `R1 FarmB ${S}` } });
    const bId = String(farmB.data?.farm?.id || farmB.data?.id || farmB.data?.farm?._id || farmB.data?._id);
    const cowB = await mkCow(`R1 CowB ${S}`, 'female', bId);
    const bullB = await mkCow(`R1 BullB ${S}`, 'male', bId);
    const crossBull = await raw(ctx, '/breeding/events', { method: 'POST', token: ctx.owner, body: { cowId, type: 'service', date: '2026-09-06', sireSource: 'farm_bull', bullId: bullB } });
    expect([400, 422], `farm-B bull as sire in A → ${crossBull.response.status}`).toContain(crossBull.response.status);
    const crossCow = await raw(ctx, '/breeding/events', { method: 'POST', token: ctx.owner, body: { cowId: cowB, type: 'heat', date: '2026-09-06' } });
    expect([400, 404, 422], `farm-B cow event under A → ${crossCow.response.status}`).toContain(crossCow.response.status);
  });

  it('calving creates calf cows with lineage; ear tags are farm-scoped and case-insensitive', async () => {
    const tag = `TAG-${S}`.toUpperCase();
    const calving = await raw(ctx, '/breeding/events', { method: 'POST', token: ctx.owner, body: { cowId, type: 'calving', date: '2026-10-01', calves: [{ gender: 'female', outcome: 'live', earTag: tag }, { gender: 'male', outcome: 'stillbirth' }] } });
    expect(calving.response.status, `calving → ${calving.response.status} ${JSON.stringify(calving.data).slice(0, 160)}`).toBeLessThan(300);
    const cows = await raw(ctx, '/cows?limit=200', { token: ctx.owner });
    const calf = rowsOf(cows.data).find((c: any) => JSON.stringify(c).includes(tag));
    expect(calf, 'no calf cow created from calving event').toBeTruthy();
    expect(JSON.stringify(calf), 'calf does not reference its mother').toContain(cowId.slice(0, 8));
    // duplicate tag (different case) in same farm rejected
    const cow2 = await mkCow(`R1 Cow2 ${S}`, 'female');
    const dup = await raw(ctx, '/breeding/events', { method: 'POST', token: ctx.owner, body: { cowId: cow2, type: 'calving', date: '2026-10-02', calves: [{ gender: 'male', outcome: 'live', earTag: tag.toLowerCase() }] } });
    expect([400, 409, 422], `duplicate ear tag (lowercase) → ${dup.response.status}`).toContain(dup.response.status);
  });

  it('legacy cow dates sync from events; worker can create but not delete', async () => {
    const cow3 = await mkCow(`R1 Cow3 ${S}`, 'female');
    const ev = await raw(ctx, '/breeding/events', { method: 'POST', token: ctx.owner, body: { cowId: cow3, type: 'service', date: '2026-08-15' } });
    expect(ev.response.status).toBeLessThan(300);
    const evId = idOf(ev.data) || String((ev.data as any)?.event?._id || '');
    const cowAfter = await raw(ctx, `/cows/${cow3}`, { token: ctx.owner });
    expect(JSON.stringify(cowAfter.data), 'cow pregnancyDate not synced from service event').toContain('2026-08-15');
    const wCreate = await raw(ctx, '/breeding/events', { method: 'POST', token: ctx.worker, body: { cowId: cow3, type: 'heat', date: '2026-08-16' } });
    expect(wCreate.response.status, `worker create → ${wCreate.response.status}`).toBeLessThan(300);
    const wDel = await raw(ctx, `/breeding/events/${evId}`, { method: 'DELETE', token: ctx.worker });
    expect([401, 403], `worker delete → ${wDel.response.status}`).toContain(wDel.response.status);
    const oDel = await raw(ctx, `/breeding/events/${evId}`, { method: 'DELETE', token: ctx.owner });
    expect(oDel.response.status, `owner delete → ${oDel.response.status}`).toBeLessThan(300);
  });
});
