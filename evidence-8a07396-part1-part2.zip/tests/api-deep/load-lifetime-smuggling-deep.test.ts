/**
 * ROUND 8 (Tier D) — load/soak with integrity, token lifetime,
 * raw-socket HTTP smuggling resilience, DOMPurify re-verification.
 * NO fixes; failures = findings.
 */
import { connect } from 'node:net';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, repoRoot, rowsOf, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const apps: Record<string, Ctx> = {};

function rssKb(pid: number): number {
  try {
    const m = readFileSync(`/proc/${pid}/status`, 'utf8').match(/VmRSS:\s+(\d+) kB/);
    return m ? Number(m[1]) : 0;
  } catch { return 0; }
}
function walk(dir: string, out: string[] = []): string[] {
  for (const e of readdirSync(dir)) {
    const p = path.join(dir, e);
    if (statSync(p).isDirectory()) walk(p, out);
    else if (/\.(ts|tsx|js|jsx)$/.test(e)) out.push(p);
  }
  return out;
}
function rawSocket(port: number, payload: string, waitMs = 4000): Promise<string> {
  return new Promise((resolve) => {
    const sock = connect(port, '127.0.0.1', () => sock.write(payload));
    let data = '';
    const done = () => { try { sock.destroy(); } catch { /* noop */ } resolve(data); };
    sock.on('data', (d) => { data += d.toString(); if (data.length > 2000) done(); });
    sock.on('error', done);
    sock.on('close', () => resolve(data));
    setTimeout(done, waitMs);
  });
}

describe.sequential('ROUND 8: load, lifetime, smuggling, deps', () => {
  beforeAll(async () => {
    apps.dairy = await startApp('dairy', 'dairy_farm/backend');
    apps.flock = await startApp('flock', 'flock_farm/backend');
    apps.agri = await startApp('agri', 'agri_farm/backend');
  }, 180_000);
  afterAll(async () => { for (const c of Object.values(apps)) await stopApp(c); }, 60_000);

  for (const name of ['dairy', 'flock', 'agri'] as const) {
    it(`${name}: token lifetime is at most 24 hours`, async () => {
      const claims = JSON.parse(Buffer.from(apps[name].owner.split('.')[1], 'base64url').toString());
      const ttlH = (claims.exp - claims.iat) / 3600;
      expect(ttlH, `${name} access-token lifetime is ${ttlH}h`).toBeLessThanOrEqual(24);
    });
  }

  it('dairy soak: 150 parallel reads + 30 parallel writes, zero 5xx, counts exact, memory sane', async () => {
    const ctx = apps.dairy;
    const rssBefore = rssKb(ctx.proc.pid!);
    const countBefore = rowsOf((await raw(ctx, '/cows?limit=500', { token: ctx.owner })).data).length;
    const reads = Array.from({ length: 150 }, () => raw(ctx, '/cows?limit=10', { token: ctx.owner }));
    const writes = Array.from({ length: 30 }, (_, i) => raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { name: `Soak Cow ${S}-${i}`, breed: 'Jersey', gender: 'female', status: 'active' } }));
    const results = await Promise.all([...reads, ...writes]);
    const fivexx = results.filter((r) => r.response.status >= 500).length;
    expect(fivexx, '5xx under parallel load').toBe(0);
    const created = results.slice(150).filter((r) => r.response.status === 201);
    expect(created.length).toBe(30);
    const countAfter = rowsOf((await raw(ctx, '/cows?limit=500', { token: ctx.owner })).data).length;
    expect(countAfter, 'soak writes lost or duplicated').toBe(countBefore + 30);
    for (const r of created) await raw(ctx, `/cows/${idOf(r.data)}`, { method: 'DELETE', token: ctx.owner });
    const alive = await raw(ctx, '/cows?limit=1', { token: ctx.owner });
    expect(alive.response.status).toBe(200);
    const rssAfter = rssKb(ctx.proc.pid!);
    if (rssBefore && rssAfter) expect(rssAfter - rssBefore, `RSS grew ${Math.round((rssAfter - rssBefore) / 1024)}MB during soak`).toBeLessThan(250 * 1024);
  }, 180_000);

  it('flock + agri soak: 100 parallel reads each, zero 5xx', async () => {
    for (const [name, route] of [['flock', '/batches'], ['agri', '/crops?limit=10']] as const) {
      const ctx = apps[name];
      const results = await Promise.all(Array.from({ length: 100 }, () => raw(ctx, route, { token: ctx.owner })));
      expect(results.filter((r) => r.response.status >= 500).length, `${name} 5xx under load`).toBe(0);
      expect(results.filter((r) => r.response.status === 200).length).toBe(100);
    }
  }, 180_000);

  it('raw-socket smuggling probes: server never hangs and stays healthy (dairy)', async () => {
    const ctx = apps.dairy;
    const port = Number(new URL(ctx.base).port);
    const probes = [
      // duplicate Content-Length with different values
      `POST /api/auth/login HTTP/1.1\r\nHost: x\r\nContent-Type: application/json\r\nContent-Length: 5\r\nContent-Length: 50\r\n\r\n{}`,
      // CL + Transfer-Encoding (classic TE.CL)
      `POST /api/auth/login HTTP/1.1\r\nHost: x\r\nContent-Type: application/json\r\nContent-Length: 4\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\n`,
      // bare-LF line endings + garbage method
      `BREW /api/cows HTTP/1.1\nHost: x\n\n`,
      // absolute-URI form
      `GET http://127.0.0.1:${port}/api/cows HTTP/1.1\r\nHost: x\r\nAuthorization: Bearer ${ctx.owner}\r\n\r\n`,
    ];
    for (const payload of probes) {
      const started = Date.now();
      const res = await rawSocket(port, payload);
      expect(Date.now() - started, 'smuggling probe hung the connection').toBeLessThan(4500);
      expect(res.length, 'no response / connection not handled').toBeGreaterThan(0);
    }
    const alive = await raw(ctx, '/cows?limit=1', { token: ctx.owner });
    expect(alive.response.status, 'server unhealthy after smuggling probes').toBe(200);
  }, 60_000);

  it('DOMPurify: no frontend imports a known-vulnerable DOMPurify (≤3.4.16)', async () => {
    const clients = ['dairy_farm/client', 'flock_farm/client', 'agri_farm/frontend'];
    for (const client of clients) {
      const files = walk(path.join(repoRoot, client, 'src'));
      const importers = files.filter((f) => /dompurify/i.test(readFileSync(f, 'utf8')));
      if (importers.length === 0) continue; // not used → not exploitable
      const lock = JSON.parse(readFileSync(path.join(repoRoot, client, 'package-lock.json'), 'utf8'));
      const ver = lock.packages?.['node_modules/dompurify']?.version || '0.0.0';
      const [maj, min, pat] = ver.split('.').map(Number);
      const vulnerable = maj < 3 || (maj === 3 && (min < 4 || (min === 4 && pat <= 16)));
      expect(vulnerable, `${client} imports DOMPurify ${ver} in ${importers.length} file(s)`).toBe(false);
    }
  });
});
