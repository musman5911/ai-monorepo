/** ROUND R3 (post-186-pull): Phase-1 super-admin owner-only surface. NO fixes; failures = findings. */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { raw, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const dirs: Record<string, string> = { dairy: 'dairy_farm/backend', flock: 'flock_farm/backend', agri: 'agri_farm/backend' };
const apps: Record<string, Ctx> = {};

describe.sequential('ROUND R3: super-admin owner-only', () => {
  beforeAll(async () => { for (const n of ['dairy', 'flock', 'agri']) apps[n] = await startApp(n, dirs[n]); }, 240_000);
  afterAll(async () => { for (const c of Object.values(apps)) await stopApp(c); }, 60_000);

  for (const n of ['dairy', 'flock', 'agri']) {
    it(`${n}: farm-summary is owner-only (anonymous + worker rejected)`, async () => {
      const anon = await raw(apps[n], '/super-admin/farm-summary', {});
      expect([401, 403], `${n} anon summary → ${anon.response.status}`).toContain(anon.response.status);
      const worker = await raw(apps[n], '/super-admin/farm-summary', { token: apps[n].worker });
      expect([401, 403], `${n} worker summary → ${worker.response.status}`).toContain(worker.response.status);
      const owner = await raw(apps[n], '/super-admin/farm-summary', { token: apps[n].owner });
      expect(owner.response.status, `${n} owner summary → ${owner.response.status}`).toBe(200);
    });

    it(`${n}: owner summary covers all of the owner's farms, separated per farm`, async () => {
      const before = await raw(apps[n], '/super-admin/farm-summary', { token: apps[n].owner });
      const beforeText = JSON.stringify(before.data);
      const mk = await raw(apps[n], '/farms', { method: 'POST', token: apps[n].owner, body: { name: `R3 Summary Farm ${n}` } });
      expect([200, 201], `${n} create farm → ${mk.response.status}`).toContain(mk.response.status);
      const after = await raw(apps[n], '/super-admin/farm-summary', { token: apps[n].owner });
      expect(JSON.stringify(after.data), `${n} summary does not list the new farm separately`).toContain(`R3 Summary Farm ${n}`);
      expect(beforeText.length).toBeLessThan(JSON.stringify(after.data).length);
    });

    it(`${n}: summary requires session auth, not the shared cross-app key alone`, async () => {
      const res = await fetch(`${apps[n].base}/api/super-admin/farm-summary`, { headers: { 'X-Farm-Summary-Key': 'whatever', 'x-api-key': 'whatever' } });
      expect([401, 403], `${n} shared-key-only summary → ${res.status}`).toContain(res.status);
    });
  }

  it('dairy: farm role is preserved at login and cleared at logout', async () => {
    const me1 = await raw(apps.dairy, '/auth/me', { token: apps.dairy.owner });
    expect(me1.response.status).toBe(200);
    const roleText = JSON.stringify(me1.data).toLowerCase();
    expect(roleText, 'owner session carries no farm role').toMatch(/owner|admin/);
    const out = await raw(apps.dairy, '/auth/logout', { method: 'POST', token: apps.dairy.owner });
    expect(out.response.status).toBeLessThan(300);
    const me2 = await raw(apps.dairy, '/auth/me', { token: apps.dairy.owner });
    // Logout may or may not revoke the token (known finding); but if the
    // session still answers, it must not keep claiming a farm role it cleared.
    if (me2.response.status === 200) {
      const t2 = JSON.stringify(me2.data).toLowerCase();
      expect(t2.includes('"farmrole":"owner"') || t2.includes('"farmrole": "owner"'), 'logout did not clear farm role (session still owner-scoped)').toBe(false);
    }
  });
});
