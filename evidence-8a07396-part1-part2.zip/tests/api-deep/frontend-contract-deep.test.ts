/**
 * ROUND 13 — frontend↔backend contract sweep (static).
 * Every API path a frontend calls must exist in its backend's
 * route table (any method). A path with no matching route is a
 * dead call = silent UI glitch. NO fixes; failures = findings.
 */
import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import { repoRoot } from '../api-matrix/harness';

function walk(dir: string, out: string[] = []): string[] {
  for (const e of readdirSync(dir)) {
    if (e === 'node_modules' || e === 'dist') continue;
    const p = path.join(dir, e);
    if (statSync(p).isDirectory()) walk(p, out);
    else if (/\.(ts|tsx|js|jsx)$/.test(e)) out.push(p);
  }
  return out;
}
const seg = (s: string) => s.split('/').filter(Boolean).map((x) =>
  x.startsWith(':') || x === ':p' || /^\{.*\}$/.test(x) ? ':p' : x.toLowerCase());
function matches(a: string, b: string): boolean {
  const A = seg(a); const B = seg(b);
  if (A.length !== B.length) return false;
  return A.every((s, i) => s === ':p' || B[i] === ':p' || s === B[i]);
}

/** Backend route table: every router.METHOD('path') both bare and mount-prefixed. */
function backendRoutes(backendDir: string): string[] {
  const routes: string[] = [];
  const server = readFileSync(path.join(backendDir, 'server.js'), 'utf8');
  const mounts = new Map<string, string>(); // import name -> prefix
  for (const m of server.matchAll(/app\.use\('(\/api[^']*)',\s*([A-Za-z0-9_]+)/g)) mounts.set(m[2], m[1]);
  const imports = new Map<string, string>(); // var -> file
  for (const m of server.matchAll(/import\s+([A-Za-z0-9_]+)[^;]*from\s+'\.\/routes\/([a-z0-9-]+)\.js'/g)) imports.set(m[1], m[2]);
  // agri-style: routers array mounted at /api (paths inside files are full)
  // inline routes defined directly in server.js (e.g. /api/farm-summary)
  for (const m of server.matchAll(/app\.(get|post|put|patch|delete)\('(\/api[^']*)'/g)) {
    routes.push(m[2].replace(/^\/api/, '') || '/');
  }
  const routeFiles = readdirSync(path.join(backendDir, 'routes')).filter((f) => f.endsWith('.js'));
  for (const f of routeFiles) {
    const text = readFileSync(path.join(backendDir, 'routes', f), 'utf8');
    if (text.includes('mufCreateFarmsRouter')) {
      // generated router (muf-farms.mjs): /, /:id, /:id/archive, /:id/restore
      let prefix2 = '/api';
      for (const [varName, file] of imports) if (file === f.replace('.js', '') && mounts.has(varName)) prefix2 = mounts.get(varName)!;
      const base = prefix2.replace('/api', '');
      routes.push(base || '/', `${base}/:id`, `${base}/:id/archive`, `${base}/:id/restore`);
    }
    let prefix = '/api';
    for (const [varName, file] of imports) if (file === f.replace('.js', '') && mounts.has(varName)) prefix = mounts.get(varName)!;
    for (const m of text.matchAll(/router\.(get|post|put|patch|delete)\('([^']+)'/g)) {
      routes.push(m[2]); // bare (covers /api-mounted routers)
      if (prefix !== '/api') routes.push(prefix.replace('/api', '') + (m[2] === '/' ? '' : m[2]));
    }
  }
  return routes;
}

/** Frontend API paths (relative to /api). */
function frontendPaths(clientDir: string): string[] {
  const found = new Set<string>();
  for (const f of walk(clientDir)) {
    const text = readFileSync(f, 'utf8');
    for (const m of text.matchAll(/['"`](\/[a-zA-Z][a-zA-Z0-9/_-]*)(?:[?'"`]|$)/g)) {
      let p = m[1];
      if (/\.(png|jpg|svg|css|ico|json|woff)/.test(p)) continue;
      found.add(p.replace(/^\/api(?=\/)/, ''));
    }
    for (const m of text.matchAll(/`(\/[a-zA-Z][a-zA-Z0-9/_-]*(?:\/\$\{[^}]+\}[a-zA-Z0-9/_-]*)+)[`?]/g)) {
      found.add(m[1].replace(/^\/api(?=\/)/, '').replace(/\$\{[^}]+\}/g, ':p'));
    }
  }
  return [...found];
}

const APPS: Array<[string, string, string]> = [
  ['dairy', 'dairy_farm/client', 'dairy_farm/backend'],
  ['flock', 'flock_farm/client', 'flock_farm/backend'],
  ['agri', 'agri_farm/frontend', 'agri_farm/backend'],
];
// paths that are frontend page routes, not API calls (vetted manually)
const PAGE_ROUTES = new Set(['/login', '/signup', '/dashboard', '/home', '/register', '/forgot-password', '/auth/forgot', '/auth/reset', '/public', '/public/', '/api', '/auth', '/data',
  // cross-app switcher config (muf-farm-switcher.tsx): paths of the OTHER
  // apps, only ever called against those apps' own backends — vetted manually
  '/users/:p/edit', '/auth/me', '/auth/users', '/auth/users/:p']);

describe('ROUND 13: frontend↔backend contract', () => {
  for (const [name, client, backend] of APPS) {
    it(`${name}: every API path the frontend calls exists in the backend`, () => {
      const routes = backendRoutes(path.join(repoRoot, backend));
      const paths = frontendPaths(path.join(repoRoot, client, 'src'))
        .filter((p) => !PAGE_ROUTES.has(p) && p.length > 1);
      const dead = paths.filter((p) => !routes.some((r) => matches(p, r)));
      expect(dead, `${name} dead: ${JSON.stringify(dead)}`).toEqual([]);
    });
  }
});
