/**
 * ROUND 18 — farm deletion with deleteData:true (scoped data
 * wipe) in all 3 apps + restore-after-farm-delete (dairy).
 * The deleteData path exercises the farm-scoped deletion code
 * that regressed elsewhere (Q1). NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const apps: Record<string, Ctx> = {};

async function mkFarm(ctx: Ctx, label: string) {
  const r = await raw(ctx, '/farms', { method: 'POST', token: ctx.owner, body: { name: `${label} ${S}` } });
  expect([200, 201]).toContain(r.response.status);
  return String(r.data?.farm?.id || r.data?.id || r.data?.farm?._id || r.data?._id);
}

describe.sequential('ROUND 18: deleteData farm wipe + restore', () => {
  beforeAll(async () => {
    apps.dairy = await startApp('dairy', 'dairy_farm/backend');
    apps.flock = await startApp('flock', 'flock_farm/backend');
    apps.agri = await startApp('agri', 'agri_farm/backend');
  }, 180_000);
  afterAll(async () => { for (const c of Object.values(apps)) await stopApp(c); }, 60_000);

  it('dairy: delete farm with deleteData:true wipes its records, keeps other farms intact', async () => {
    const ctx = apps.dairy;
    const farmB = await mkFarm(ctx, 'WIPE Farm');
    const cow = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, farmId: farmB, body: { name: `WIPE Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    const cowId = idOf(cow.data);
    expect(cowId).toBeTruthy();
    const del = await raw(ctx, `/farms/${farmB}`, { method: 'DELETE', token: ctx.owner, body: { confirmName: `WIPE Farm ${S}`, deleteData: true } });
    expect(del.response.status, `deleteData farm wipe → ${del.response.status} ${JSON.stringify(del.data).slice(0, 140)}`).toBe(200);
    const farms = await raw(ctx, '/farms', { token: ctx.owner });
    expect(JSON.stringify(farms.data), 'farm still listed after wipe').not.toContain(farmB);
    const cowGone = await raw(ctx, `/cows/${cowId}`, { token: ctx.owner, farmId: 'all' });
    expect(cowGone.response.status, 'wiped farm cow still readable').toBe(404);
    const defaultList = await raw(ctx, '/cows?limit=5', { token: ctx.owner });
    expect(defaultList.response.status).toBe(200);
  });

  it('flock + agri: deleteData farm wipe works in memory mode too', async () => {
    const fctx = apps.flock;
    const fFarm = await mkFarm(fctx, 'WIPE Flock Farm');
    const batch = await raw(fctx, '/batches', { method: 'POST', token: fctx.owner, farmId: fFarm, body: { name: `WIPE Batch ${S}`, type: 'Broiler', start_date: '2026-09-01', intake_count: 5, cost_per_bird: 10 } });
    expect(batch.response.status).toBe(201);
    const fDel = await raw(fctx, `/farms/${fFarm}`, { method: 'DELETE', token: fctx.owner, body: { confirmName: `WIPE Flock Farm ${S}`, deleteData: true } });
    expect(fDel.response.status, `flock deleteData wipe → ${fDel.response.status} ${JSON.stringify(fDel.data).slice(0, 140)}`).toBe(200);

    const actx = apps.agri;
    const aFarm = await mkFarm(actx, 'WIPE Agri Farm');
    const crop = await raw(actx, '/crops', { method: 'POST', token: actx.owner, farmId: aFarm, body: { name: `WIPE Crop ${S}`, status: 'Growing', plant_date: '2026-09-01' } });
    expect([200, 201]).toContain(crop.response.status);
    const aDel = await raw(actx, `/farms/${aFarm}`, { method: 'DELETE', token: actx.owner, body: { confirmName: `WIPE Agri Farm ${S}`, deleteData: true } });
    expect(aDel.response.status, `agri deleteData wipe → ${aDel.response.status} ${JSON.stringify(aDel.data).slice(0, 140)}`).toBe(200);
  });

  it('dairy: backup → delete farm+data → restore brings the farm and its cow back', async () => {
    const ctx = apps.dairy;
    const farmB = await mkFarm(ctx, 'PHOENIX Farm');
    const cow = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, farmId: farmB, body: { name: `PHOENIX Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    const cowId = idOf(cow.data);
    const backup = await raw(ctx, '/backup', { token: ctx.owner });
    expect(backup.response.status).toBe(200);
    const del = await raw(ctx, `/farms/${farmB}`, { method: 'DELETE', token: ctx.owner, body: { confirmName: `PHOENIX Farm ${S}`, deleteData: true } });
    expect(del.response.status).toBe(200);
    const gone = await raw(ctx, `/cows/${cowId}`, { token: ctx.owner, farmId: 'all' });
    expect(gone.response.status).toBe(404);
    const restore = await raw(ctx, '/backup/restore', { method: 'POST', token: ctx.owner, body: backup.data });
    expect([200, 201], `restore → ${restore.response.status}`).toContain(restore.response.status);
    const farms = await raw(ctx, '/farms', { token: ctx.owner });
    expect(JSON.stringify(farms.data), 'restored backup did not bring the farm back').toContain(`PHOENIX Farm ${S}`);
    const back = await raw(ctx, `/cows/${cowId}`, { token: ctx.owner, farmId: 'all' });
    expect(back.response.status, 'restored farm cow not readable').toBe(200);
  });
});
