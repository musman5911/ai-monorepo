/** ROUND R2 (post-186-pull): Agri fields + crop-cycle links + field analytics + backup. NO fixes; failures = findings. */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

describe.sequential('ROUND R2: agri fields & cycles', () => {
  let ctx: Ctx; let fieldA = ''; let farmB = ''; let fieldB = '';
  beforeAll(async () => {
    ctx = await startApp('agri', 'agri_farm/backend');
    const f = await raw(ctx, '/farms', { method: 'POST', token: ctx.owner, body: { name: `R2 FarmB ${S}` } });
    farmB = String(f.data?.farm?.id || f.data?.id || f.data?.farm?._id || f.data?._id);
  }, 120_000);
  afterAll(async () => { await stopApp(ctx); }, 60_000);

  it('field CRUD + validation: duplicate/empty rejected, worker cannot create', async () => {
    const c = await raw(ctx, '/fields', { method: 'POST', token: ctx.owner, body: { name: `R2 Field ${S}`, area_kanal: 12 } });
    expect([200, 201], `create field → ${c.response.status} ${JSON.stringify(c.data).slice(0, 120)}`).toContain(c.response.status);
    fieldA = idOf(c.data);
    expect(fieldA).toBeTruthy();
    const empty = await raw(ctx, '/fields', { method: 'POST', token: ctx.owner, body: {} });
    expect([400, 422], `empty field → ${empty.response.status}`).toContain(empty.response.status);
    const w = await raw(ctx, '/fields', { method: 'POST', token: ctx.worker, body: { name: `R2 WField ${S}` } });
    expect([401, 403], `worker create field → ${w.response.status}`).toContain(w.response.status);
    const fb = await raw(ctx, '/fields', { method: 'POST', token: ctx.owner, farmId: farmB, body: { name: `R2 FieldB ${S}`, area_kanal: 5 } });
    fieldB = idOf(fb.data);
    expect(fieldB).toBeTruthy();
  });

  it('crop cannot link to another farm field; same-farm link works and survives edit', async () => {
    const cross = await raw(ctx, '/crops', { method: 'POST', token: ctx.owner, body: { name: `R2 CrossCrop ${S}`, status: 'Growing', plant_date: '2026-10-01', fieldId: fieldB } });
    expect([400, 422], `crop + farm-B field → ${cross.response.status} ${JSON.stringify(cross.data).slice(0, 100)}`).toContain(cross.response.status);
    const ok = await raw(ctx, '/crops', { method: 'POST', token: ctx.owner, body: { name: `R2 Crop ${S}`, status: 'Growing', plant_date: '2026-10-01', fieldId: fieldA } });
    expect([200, 201], `crop + own field → ${ok.response.status}`).toContain(ok.response.status);
    const cropId = idOf(ok.data);
    const edit = await raw(ctx, `/crops/${cropId}`, { method: 'PUT', token: ctx.owner, body: { name: `R2 Crop ${S}`, status: 'Growing', plant_date: '2026-10-01' } });
    expect(edit.response.status).toBeLessThan(300);
    const afterList = await raw(ctx, `/crops?fieldId=${fieldA}&limit=100`, { token: ctx.owner });
    const afterRow = (Array.isArray(afterList.data) ? afterList.data : []).find((r: any) => String(r._id) === cropId);
    expect(afterRow, 'field link lost after legacy edit (crop no longer under field filter)').toBeTruthy();
    const byField = await raw(ctx, `/crops?fieldId=${fieldA}&limit=50`, { token: ctx.owner });
    expect(JSON.stringify(byField.data), 'field_id filter misses linked crop').toContain(`R2 Crop ${S}`);
  });

  it('finance summary by field: linked expense counts under the field, unlinked stays unassigned', async () => {
    const crop = await raw(ctx, '/crops?limit=5', { token: ctx.owner });
    const cropId = idOf(Array.isArray(crop.data) ? crop.data[0] : (crop.data?.items?.[0] || {}));
    const fin = await raw(ctx, '/finance', { method: 'POST', token: ctx.owner, body: { type: 'expense', amount: 24680, category: `R2CAT${S}`, date: '2026-10-03', fieldId: fieldA, crop_id: cropId || undefined } });
    expect(fin.response.status, `finance+field → ${fin.response.status} ${JSON.stringify(fin.data).slice(0, 100)}`).toBeLessThan(300);
    const sum = await raw(ctx, '/analytics/summary', { token: ctx.owner });
    expect(sum.response.status).toBe(200);
    const text = JSON.stringify(sum.data);
    const byField = (sum.data as any)?.financeSummary?.byField || [];
    const mine = byField.find((r: any) => JSON.stringify(r).includes(`R2 Field ${S}`) || String(r.fieldId || '') === fieldA);
    expect(mine, `no byField entry for the new field in ${JSON.stringify(byField).slice(0, 200)}`).toBeTruthy();
    expect(Number(mine.expense ?? mine.amount ?? 0), 'field-linked amount not totalled under the field').toBeGreaterThanOrEqual(24680);
  });

  it('fields survive backup → delete → restore; deleting a used field is guarded or unlinks safely', async () => {
    const backup = await raw(ctx, '/backup', { token: ctx.owner });
    expect(backup.response.status).toBe(200);
    expect(JSON.stringify(backup.data), 'backup omits fields collection').toContain(`R2 Field ${S}`);
    const del = await raw(ctx, `/fields/${fieldA}`, { method: 'DELETE', token: ctx.owner });
    // Either guarded (4xx while crops link to it) or allowed with crops unlinked (not dangling).
    if (del.response.status < 300) {
      const crops = await raw(ctx, '/crops?limit=100', { token: ctx.owner });
      expect(JSON.stringify(crops.data), 'crop still points at deleted field').not.toContain(fieldA);
    } else {
      expect([400, 409, 422], `delete used field → ${del.response.status}`).toContain(del.response.status);
      const restore = await raw(ctx, '/restore', { method: 'POST', token: ctx.owner, body: backup.data });
      expect(restore.response.status, `restore → ${restore.response.status}`).toBeLessThan(300);
      const fields = await raw(ctx, '/fields', { token: ctx.owner });
      expect(JSON.stringify(fields.data), 'field missing after restore').toContain(`R2 Field ${S}`);
    }
  });
});
