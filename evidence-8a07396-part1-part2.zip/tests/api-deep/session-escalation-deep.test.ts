/**
 * DEEPEST round — session lifecycle (logout / password change /
 * user deletion must revoke tokens), privilege escalation via
 * signup + mass assignment, backup credential leakage, login
 * brute-force throttling. NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, rowsOf, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const apps: Record<string, Ctx> = {};
const LIST: Record<string, string> = { dairy: '/cows?limit=3', flock: '/batches', agri: '/crops?limit=3' };

async function loginAs(name: string, ctx: Ctx, u: string, p: string) {
  const r = name === 'agri'
    ? await raw(ctx, '/login', { method: 'POST', form: { username: u, password: p } })
    : await raw(ctx, '/auth/login', { method: 'POST', body: { username: u, password: p } });
  return { status: r.response.status, token: r.data?.token || r.data?.access_token || '' };
}

async function firstFarmId(ctx: Ctx) {
  const r = await raw(ctx, '/farms', { token: ctx.owner });
  const rows = rowsOf(r.data).length ? rowsOf(r.data) : (r.data?.farms || []);
  return rows[0] ? String(rows[0]._id || rows[0].id) : '';
}
async function createWorker(name: string, ctx: Ctx, username: string) {
  const farmId = await firstFarmId(ctx);
  const body = { username, password: '[SECURITY_DATA]', role: 'worker', displayName: 'Deep Probe', farmIds: farmId ? [farmId] : [], farmId };
  const route = name === 'agri' ? '/signup' : '/auth/users';
  const r = await raw(ctx, route, { method: 'POST', token: ctx.owner, body });
  return r;
}
async function findUserId(name: string, ctx: Ctx, username: string) {
  const route = name === 'agri' ? '/users' : '/auth/users';
  const r = await raw(ctx, route, { token: ctx.owner });
  const rows = rowsOf(r.data).length ? rowsOf(r.data) : (r.data?.users || []);
  const u = rows.find((x: any) => x.username === username);
  return u ? String(u._id || u.id) : '';
}
async function deleteUser(name: string, ctx: Ctx, id: string) {
  const route = name === 'agri' ? `/users/${id}` : `/auth/users/${id}`;
  return raw(ctx, route, { method: 'DELETE', token: ctx.owner });
}

describe.sequential('DEEPEST: sessions, escalation, leakage, throttling', () => {
  beforeAll(async () => {
    apps.dairy = await startApp('dairy', 'dairy_farm/backend');
    apps.flock = await startApp('flock', 'flock_farm/backend');
    apps.agri = await startApp('agri', 'agri_farm/backend');
  }, 180_000);
  afterAll(async () => { for (const c of Object.values(apps)) await stopApp(c); }, 60_000);

  for (const name of ['dairy', 'flock', 'agri']) {
    it(`${name}: token is revoked after logout`, async () => {
      const ctx = apps[name];
      const { token } = await loginAs(name, ctx, 'worker', 'worker123');
      expect(token).toBeTruthy();
      const logoutRoute = name === 'agri' ? '/logout' : '/auth/logout';
      await raw(ctx, logoutRoute, { method: 'POST', token });
      const after = await raw(ctx, LIST[name], { token });
      expect(after.response.status, 'pre-logout token still works after logout').toBe(401);
    });

    it(`${name}: token of a DELETED user stops working`, async () => {
      const ctx = apps[name];
      const username = `gp${name}${S.slice(-6)}`;
      const created = await createWorker(name, ctx, username);
      expect([200, 201], `create probe user: ${created.response.status} ${JSON.stringify(created.data).slice(0, 120)}`).toContain(created.response.status);
      let token = '';
      for (let i = 0; i < 8 && !token; i++) {
        const lr = name === 'agri'
          ? await raw(ctx, '/login', { method: 'POST', form: { username, password: '[SECURITY_DATA]' } })
          : await raw(ctx, '/auth/login', { method: 'POST', body: { username, password: '[SECURITY_DATA]' } });
        token = lr.data?.token || lr.data?.access_token || '';
        if (!token) await new Promise((r) => setTimeout(r, 400));
      }
            expect(token, `probe login failed for ${name}`).toBeTruthy();
      const uid = (await findUserId(name, ctx, username)) || idOf(created.data);
      expect(uid).toBeTruthy();
      const del = await deleteUser(name, ctx, uid);
      expect([200, 204]).toContain(del.response.status);
      const after = await raw(ctx, LIST[name], { token });
      expect(after.response.status, 'deleted user token still works').toBe(401);
    });

    it(`${name}: backup export contains no password hashes or secrets`, async () => {
      const ctx = apps[name];
      const r = await raw(ctx, '/backup', { token: ctx.owner });
      expect(r.response.status).toBe(200);
      const text = JSON.stringify(r.data);
      expect(text, 'backup leaks bcrypt hash').not.toMatch(/\$2[aby]\$\d{2}\$/);
      expect(text, 'backup leaks password field').not.toMatch(/"password"\s*:\s*"/);
      expect(text, 'backup leaks scrypt/pbkdf2 hash').not.toMatch(/scrypt\$|pbkdf2\$/i);
      expect(text).not.toContain('local-e2e-test-secret');
    });

    it(`${name}: mass assignment on create cannot forge id/role/farm ownership`, async () => {
      const ctx = apps[name];
      const forgedId = `forged-${S}`;
      if (name === 'dairy') {
        const r = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { name: `MA Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active', _id: forgedId, id: forgedId, role: 'admin', isAdmin: true } as any });
        expect(r.response.status).toBe(201);
        expect(idOf(r.data), 'server honored client-supplied _id').not.toBe(forgedId);
        const got = await raw(ctx, `/cows/${idOf(r.data)}`, { token: ctx.owner });
        expect((got.data as any).role).toBeUndefined();
        await raw(ctx, `/cows/${idOf(r.data)}`, { method: 'DELETE', token: ctx.owner });
      } else if (name === 'agri') {
        const r = await raw(ctx, '/crops', { method: 'POST', token: ctx.owner, body: { name: `MA Crop ${S}`, status: 'Growing', plant_date: '2026-09-01', _id: forgedId, role: 'admin' } as any });
        expect(r.response.status).toBe(201);
        expect(idOf(r.data), 'server honored client-supplied _id').not.toBe(forgedId);
        await raw(ctx, `/crops/${idOf(r.data)}`, { method: 'DELETE', token: ctx.owner });
      } else {
        const r = await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, body: { name: `MA Batch ${S}`, type: 'Broiler', start_date: '2026-09-01', intake_count: 5, cost_per_bird: 10, batch_id: forgedId, role: 'admin' } as any });
        expect(r.response.status).toBe(201);
        expect(String(r.data.batch.batch_id), 'server honored client-supplied batch_id').not.toBe(forgedId);
        await raw(ctx, `/batches/${r.data.batch.batch_id}`, { method: 'DELETE', token: ctx.owner });
      }
    });
  }

  it('agri: unauthenticated signup cannot mint an owner account', async () => {
    const ctx = apps.agri;
    const username = `selfmint${S}`;
    const r = await raw(ctx, '/signup', { method: 'POST', body: { username, password: '[SECURITY_DATA]', role: 'owner', email: `${username}@example.com` } });
    expect([400, 401, 403, 409, 422], `open signup returned ${r.response.status}`).toContain(r.response.status);
    if (r.response.status < 300) {
      const { token } = await loginAs('agri', ctx, username, 'MintPass123!');
      const backup = await raw(ctx, '/backup', { token });
      expect(backup.response.status, 'self-minted user reached owner-only backup').toBe(403);
      const uid = await findUserId('agri', ctx, username);
      if (uid) await deleteUser('agri', ctx, uid);
    }
  });

  it('dairy: changing password revokes previously issued tokens', async () => {
    const ctx = apps.dairy;
    const username = `cp${S.slice(-8)}`;
    const created = await createWorker('dairy', ctx, username);
    expect([200, 201]).toContain(created.response.status);
    let token = '';
    for (let i = 0; i < 8 && !token; i++) {
      const lr = await raw(ctx, '/auth/login', { method: 'POST', body: { username, password: '[SECURITY_DATA]' } });
      token = lr.data?.token || '';
      if (!token) await new Promise((r) => setTimeout(r, 400));
    }
    expect(token).toBeTruthy();
    const change = await raw(ctx, '/auth/change-password', { method: 'POST', token, body: { currentPassword: '[SECURITY_DATA]', newPassword: '[SECURITY_DATA]' } });
    expect([200, 201], `change-password: ${change.response.status} ${JSON.stringify(change.data).slice(0, 120)}`).toContain(change.response.status);
    const after = await raw(ctx, LIST.dairy, { token });
    expect(after.response.status, 'pre-password-change token still works').toBe(401);
    const uid = (await findUserId('dairy', ctx, username)) || idOf(created.data);
    if (uid) await deleteUser('dairy', ctx, uid);
  });

  it('login throttling: 60 rapid failed logins trigger rate limiting (429)', async () => {
    for (const name of ['dairy', 'flock', 'agri']) {
      const ctx = apps[name];
      let saw429 = false;
      const attempts = name === 'agri' ? 150 : 60;
      for (let i = 0; i < attempts && !saw429; i++) {
        const r = name === 'agri'
          ? await raw(ctx, '/login', { method: 'POST', form: { username: `brute${S}`, password: '[SECURITY_DATA]' } })
          : await raw(ctx, '/auth/login', { method: 'POST', body: { username: `brute${S}`, password: '[SECURITY_DATA]' } });
        if (r.response.status === 429) saw429 = true;
      }
      expect(saw429, `${name}: no 429 after ${attempts} failed logins`).toBe(true);
    }
  }, 120_000);
});
