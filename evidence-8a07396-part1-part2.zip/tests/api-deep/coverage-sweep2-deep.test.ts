/**
 * ROUND 12 (new sweep) — Agri uncovered endpoints: automations,
 * location, diary-media, cron dispatch; unknown-route handling
 * across all apps. NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const apps: Record<string, Ctx> = {};

describe.sequential('ROUND 12: agri coverage + unknown routes', () => {
  beforeAll(async () => {
    apps.dairy = await startApp('dairy', 'dairy_farm/backend');
    apps.flock = await startApp('flock', 'flock_farm/backend');
    apps.agri = await startApp('agri', 'agri_farm/backend');
  }, 180_000);
  afterAll(async () => { for (const c of Object.values(apps)) await stopApp(c); }, 60_000);

  it('agri farm GPS location is not public', async () => {
    const ctx = apps.agri;
    const put = await raw(ctx, '/settings/location', { method: 'PUT', token: ctx.owner, body: { lat: 31.5204, lon: 74.3587, city: `Probe City ${S}` } });
    expect([200, 201]).toContain(put.response.status);
    const pub = await fetch(`${ctx.base}/api/settings/location`);
    expect(pub.status, 'agri farm location served without login').toBe(401);
    if (pub.status === 200) {
      const body = await pub.text();
      expect(body, 'public location leaks coordinates').not.toContain('31.5204');
    }
  });

  it('agri automations are admin-only and validate their payload', async () => {
    const ctx = apps.agri;
    const workerGet = await raw(ctx, '/settings/automations', { token: ctx.worker });
    expect([401, 403]).toContain(workerGet.response.status);
    const ownerGet = await raw(ctx, '/settings/automations', { token: ctx.owner });
    expect(ownerGet.response.status).toBe(200);
    const workerTrigger = await raw(ctx, '/settings/automations/trigger', { method: 'POST', token: ctx.worker, body: {} });
    expect([401, 403]).toContain(workerTrigger.response.status);
    const garbage = await raw(ctx, '/settings/automations', { method: 'PUT', token: ctx.owner, body: { dailyReportTime: '99:99', weeklyDay: 'Funday', enabled: 'yes-please', reportEmail: 'not-an-email' } });
    expect(garbage.response.status, `automations accepted garbage config → ${garbage.response.status}`).toBeGreaterThanOrEqual(400);
  });

  it('agri diary-media: round-trip works, garbage dates and mega-payloads are safe', async () => {
    const ctx = apps.agri;
    const put = await raw(ctx, '/diary-media/2026-09-25', { method: 'PUT', token: ctx.owner, body: { entries: [{ id: `e-${S}`, note: `Agri diary ${S}`, photos: [] }] } });
    expect([200, 201]).toContain(put.response.status);
    const got = await raw(ctx, '/diary-media/2026-09-25', { token: ctx.owner });
    expect(JSON.stringify(got.data)).toContain(`Agri diary ${S}`);
    for (const bad of ['not-a-date', '2026-02-30', '2026-13-01']) {
      const w = await raw(ctx, `/diary-media/${bad}`, { method: 'PUT', token: ctx.owner, body: { notes: 'x' } });
      expect(w.response.status, `diary-media PUT ${bad} must reject`).toBeGreaterThanOrEqual(400);
      expect(w.response.status).toBeLessThan(500);
    }
    const huge = await raw(ctx, '/diary-media/2026-09-26', { method: 'PUT', token: ctx.owner, body: { notes: 'big', photos: ['data:image/png;base64,' + 'A'.repeat(3_000_000)] } });
    expect(huge.response.status).toBeLessThan(500);
  });

  it('agri cron dispatch + telegram settings refuse unauthorized callers', async () => {
    const ctx = apps.agri;
    const cron = await fetch(`${ctx.base}/api/cron/dispatch-report`);
    expect([401, 403, 503]).toContain(cron.status);
    const cronPost = await raw(ctx, '/cron/dispatch-report', { method: 'POST', body: {} });
    expect([401, 403, 503]).toContain(cronPost.response.status);
    const tgWorker = await raw(ctx, '/telegram/settings', { token: ctx.worker });
    expect([401, 403]).toContain(tgWorker.response.status);
  });

  it('unknown API routes return JSON 404s (never HTML, never 500) in all apps', async () => {
    for (const name of ['dairy', 'flock', 'agri'] as const) {
      const ctx = apps[name];
      for (const method of ['GET', 'POST', 'DELETE']) {
        const res = await fetch(`${ctx.base}/api/definitely-not-a-route-${S}`, { method, headers: { Authorization: `Bearer ${ctx.owner}`, 'Content-Type': 'application/json' }, body: method === 'GET' ? undefined : '{}' });
        expect(res.status, `${name} ${method} unknown route`).toBe(404);
        const ct = res.headers.get('content-type') || '';
        expect(ct, `${name} unknown route answered ${ct}`).toContain('application/json');
        await res.text();
      }
      // version-prefix confusion must not alias into the API
      const v1 = await fetch(`${ctx.base}/api/v1/cows`, { headers: { Authorization: `Bearer ${ctx.owner}` } });
      expect([401, 404]).toContain(v1.status);
    }
  });

  it('root and health endpoints do not disclose stack or env details', async () => {
    for (const name of ['dairy', 'flock', 'agri'] as const) {
      const ctx = apps[name];
      for (const path of ['/', '/api', '/api/health', '/health']) {
        const res = await fetch(`${ctx.base}${path}`);
        const text = await res.text();
        expect(res.status, `${name} ${path}`).toBeLessThan(500);
        expect(text, `${name} ${path} leaks env`).not.toMatch(/JWT_SECRET|MONGO_URI|password\s*[:=]\s*\S+/i);
        expect(text).not.toMatch(/node_modules|at .*\(.*:\d+:\d+\)/);
      }
    }
  });
});
