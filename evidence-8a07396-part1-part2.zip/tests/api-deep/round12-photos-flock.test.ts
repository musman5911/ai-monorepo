/** ROUND 12B (Phase 9): Flock photo routes — /uploads/image, /uploads/diary-image, /images/:id. NO fixes. */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', 'base64');
const SVG = Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>');

describe.sequential('ROUND 12B: photos (flock)', () => {
  let ctx: Ctx; let farmA = ''; let farmB = ''; let imgB = ''; let mgrA = '';
  const upload = async (token: string, route: string, bytes: Buffer, type: string, farmId?: string) => {
    const form = new FormData();
    form.append('image', new Blob([new Uint8Array(bytes)], { type }), 'probe.bin');
    const headers: Record<string, string> = { Authorization: `Bearer ${token}` };
    if (farmId) headers['X-Farm-Id'] = farmId;
    const res = await fetch(`${ctx.base}${route}`, { method: 'POST', headers, body: form });
    const text = await res.text();
    let json: any = {}; try { json = JSON.parse(text); } catch { /* keep text */ }
    return { status: res.status, json, text, headers: res.headers };
  };
  beforeAll(async () => {
    ctx = await startApp('flock', 'flock_farm/backend');
    const farms = await raw(ctx, '/farms', { token: ctx.owner });
    farmA = String(((farms.data as any)?.farms || [])[0]?.id || '');
    const fb = await raw(ctx, '/farms', { method: 'POST', token: ctx.owner, body: { name: `P12B FarmB ${S}` } });
    farmB = String((fb.data as any)?.id || idOf(fb.data));
    const uname = `p12bflock${S}`;
    const mk = await raw(ctx, '/auth/users', { method: 'POST', token: ctx.owner, body: { username: uname, password: '[SECURITY_DATA]', role: 'manager', email: `${uname}@t.local`, farmIds: [farmA] } });
    expect([200, 201], `mgr create → ${mk.response.status}`).toContain(mk.response.status);
    const l = await raw(ctx, '/auth/login', { method: 'POST', body: { username: uname, password: '[SECURITY_DATA]' } });
    mgrA = String((l.data as any)?.token || '');
    const upB = await upload(ctx.owner, '/api/uploads/image?kind=bird', PNG, 'image/png', farmB);
    expect(upB.status, `owner upload B → ${upB.status} ${upB.text.slice(0, 120)}`).toBeLessThan(300);
    imgB = String(upB.json?.id || upB.json?.image?.id || upB.json?._id || String(upB.json?.path || '').split('/').pop() || '');
    expect(imgB, `no image id in ${upB.text.slice(0, 160)}`).toBeTruthy();
  }, 180_000);
  afterAll(async () => { await stopApp(ctx); }, 60_000);

  it('unauthenticated image read: 401, no bytes, no cloudinary redirect', async () => {
    const res = await fetch(`${ctx.base}/api/images/${imgB}`);
    expect([401, 403], `unauth GET image → ${res.status}`).toContain(res.status);
    expect(res.headers.get('location') || '').not.toContain('cloudinary');
  });

  it('farm isolation: manager of A cannot read/delete farm B image', async () => {
    const read = await fetch(`${ctx.base}/api/images/${imgB}`, { headers: { Authorization: `Bearer ${mgrA}` } });
    expect([403, 404], `mgrA read imgB → ${read.status}`).toContain(read.status);
    const del = await raw(ctx, `/images/${imgB}`, { method: 'DELETE', token: mgrA });
    expect([401, 403, 404], `mgrA delete imgB → ${del.response.status}`).toContain(del.response.status);
  });

  it('roles: worker cannot use admin upload; diary upload + delete fencing', async () => {
    const wUp = await upload(ctx.worker, '/api/uploads/image?kind=bird', PNG, 'image/png', farmA);
    expect([401, 403], `worker admin-upload → ${wUp.status}`).toContain(wUp.status);
    const wDel = await raw(ctx, `/images/${imgB}`, { method: 'DELETE', token: ctx.worker });
    expect([401, 403, 404], `worker delete image → ${wDel.response.status}`).toContain(wDel.response.status);
    const mDel = await raw(ctx, `/images/${imgB}`, { method: 'DELETE', token: mgrA });
    expect([401, 403, 404], `manager(A) delete image B → ${mDel.response.status}`).toContain(mDel.response.status);
  });

  it('validation: SVG rejected on both upload routes; wrong field name rejected', async () => {
    const svg1 = await upload(ctx.owner, '/api/uploads/image?kind=bird', SVG, 'image/svg+xml', farmA);
    expect(svg1.status, `svg admin route → ${svg1.status}`).toBeGreaterThanOrEqual(400);
    const svg2 = await upload(ctx.owner, '/api/uploads/diary-image', SVG, 'image/svg+xml', farmA);
    expect(svg2.status, `svg diary route → ${svg2.status}`).toBeGreaterThanOrEqual(400);
    const form = new FormData();
    form.append('wrongfield', new Blob([new Uint8Array(PNG)], { type: 'image/png' }), 'x.png');
    const res = await fetch(`${ctx.base}/api/uploads/image?kind=bird`, { method: 'POST', headers: { Authorization: `Bearer ${ctx.owner}`, 'X-Farm-Id': farmA }, body: form });
    expect(res.status, `wrong field name → ${res.status}`).toBeGreaterThanOrEqual(400);
    expect(res.status).toBeLessThan(500);
  });

  it('cache headers on image read are private', async () => {
    const res = await fetch(`${ctx.base}/api/images/${imgB}`, { headers: { Authorization: `Bearer ${ctx.owner}`, 'X-Farm-Id': farmB } });
    expect(res.status).toBe(200);
    const cc = (res.headers.get('cache-control') || '').toLowerCase();
    expect(cc, `cache-control: ${cc}`).not.toContain('public');
  });

  it('P8-1: flock /api/photos/:id (what the diary UI requests) exists', async () => {
    const res = await fetch(`${ctx.base}/api/photos/${imgB}`, { headers: { Authorization: `Bearer ${ctx.owner}`, 'X-Farm-Id': farmB } });
    expect(res.status, `GET /api/photos/:id → ${res.status} (diary UI builds these URLs)`).toBe(200);
  });
});
