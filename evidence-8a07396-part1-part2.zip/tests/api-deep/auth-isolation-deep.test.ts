/**
 * DEEP round 3 — forged/expired tokens, role matrix, cross-farm
 * isolation on EVERY resource (NO fixes; failures = findings).
 * Tokens are forged with the test JWT secret the harness injects,
 * so attacks are cryptographically valid but semantically wrong:
 * expired, role-escalated, nonexistent user, alg confusion.
 */
import { createHmac } from 'node:crypto';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const SECRET = '[SECURITY_DATA]';
const apps: Record<string, Ctx> = {};

const b64 = (o: any) => Buffer.from(JSON.stringify(o)).toString('base64url');
function forge(payload: any, { alg = 'HS256', secret = SECRET, header = {} as any } = {}): string {
  const h = b64({ alg, typ: 'JWT', ...header });
  const p = b64(payload);
  if (alg === 'none') return `${h}.${p}.`;
  const sig = createHmac('sha256', secret).update(`${h}.${p}`).digest('base64url');
  return `${h}.${p}.${sig}`;
}
// Pick a plausible user-claim shape per app from a real token.
function claimsOf(token: string): any {
  try { return JSON.parse(Buffer.from(token.split('.')[1], 'base64url').toString()); } catch { return {}; }
}

describe.sequential('DEEP: forged tokens + cross-farm isolation', () => {
  beforeAll(async () => {
    apps.dairy = await startApp('dairy', 'dairy_farm/backend');
    apps.flock = await startApp('flock', 'flock_farm/backend');
    apps.agri = await startApp('agri', 'agri_farm/backend');
  }, 180_000);
  afterAll(async () => { for (const c of Object.values(apps)) await stopApp(c); }, 60_000);

  for (const name of ['dairy', 'flock', 'agri']) {
    describe(name, () => {
      it('forged tokens are all rejected (expired, alg-none, wrong secret, role-escalated ghost)', async () => {
        const ctx = apps[name];
        const listRoute = name === 'agri' ? '/crops?limit=5' : name === 'flock' ? '/batches' : '/cows?limit=5';
        const real = claimsOf(ctx.owner);
        const now = Math.floor(Date.now() / 1000);
        const attacks: Array<[string, string]> = [
          ['expired (valid signature)', forge({ ...real, exp: now - 3600 })],
          ['alg none', forge({ ...real, exp: now + 3600 }, { alg: 'none' })],
          ['wrong secret', forge({ ...real, exp: now + 3600 }, { secret: 'definitely-not-the-secret' })],
          ['ghost user, admin role', forge({ ...real, sub: 'ghost-user-000', id: 'ghost-user-000', _id: 'ghost-user-000', userId: 'ghost-user-000', role: 'admin', exp: now + 3600 })],
          ['empty payload', forge({ exp: now + 3600 })],
        ];
        for (const [label, token] of attacks) {
          const r = await raw(ctx, listRoute, { token });
          expect(r.response.status, `${name} forged: ${label}`).toBe(401);
        }
        // garbage formats
        for (const token of ['not-a-token', 'a.b.c', '', 'Bearer']) {
          const res = await fetch(`${ctx.base}/api${listRoute}`, { headers: { Authorization: `Bearer ${token}` } });
          expect([401, 403], `${name} garbage token`).toContain(res.status);
        }
      });

      it('worker token cannot perform owner-only mutations (role matrix spot-check)', async () => {
        const ctx = apps[name];
        const attempts: Array<[string, string, any]> = name === 'dairy'
          ? [['POST', '/cows', { name: `Role Cow ${S}`, breed: 'Jersey' }], ['DELETE', '/cows/whatever', undefined], ['GET', '/backup', undefined], ['POST', '/auth/users', { username: `evil${S}`, password: 'definitely-not-the-secret', role: 'admin' }]]
          : name === 'flock'
            ? [['POST', '/batches', { name: `Role Batch ${S}`, type: 'Broiler', start_date: '2026-09-01', intake_count: 5, cost_per_bird: 10 }], ['GET', '/backup', undefined], ['POST', '/auth/users', { username: `evil${S}`, password: 'definitely-not-the-secret', role: 'admin' }]]
            : [['POST', '/crops', { name: `Role Crop ${S}` }], ['GET', '/backup', undefined], ['GET', '/users', undefined], ['DELETE', '/crops/whatever', undefined]];
        for (const [method, route, body] of attempts) {
          const r = await raw(ctx, route, { method, token: ctx.worker, body });
          expect(r.response.status, `${name} worker ${method} ${route}`).toBe(403);
          if (r.response.status === 201 && body) {
            // clean up anything a too-powerful worker created
            const id = idOf(r.data);
            if (id) await raw(ctx, route.split('/').slice(0, 2).join('/') + `/${id}`, { method: 'DELETE', token: ctx.owner });
          }
        }
      });
    });
  }

  it('JWT_SECRET environment variable must take precedence over backend .env file', async () => {
    // The harness spawns every server with JWT_SECRET=[SECURITY_DATA]
    // A token signed with THAT secret must verify if env config is honored.
    for (const name of ['dairy', 'flock', 'agri']) {
      const ctx = apps[name];
      const listRoute = name === 'agri' ? '/crops?limit=5' : name === 'flock' ? '/batches' : '/cows?limit=5';
      const now = Math.floor(Date.now() / 1000);
      const token = forge({ ...claimsOf(ctx.owner), exp: now + 3600 }, { secret: SECRET });
      const r = await raw(ctx, listRoute, { token });
      expect(r.response.status, `${name}: token signed with env-provided JWT_SECRET`).toBe(200);
    }
  });

  it('cross-farm isolation: farm B cannot read/update/delete farm A records (dairy deep-dive)', async () => {
    const ctx = apps.dairy;
    // second farm for the same owner
    const farmB = await raw(ctx, '/farms', { method: 'POST', token: ctx.owner, body: { name: `Isolation Farm B ${S}` } });
    expect([200, 201]).toContain(farmB.response.status);
    const farmBId = String(farmB.data?.farm?.id || farmB.data?.id || farmB.data?.farm?._id || farmB.data?._id);
    expect(farmBId).toBeTruthy();

    // record in default farm A
    const cow = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { name: `Isolation Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    const cowId = idOf(cow.data);

    // read it scoped to farm B → must be 404 (not leaked)
    const readB = await raw(ctx, `/cows/${cowId}`, { token: ctx.owner, farmId: farmBId });
    expect(readB.response.status, 'cross-farm read').toBe(404);
    // mutate it scoped to farm B
    const updB = await raw(ctx, `/cows/${cowId}`, { method: 'PUT', token: ctx.owner, farmId: farmBId, body: { name: 'Hijacked' } });
    expect([403, 404]).toContain(updB.response.status);
    const delB = await raw(ctx, `/cows/${cowId}`, { method: 'DELETE', token: ctx.owner, farmId: farmBId });
    expect([403, 404]).toContain(delB.response.status);
    // list in farm B must not contain it
    const listB = await raw(ctx, '/cows?limit=500', { token: ctx.owner, farmId: farmBId });
    expect(JSON.stringify(listB.data)).not.toContain(cowId);
    // still intact in farm A
    const readA = await raw(ctx, `/cows/${cowId}`, { token: ctx.owner });
    expect(readA.response.status).toBe(200);
    expect(String(readA.data.name)).toContain('Isolation Cow');
    await raw(ctx, `/cows/${cowId}`, { method: 'DELETE', token: ctx.owner });
  });

  it('cross-farm isolation holds for agri crops and flock batches too', async () => {
    for (const name of ['agri', 'flock'] as const) {
      const ctx = apps[name];
      const farmB = await raw(ctx, '/farms', { method: 'POST', token: ctx.owner, body: { name: `Iso B ${S}` } });
      const farmBId = String(farmB.data?.farm?.id || farmB.data?.id || farmB.data?.farm?._id || farmB.data?._id);
      if (name === 'agri') {
        const crop = await raw(ctx, '/crops', { method: 'POST', token: ctx.owner, body: { name: `Iso Crop ${S}`, status: 'Growing', plant_date: '2026-09-01' } });
        const id = idOf(crop.data);
        const listB = await raw(ctx, '/crops?skip=0&limit=500', { token: ctx.owner, farmId: farmBId });
        expect(JSON.stringify(listB.data), 'agri cross-farm crop list leak').not.toContain(id);
        await raw(ctx, `/crops/${id}`, { method: 'DELETE', token: ctx.owner });
      } else {
        const batch = await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, body: { name: `Iso Batch ${S}`, type: 'Layer', start_date: '2026-09-01', intake_count: 10, cost_per_bird: 50 } });
        const id = String(batch.data.batch.batch_id);
        const readB = await raw(ctx, `/batches/${id}`, { token: ctx.owner, farmId: farmBId });
        expect(readB.response.status, 'flock cross-farm batch read').toBe(404);
        await raw(ctx, `/batches/${id}`, { method: 'DELETE', token: ctx.owner });
      }
    }
  });
});
