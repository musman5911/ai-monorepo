/**
 * ROUND 5 (Tier B) — public surface: share-cards data exposure,
 * Telegram/cron gates, account enumeration, security headers,
 * CORS reflection, cache control. NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const apps: Record<string, Ctx> = {};
const LIST: Record<string, string> = { dairy: '/cows?limit=3', flock: '/batches', agri: '/crops?limit=3' };

describe.sequential('ROUND 5: public surface + headers', () => {
  beforeAll(async () => {
    apps.dairy = await startApp('dairy', 'dairy_farm/backend');
    apps.flock = await startApp('flock', 'flock_farm/backend');
    apps.agri = await startApp('agri', 'agri_farm/backend');
  }, 180_000);
  afterAll(async () => { for (const c of Object.values(apps)) await stopApp(c); }, 60_000);

  it('dairy public buyer card does not expose phone number to unauthenticated visitors', async () => {
    const ctx = apps.dairy;
    const phone = '0300-7654321';
    const buyer = await raw(ctx, '/buyers', { method: 'POST', token: ctx.owner, body: { name: `Card Buyer ${S}`, phone } });
    const id = idOf(buyer.data);
    expect(id).toBeTruthy();
    const res = await fetch(`${ctx.base}/api/cards/buyer/${id}`);
    expect(res.status).toBe(200);
    const html = await res.text();
    expect(html, 'public card leaks buyer phone number').not.toContain('0300-7654321');
    for (const guess of ['1', '000000000000000000000001', 'admin']) {
      const g = await fetch(`${ctx.base}/api/cards/buyer/${guess}`);
      expect(g.status, `card guess ${guess}`).toBe(404);
    }
    await raw(ctx, `/buyers/${id}`, { method: 'DELETE', token: ctx.owner });
  });

  it('telegram webhooks never 500 on wrong secrets; cron endpoints reject missing keys (all apps)', async () => {
    for (const name of ['dairy', 'flock', 'agri'] as const) {
      const ctx = apps[name];
      const hook = await fetch(`${ctx.base}/api/telegram/webhook/definitely-wrong-secret`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: { chat: { id: 1 }, text: '/start' } }),
      });
      // 200 empty-ack is acceptable (Telegram convention; secret is
      // verified before any processing — checked in route source).
      expect([200, 401, 403, 404, 503], `${name} webhook wrong secret → ${hook.status}`).toContain(hook.status);
    }
    const dCron = await fetch(`${apps.dairy.base}/api/telegram/cron`);
    expect([401, 503]).toContain(dCron.status);
    const fCron = await fetch(`${apps.flock.base}/api/cron/daily-summary`);
    expect([401, 503]).toContain(fCron.status);
  });

  it('no account enumeration via login errors or forgot-password (all apps)', async () => {
    for (const name of ['dairy', 'flock', 'agri'] as const) {
      const ctx = apps[name];
      const login = (u: string, p: string) => name === 'agri'
        ? raw(ctx, '/login', { method: 'POST', form: { username: u, password: p } })
        : raw(ctx, '/auth/login', { method: 'POST', body: { username: u, password: p } });
      const ghost = await login(`no-such-user-${S}`, 'Whatever123!');
      const real = await login('admin', 'WrongPass123!');
      expect(real.response.status, `${name} wrong-password status`).toBe(ghost.response.status);
      expect(JSON.stringify(real.data), `${name} login errors differ (user enumeration)`).toBe(JSON.stringify(ghost.data));

      const fpRoute = name === 'agri' ? '/forgot-password' : '/auth/forgot-password';
      const fpGhost = await raw(ctx, fpRoute, { method: 'POST', body: { email: `ghost-${S}@example.com` } });
      const fpReal = await raw(ctx, fpRoute, { method: 'POST', body: { email: 'admin@example.com' } });
      expect(fpReal.response.status, `${name} forgot-password status differs`).toBe(fpGhost.response.status);
      expect(JSON.stringify(fpReal.data), `${name} forgot-password body differs`).toBe(JSON.stringify(fpGhost.data));
    }
  });

  for (const name of ['dairy', 'flock', 'agri'] as const) {
    it(`${name}: API responses carry CSP + nosniff + frame protection`, async () => {
      const ctx = apps[name];
      const res = await fetch(`${ctx.base}/api${LIST[name]}`, { headers: { Authorization: `Bearer ${ctx.owner}` } });
      expect(res.status).toBe(200);
      const h = res.headers;
      expect(h.get('content-security-policy'), `${name} missing Content-Security-Policy`).toBeTruthy();
      expect((h.get('x-content-type-options') || '').toLowerCase(), `${name} missing X-Content-Type-Options`).toBe('nosniff');
      const frame = h.get('x-frame-options') || h.get('content-security-policy') || '';
      expect(frame.toUpperCase(), `${name} no frame protection`).toMatch(/DENY|SAMEORIGIN|FRAME-ANCESTORS/);
    });

    it(`${name}: CORS does not reflect arbitrary origins with credentials`, async () => {
      const ctx = apps[name];
      const res = await fetch(`${ctx.base}/api${LIST[name]}`, {
        method: 'OPTIONS',
        headers: { Origin: 'https://evil.example', 'Access-Control-Request-Method': 'GET', 'Access-Control-Request-Headers': 'authorization' },
      });
      const acao = res.headers.get('access-control-allow-origin');
      const acc = res.headers.get('access-control-allow-credentials');
      expect(!(acao === 'https://evil.example' && acc === 'true'), `${name} preflight reflects evil origin WITH credentials`).toBe(true);
      const get = await fetch(`${ctx.base}/api${LIST[name]}`, { headers: { Authorization: `Bearer ${ctx.owner}`, Origin: 'https://evil.example' } });
      const gAcao = get.headers.get('access-control-allow-origin');
      const gAcc = get.headers.get('access-control-allow-credentials');
      expect(!(gAcao === 'https://evil.example' && gAcc === 'true'), `${name} GET reflects evil origin WITH credentials`).toBe(true);
    });

    it(`${name}: authenticated responses are marked non-cacheable`, async () => {
      const ctx = apps[name];
      const res = await fetch(`${ctx.base}/api${LIST[name]}`, { headers: { Authorization: `Bearer ${ctx.owner}` } });
      const cc = (res.headers.get('cache-control') || '').toLowerCase();
      expect(cc, `${name} sensitive API response cacheable: "${cc}"`).toMatch(/no-store|no-cache|private/);
    });
  }
});
