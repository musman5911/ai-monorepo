/**
 * ROUND 16 — Agri's NEW server-side filter engine (crops/finance/
 * tasks filters shipped in the latest tree changes): correctness,
 * worker-visibility interplay, injection, total-count headers.
 * NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, rowsOf, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

let ctx: Ctx;
const made: string[] = [];

async function mkCrop(body: any) {
  const r = await raw(ctx, '/crops', { method: 'POST', token: ctx.owner, body });
  expect([200, 201]).toContain(r.response.status);
  const id = idOf(r.data);
  made.push(id);
  return id;
}
async function list(route: string, token?: string) {
  const r = await raw(ctx, route, { token: token || ctx.owner });
  expect(r.response.status, `GET ${route}`).toBe(200);
  return r;
}

describe.sequential('ROUND 16: agri filter engine', () => {
  beforeAll(async () => { ctx = await startApp('agri', 'agri_farm/backend'); }, 120_000);
  afterAll(async () => {
    for (const id of made) await raw(ctx, `/crops/${id}`, { method: 'DELETE', token: ctx.owner });
    await stopApp(ctx);
  }, 60_000);

  it('crop filters match exactly (status / season / field / combined / all)', async () => {
    const a = await mkCrop({ name: `FiltA ${S}`, status: 'Growing', season: 'Kharif', field: `North ${S}`, plant_date: '2026-09-01' });
    await mkCrop({ name: `FiltB ${S}`, status: 'Harvested', season: 'Rabi', field: `South ${S}`, plant_date: '2026-09-01' });

    const byStatus = rowsOf((await list(`/crops?status=Growing&search=Filt${''}`)).data);
    expect(rowsOf((await list('/crops?status=Growing&limit=500')).data).some((c: any) => String(c._id || c.id) === a)).toBe(true);
    const harvested = rowsOf((await list('/crops?status=Growing&limit=500')).data);
    expect(harvested.some((c: any) => (c.name || '') === `FiltB ${S}`), 'status=Growing leaked a Harvested crop').toBe(false);

    const bySeason = rowsOf((await list('/crops?season=Rabi&limit=500')).data);
    expect(bySeason.some((c: any) => (c.name || '') === `FiltB ${S}`)).toBe(true);
    expect(bySeason.some((c: any) => (c.name || '') === `FiltA ${S}`), 'season=Rabi leaked Kharif crop').toBe(false);

    const combined = rowsOf((await list('/crops?status=Growing&season=Rabi&limit=500')).data);
    expect(combined.some((c: any) => String(c.name || '').startsWith('Filt')), 'contradictory filters returned rows').toBe(false);

    const all = rowsOf((await list('/crops?status=all&limit=500')).data);
    expect(all.some((c: any) => (c.name || '') === `FiltA ${S}`)).toBe(true);
    expect(all.some((c: any) => (c.name || '') === `FiltB ${S}`)).toBe(true);
    expect(byStatus).toBeDefined();
  });

  it('crop search is partial + case-insensitive and regex-safe', async () => {
    const hits = rowsOf((await list(`/crops?search=filtb&limit=500`)).data);
    expect(hits.some((c: any) => (c.name || '') === `FiltB ${S}`), 'lowercase partial search missed').toBe(true);
    const dotStar = rowsOf((await list('/crops?search=.*&limit=500')).data);
    expect(dotStar.filter((c: any) => String(c.name || '').startsWith('Filt')).length, 'search ".*" acted as regex').toBe(0);
    const byField = rowsOf((await list(`/crops?search=north&limit=500`)).data);
    expect(byField.some((c: any) => (c.name || '') === `FiltA ${S}`), 'search did not match field').toBe(true);
  });

  it('crop_id filter validates format and matches exactly', async () => {
    const bad = await raw(ctx, '/crops?crop_id=not-an-id', { token: ctx.owner });
    expect(bad.response.status, 'malformed crop_id accepted').toBe(400);
    const ghost = await list('/crops?crop_id=507f1f77bcf86cd799439011&limit=10');
    expect(rowsOf(ghost.data).length).toBe(0);
    const mine = rowsOf((await list(`/crops?crop_id=${made[0]}&limit=10`)).data);
    expect(mine.length).toBe(1);
    expect(String(mine[0]._id || mine[0].id)).toBe(made[0]);
  });

  it('worker cannot filter their way into Completed crops', async () => {
    const done = await mkCrop({ name: `FiltDone ${S}`, status: 'Completed', plant_date: '2026-09-01' });
    const wAll = rowsOf((await list('/crops?limit=500', ctx.worker)).data);
    expect(wAll.some((c: any) => String(c._id || c.id) === done), 'worker list contains Completed crop').toBe(false);
    const wFiltered = rowsOf((await list('/crops?status=Completed&limit=500', ctx.worker)).data);
    expect(wFiltered.some((c: any) => String(c._id || c.id) === done), 'worker used status=Completed to reach hidden crops').toBe(false);
    const wSearch = rowsOf((await list(`/crops?search=FiltDone&limit=500`, ctx.worker)).data);
    expect(wSearch.some((c: any) => String(c._id || c.id) === done), 'worker search reached Completed crop').toBe(false);
  });

  it('filter injection shapes never 500 and never widen results', async () => {
    const attacks = [
      '/crops?status[$ne]=Completed', '/crops?status[]=Growing', '/crops?search[$regex]=.*',
      '/crops?crop_id[$gt]=', '/finance?type[$ne]=expense', '/finance?search[$gt]=',
      '/tasks?status[$ne]=Done', '/crops?season=Kharif&season=Rabi',
    ];
    for (const route of attacks) {
      const r = await raw(ctx, route, { token: ctx.owner });
      expect(r.response.status, `GET ${route}`).toBeLessThan(500);
    }
    const neProbe = rowsOf((await raw(ctx, '/crops?status[$ne]=Growing&limit=500', { token: ctx.owner })).data);
    // if the object filter were honored as $ne, FiltA (Growing) would vanish; string filters ignore objects
    expect(neProbe.some((c: any) => (c.name || '') === `FiltA ${S}`), 'object-style status filter was honored (injection)').toBe(true);
  });

  it('finance filters: type validation, income/expense split, total-count header is the FILTERED total', async () => {
    const inc = await raw(ctx, '/finance', { method: 'POST', token: ctx.owner, body: { type: 'income', category: `FiltInc ${S}`, amount: 111, date: '2026-09-05' } });
    expect([200, 201]).toContain(inc.response.status);
    const exp = await raw(ctx, '/finance', { method: 'POST', token: ctx.owner, body: { type: 'expense', category: `FiltExp ${S}`, amount: 222, date: '2026-09-05' } });
    expect([200, 201]).toContain(exp.response.status);

    const badType = await raw(ctx, '/finance?type=banana', { token: ctx.owner });
    expect(badType.response.status).toBe(400);
    const onlyInc = await list('/finance?type=income&limit=500');
    const incRows = rowsOf(onlyInc.data);
    expect(incRows.some((f: any) => f.category === `FiltInc ${S}`)).toBe(true);
    expect(incRows.some((f: any) => f.category === `FiltExp ${S}`), 'type=income leaked an expense').toBe(false);
    // header must agree with the filtered row count for a unique search
    const searched = await list(`/finance?search=FiltInc ${S}&limit=500`);
    const totalHeader = searched.response.headers.get('x-total-count');
    if (totalHeader !== null) {
      expect(Number(totalHeader), 'X-Total-Count disagrees with filtered rows').toBe(rowsOf(searched.data).length);
    }
    for (const f of rowsOf((await list('/finance?limit=500')).data).filter((x: any) => String(x.category || '').startsWith('Filt'))) {
      await raw(ctx, `/finance/${f._id || f.id}`, { method: 'DELETE', token: ctx.owner });
    }
  });

  it('tasks filters respond sanely (status filter + bad values)', async () => {
    const t = await raw(ctx, '/tasks', { method: 'POST', token: ctx.owner, body: { title: `FiltTask ${S}`, status: 'Pending', priority: 'High' } });
    expect([200, 201]).toContain(t.response.status);
    const pending = rowsOf((await list('/tasks?status=Pending&limit=500')).data);
    expect(pending.some((x: any) => (x.title || '') === `FiltTask ${S}`)).toBe(true);
    const done = rowsOf((await list('/tasks?status=Completed&limit=500')).data);
    expect(done.some((x: any) => (x.title || '') === `FiltTask ${S}`), 'status=Completed leaked a Pending task').toBe(false);
    const rows = rowsOf((await list('/tasks?limit=500')).data);
    const mine = rows.find((x: any) => (x.title || '') === `FiltTask ${S}`);
    if (mine) await raw(ctx, `/tasks/${mine._id || mine.id}`, { method: 'DELETE', token: ctx.owner });
  });
});
