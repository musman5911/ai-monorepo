/**
 * ROUND 22 (revised to real schemas) — Agri liabilities +
 * inventory money rules. /pay settles the FULL amount_owed
 * (body amount is ignored by design); probes: negative
 * amount_owed via create/update, negative inventory qty,
 * double-pay finance duplication, worker access.
 * NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

describe.sequential('ROUND 22: agri liabilities + inventory', () => {
  let ctx: Ctx;
  beforeAll(async () => { ctx = await startApp('agri', 'agri_farm/backend'); }, 120_000);
  afterAll(async () => { await stopApp(ctx); }, 60_000);

  const findRow = (data: any, id: string) => (Array.isArray(data) ? data : []).find((r: any) => String(r._id) === id);

  it('pay settles in full exactly once (no duplicate finance expense on double-pay)', async () => {
    const c = await raw(ctx, '/liabilities', { method: 'POST', token: ctx.owner, body: { creditor: `R22 Creditor ${S}`, amount_owed: 4321, due_date: '2026-12-01' } });
    expect(c.response.status, `create → ${c.response.status} ${JSON.stringify(c.data).slice(0, 140)}`).toBe(201);
    const id = idOf(c.data);
    expect(id).toBeTruthy();
    const pay1 = await raw(ctx, `/liabilities/${id}/pay`, { method: 'PUT', token: ctx.owner, body: {} });
    expect(pay1.response.status).toBeLessThan(300);
    const pay2 = await raw(ctx, `/liabilities/${id}/pay`, { method: 'PUT', token: ctx.owner, body: {} });
    expect(pay2.response.status).toBeLessThan(300);
    const fin = await raw(ctx, '/finance?limit=100', { token: ctx.owner });
    const rows = Array.isArray(fin.data) ? fin.data : (fin.data?.items || fin.data?.rows || []);
    const hits = rows.filter((r: any) => JSON.stringify(r).includes(`R22 Creditor ${S}`)).length;
    expect(hits, `settlement finance expense rows written ${hits}x for one liability`).toBe(1);
    const list = await raw(ctx, '/liabilities', { token: ctx.owner });
    expect(findRow(list.data, id)?.status, 'liability not marked Paid').toBe('Paid');
  });

  it('negative amount_owed cannot be created or set via update', async () => {
    const c = await raw(ctx, '/liabilities', { method: 'POST', token: ctx.owner, body: { creditor: `R22 Neg ${S}`, amount_owed: -777, due_date: '' } });
    if (c.response.status === 201) {
      const id = idOf(c.data);
      const list = await raw(ctx, '/liabilities', { token: ctx.owner });
      expect(Number(findRow(list.data, id)?.amount_owed), 'negative liability persisted on create').toBeGreaterThanOrEqual(0);
    } else {
      expect([400, 422]).toContain(c.response.status);
    }
    const ok = await raw(ctx, '/liabilities', { method: 'POST', token: ctx.owner, body: { creditor: `R22 Upd ${S}`, amount_owed: 500, due_date: '' } });
    const okId = idOf(ok.data);
    const upd = await raw(ctx, `/liabilities/${okId}`, { method: 'PUT', token: ctx.owner, body: { creditor: `R22 Upd ${S}`, amount_owed: -500, due_date: '', notes: '' } });
    expect([200, 400, 422], `negative update → ${upd.response.status}`).toContain(upd.response.status);
    const list2 = await raw(ctx, '/liabilities', { token: ctx.owner });
    expect(Number(findRow(list2.data, okId)?.amount_owed), 'negative liability persisted via update').toBeGreaterThanOrEqual(0);
  });

  it('inventory: negative quantity via update is rejected; worker blocked everywhere', async () => {
    const c = await raw(ctx, '/inventory', { method: 'POST', token: ctx.owner, body: { name: `R22 Feed ${S}`, quantity: 10, unit: 'bags' } });
    expect(c.response.status, `create → ${c.response.status} ${JSON.stringify(c.data).slice(0, 120)}`).toBe(201);
    const itemId = idOf(c.data);
    const neg = await raw(ctx, `/inventory/${itemId}`, { method: 'PUT', token: ctx.owner, body: { quantity: -50 } });
    expect([200, 400, 422], `negative update → ${neg.response.status}`).toContain(neg.response.status);
    const after = await raw(ctx, '/inventory', { token: ctx.owner });
    expect(Number(findRow(after.data, itemId)?.quantity), 'negative inventory quantity persisted').toBeGreaterThanOrEqual(0);
    const w = await raw(ctx, '/inventory', { method: 'POST', token: ctx.worker, body: { name: 'x', quantity: 1 } });
    expect([401, 403], `worker inventory create → ${w.response.status}`).toContain(w.response.status);
    const wl = await raw(ctx, '/liabilities', { token: ctx.worker });
    expect([401, 403], `worker liabilities → ${wl.response.status}`).toContain(wl.response.status);
  });
});
