/**
 * ROUND 23 — Q1 pinpoint: every Dairy DELETE route in
 * memory/demo mode, one assertion per route; plus Flock
 * import-all cross-farm scoping. NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, rowsOf, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

describe.sequential('ROUND 23: Q1 DELETE pinpoint + flock import scoping', () => {
  let dairy: Ctx; let flock: Ctx;
  beforeAll(async () => {
    dairy = await startApp('dairy', 'dairy_farm/backend');
    flock = await startApp('flock', 'flock_farm/backend');
  }, 180_000);
  afterAll(async () => { await stopApp(dairy); await stopApp(flock); }, 60_000);

  it('dairy DELETE /health/:id works in memory mode (no 500)', async () => {
    const cow = await raw(dairy, '/cows', { method: 'POST', token: dairy.owner, body: { name: `Q1 Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    const cowId = idOf(cow.data);
    const h = await raw(dairy, '/health', { method: 'POST', token: dairy.owner, body: { cowId, type: 'checkup', date: '2026-10-01', description: `Q1 ${S}` } });
    const hid = idOf(h.data);
    expect(hid, `health create → ${h.response.status} ${JSON.stringify(h.data).slice(0, 100)}`).toBeTruthy();
    const del = await raw(dairy, `/health/${hid}`, { method: 'DELETE', token: dairy.owner });
    expect(del.response.status, `DELETE /health → ${del.response.status}`).toBeLessThan(300);
  });

  it('dairy DELETE /buyers/:id works in memory mode (no 500)', async () => {
    const b = await raw(dairy, '/buyers', { method: 'POST', token: dairy.owner, body: { name: `Q1 Buyer ${S}`, phone: '0300-9998877' } });
    const bid = idOf(b.data);
    expect(bid, `buyer create → ${b.response.status}`).toBeTruthy();
    const del = await raw(dairy, `/buyers/${bid}`, { method: 'DELETE', token: dairy.owner });
    expect(del.response.status, `DELETE /buyers → ${del.response.status}`).toBeLessThan(300);
  });

  it('dairy DELETE /suppliers/:id works in memory mode (no 500)', async () => {
    const s = await raw(dairy, '/suppliers', { method: 'POST', token: dairy.owner, body: { name: `Q1 Supplier ${S}`, phone: '0300-9998876' } });
    const sid = idOf(s.data);
    expect(sid, `supplier create → ${s.response.status}`).toBeTruthy();
    const del = await raw(dairy, `/suppliers/${sid}`, { method: 'DELETE', token: dairy.owner });
    expect(del.response.status, `DELETE /suppliers → ${del.response.status}`).toBeLessThan(300);
  });

  it('dairy DELETE /labor/:id works in memory mode (no 500)', async () => {
    const l = await raw(dairy, '/labor/workers', { method: 'POST', token: dairy.owner, body: { name: `Q1 Labor ${S}`, dailyWage: 1500 } });
    const lid = idOf(l.data);
    expect(lid, `labor create → ${l.response.status} ${JSON.stringify(l.data).slice(0, 100)}`).toBeTruthy();
    const del = await raw(dairy, `/labor/workers/${lid}`, { method: 'DELETE', token: dairy.owner });
    expect(del.response.status, `DELETE /labor → ${del.response.status}`).toBeLessThan(300);
  });

  it('dairy DELETE /milk/:id works in memory mode (no 500)', async () => {
    const cow = await raw(dairy, '/cows', { method: 'POST', token: dairy.owner, body: { name: `Q1 MilkCow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    const cowId = idOf(cow.data);
    const m = await raw(dairy, '/milk', { method: 'POST', token: dairy.owner, body: { cowId, date: '2026-10-04', quantity: 9, session: 'morning' } });
    const mid = idOf(m.data);
    expect(mid, `milk create → ${m.response.status} ${JSON.stringify(m.data).slice(0, 100)}`).toBeTruthy();
    const del = await raw(dairy, `/milk/${mid}`, { method: 'DELETE', token: dairy.owner });
    expect(del.response.status, `DELETE /milk → ${del.response.status}`).toBeLessThan(300);
  });

  it('flock import-all into farm B does not leak into farm A', async () => {
    const mkFarm = async () => {
      const r = await raw(flock, '/farms', { method: 'POST', token: flock.owner, body: { name: `R23 Farm ${S}-${Math.random().toString(36).slice(2, 8)}` } });
      expect([200, 201]).toContain(r.response.status);
      return String(r.data?.farm?.id || r.data?.id || r.data?.farm?._id || r.data?._id);
    };
    const farmB = await mkFarm();
    const b = await raw(flock, '/batches', { method: 'POST', token: flock.owner, body: { name: `R23 Batch ${S}`, type: 'Broiler', start_date: '2026-09-01', intake_count: 10, cost_per_bird: 5 } });
    expect(b.response.status).toBe(201);
    const exp = await raw(flock, '/batches/export-all', { token: flock.owner });
    expect(exp.response.status).toBe(200);
    const bOwn = await raw(flock, '/batches', { method: 'POST', token: flock.owner, farmId: farmB, body: { name: `R23 BOwn ${S}`, type: 'Layer', start_date: '2026-09-02', intake_count: 7, cost_per_bird: 5 } });
    expect(bOwn.response.status, `farm B own batch → ${bOwn.response.status}`).toBe(201);
    const impB = await raw(flock, '/batches/import-all', { method: 'POST', token: flock.owner, farmId: farmB, body: exp.data });
    expect(impB.response.status, `import into B → ${impB.response.status}`).toBeLessThan(300);
    const listB0 = await raw(flock, '/batches', { token: flock.owner, farmId: farmB });
    expect(JSON.stringify(listB0.data), 'farm B own batch was destroyed by the import').toContain(`R23 BOwn ${S}`);
    const listA = await raw(flock, '/batches', { token: flock.owner });
    const countA = rowsOf(listA.data).filter((r: any) => JSON.stringify(r).includes(`R23 Batch ${S}`)).length;
    expect(countA, `batch duplicated into farm A listing (${countA}x)`).toBe(1);
    const listAll = await raw(flock, '/batches', { token: flock.owner, farmId: 'all' });
    const countAll = rowsOf(listAll.data).filter((r: any) => JSON.stringify(r).includes(`R23 Batch ${S}`)).length;
    expect(countAll, 'expected original + farm-B import in all-farms view').toBe(2);
  });
});
