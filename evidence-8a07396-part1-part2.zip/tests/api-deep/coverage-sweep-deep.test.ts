/**
 * ROUND 11 (new sweep) — endpoint-coverage of route files the
 * matrix never touched: breeding, dailylog, feedstock, rates,
 * settings (public GPS!), sales lifecycle, email cron; flock
 * settings contrast. NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const apps: Record<string, Ctx> = {};

describe.sequential('ROUND 11: coverage sweep', () => {
  beforeAll(async () => {
    apps.dairy = await startApp('dairy', 'dairy_farm/backend');
    apps.flock = await startApp('flock', 'flock_farm/backend');
    apps.agri = await startApp('agri', 'agri_farm/backend');
  }, 180_000);
  afterAll(async () => { for (const c of Object.values(apps)) await stopApp(c); }, 60_000);

  it('dairy farm GPS location is not public (flock requires auth for the same data)', async () => {
    const ctx = apps.dairy;
    const put = await raw(ctx, '/settings/location', { method: 'PUT', token: ctx.owner, body: { lat: 31.5204, lon: 74.3587, city: `Probe City ${S}`, raw_dms: '' } });
    expect([200, 201]).toContain(put.response.status);
    const pub = await fetch(`${ctx.base}/api/settings/location`);
    expect(pub.status, 'farm location served without login').toBe(401);
    const fPub = await fetch(`${apps.flock.base}/api/settings/location`);
    expect(fPub.status).toBe(401);
  });

  it('dairy uncovered GET endpoints: owner 200, anonymous 401, no 500s', async () => {
    const ctx = apps.dairy;
    const routes = ['/breeding', '/dailylog/entries', '/dailylog/2026-09-01', '/feedstock/settings', '/rates', '/rates/1', '/rates/history', '/sales', '/email/status'];
    for (const route of routes) {
      const owner = await raw(ctx, route, { token: ctx.owner });
      expect(owner.response.status, `owner GET ${route}`).toBe(200);
      const anon = await raw(ctx, route, {});
      expect(anon.response.status, `anon GET ${route}`).toBe(401);
    }
  });

  it('dairy sales lifecycle: sale marks cow sold, duplicate blocked, delete restores status', async () => {
    const ctx = apps.dairy;
    const cow = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { name: `Sale Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    const cowId = idOf(cow.data);
    const ghost = await raw(ctx, '/sales', { method: 'POST', token: ctx.owner, body: { cowId: 'no-such-cow', date: '2026-09-22', salePrice: 1000 } });
    expect(ghost.response.status, 'sale for nonexistent cow').toBe(404);
    const sale = await raw(ctx, '/sales', { method: 'POST', token: ctx.owner, body: { cowId, date: '2026-09-22', salePrice: 250000, buyer: `Buyer ${S}` } });
    expect(sale.response.status).toBe(201);
    const saleId = idOf(sale.data);
    const after = await raw(ctx, `/cows/${cowId}`, { token: ctx.owner });
    expect(after.data.status, 'cow not marked sold').toBe('sold');
    const dup = await raw(ctx, '/sales', { method: 'POST', token: ctx.owner, body: { cowId, date: '2026-09-23', salePrice: 1 } });
    expect([400, 409]).toContain(dup.response.status);
    const workerSale = await raw(ctx, '/sales', { method: 'POST', token: ctx.worker, body: { cowId, date: '2026-09-23', salePrice: 1 } });
    expect(workerSale.response.status, 'worker created a sale').toBe(403);
    const del = await raw(ctx, `/sales/${saleId}`, { method: 'DELETE', token: ctx.owner });
    expect([200, 204]).toContain(del.response.status);
    const restored = await raw(ctx, `/cows/${cowId}`, { token: ctx.owner });
    expect(restored.data.status, 'cow still "sold" after sale deleted (orphaned status)').toBe('active');
    await raw(ctx, `/cows/${cowId}`, { method: 'DELETE', token: ctx.owner });
  });

  it('dairy rates: worker cannot change the milk rate; owner change is recorded in history', async () => {
    const ctx = apps.dairy;
    const before = await raw(ctx, '/rates/history', { token: ctx.owner });
    const beforeCount = JSON.stringify(before.data).length;
    const worker = await raw(ctx, '/rates/1', { method: 'PUT', token: ctx.worker, body: { value: 260 } });
    expect(worker.response.status).toBe(403);
    const owner = await raw(ctx, '/rates/1', { method: 'PUT', token: ctx.owner, body: { value: 261 } });
    expect([200, 201]).toContain(owner.response.status);
    const now = await raw(ctx, '/rates/1', { token: ctx.owner });
    expect(Number((now.data as any).value)).toBe(261);
    const neg = await raw(ctx, '/rates/1', { method: 'PUT', token: ctx.owner, body: { value: -5 } });
    expect(neg.response.status, 'negative milk rate accepted').toBeGreaterThanOrEqual(400);
    const after = await raw(ctx, '/rates/history', { token: ctx.owner });
    expect(JSON.stringify(after.data).length).toBeGreaterThanOrEqual(beforeCount);
  });

  it('dairy dailylog: write/read round-trip; garbage dates are 4xx not 500', async () => {
    const ctx = apps.dairy;
    const put = await raw(ctx, '/dailylog/2026-09-24', { method: 'PUT', token: ctx.owner, body: { notes: `Sweep note ${S}` } });
    expect([200, 201]).toContain(put.response.status);
    const got = await raw(ctx, '/dailylog/2026-09-24', { token: ctx.owner });
    expect(JSON.stringify(got.data)).toContain(`Sweep note ${S}`);
    for (const bad of ['not-a-date', '2026-13-40', '..%2f..', '2026-02-30']) {
      const r = await raw(ctx, `/dailylog/${bad}`, { token: ctx.owner });
      expect(r.response.status, `dailylog GET ${bad}`).toBeLessThan(500);
      const w = await raw(ctx, `/dailylog/${bad}`, { method: 'PUT', token: ctx.owner, body: { notes: 'x' } });
      expect(w.response.status, `dailylog PUT ${bad} must reject`).toBeGreaterThanOrEqual(400);
      expect(w.response.status).toBeLessThan(500);
    }
  });

  it('dairy feedstock: worker read-only; negative use is clamped/rejected', async () => {
    const ctx = apps.dairy;
    const worker = await raw(ctx, '/feedstock/settings', { method: 'PUT', token: ctx.worker, body: { dailyUseKg: 10, lowStockDays: 5 } });
    expect(worker.response.status).toBe(403);
    const owner = await raw(ctx, '/feedstock/settings', { method: 'PUT', token: ctx.owner, body: { dailyUseKg: -50, lowStockDays: 5 } });
    expect([200, 201]).toContain(owner.response.status);
    const got = await raw(ctx, '/feedstock/settings', { token: ctx.owner });
    expect(Number((got.data as any).dailyUseKg), 'negative feed use stored').toBeGreaterThanOrEqual(0);
    await raw(ctx, '/feedstock/settings', { method: 'PUT', token: ctx.owner, body: { dailyUseKg: 20, lowStockDays: 14 } });
  });

  it('dairy email cron refuses unauthenticated triggers', async () => {
    const ctx = apps.dairy;
    const r = await fetch(`${ctx.base}/api/email/cron`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
    expect([401, 403, 503]).toContain(r.status);
    const sendWorker = await raw(ctx, '/email/send-now', { method: 'POST', token: ctx.worker, body: {} });
    expect([401, 403]).toContain(sendWorker.response.status);
  });
});
