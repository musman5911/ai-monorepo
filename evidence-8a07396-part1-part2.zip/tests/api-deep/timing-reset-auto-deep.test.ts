/**
 * ROUND 7 (Tier C) — login timing side-channel, reset-code
 * brute-force throttling, auto-backup/restore-auto abuse,
 * session-cookie attributes. NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { raw, rowsOf, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const apps: Record<string, Ctx> = {};
const LIST: Record<string, string> = { dairy: '/cows?limit=3', flock: '/batches', agri: '/crops?limit=3' };

async function timedLogin(name: string, ctx: Ctx, u: string, p: string) {
  const start = performance.now();
  if (name === 'agri') await raw(ctx, '/login', { method: 'POST', form: { username: u, password: p } });
  else await raw(ctx, '/auth/login', { method: 'POST', body: { username: u, password: p } });
  return performance.now() - start;
}
const median = (xs: number[]) => xs.slice().sort((a, b) => a - b)[Math.floor(xs.length / 2)];

describe.sequential('ROUND 7: timing, reset, auto-backup, cookies', () => {
  beforeAll(async () => {
    apps.dairy = await startApp('dairy', 'dairy_farm/backend');
    apps.flock = await startApp('flock', 'flock_farm/backend');
    apps.agri = await startApp('agri', 'agri_farm/backend');
  }, 180_000);
  afterAll(async () => { for (const c of Object.values(apps)) await stopApp(c); }, 60_000);

  for (const name of ['dairy', 'flock', 'agri'] as const) {
    it(`${name}: login timing does not reveal whether the username exists`, async () => {
      const ctx = apps[name];
      for (let i = 0; i < 3; i++) { await timedLogin(name, ctx, `ghost-${S}`, 'x'); await timedLogin(name, ctx, 'admin', 'x'); }
      const ghost: number[] = []; const real: number[] = [];
      for (let i = 0; i < 11; i++) {
        ghost.push(await timedLogin(name, ctx, `ghost-${S}-${i}`, 'WrongPass123!'));
        real.push(await timedLogin(name, ctx, 'admin', 'WrongPass123!'));
      }
      const g = median(ghost); const r = median(real);
      expect(r - g, `${name} real-user logins are ${Math.round(r - g)}ms slower (timing oracle: real≈${Math.round(r)}ms ghost≈${Math.round(g)}ms)`).toBeLessThan(120);
    }, 120_000);

    it(`${name}: session cookie (if issued) is HttpOnly + SameSite`, async () => {
      const ctx = apps[name];
      const res = name === 'agri'
        ? await fetch(`${ctx.base}/api/login`, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ username: 'admin', password: 'admin123' }) })
        : await fetch(`${ctx.base}/api/auth/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'admin', password: 'admin123' }) });
      expect(res.status).toBe(200);
      const cookies = typeof (res.headers as any).getSetCookie === 'function' ? (res.headers as any).getSetCookie() : [res.headers.get('set-cookie') || ''];
      for (const c of cookies.filter(Boolean)) {
        expect(c.toLowerCase(), `${name} cookie missing HttpOnly: ${c}`).toContain('httponly');
        expect(c.toLowerCase(), `${name} cookie missing SameSite: ${c}`).toContain('samesite');
      }
    });
  }

  it('reset-code guessing is throttled (429) within 30 attempts — dairy + flock + agri', async () => {
    const targets: Array<[string, string]> = [
      ['dairy', '/auth/reset-password'],
      ['flock', '/auth/reset-password'],
      ['agri', '/reset-password'],
    ];
    for (const [name, route] of targets) {
      const ctx = apps[name];
      let saw429 = false; let saw200 = false;
      for (let i = 0; i < 30 && !saw429; i++) {
        const r = await raw(ctx, route, { method: 'POST', body: { email: 'admin@example.com', code: String(100000 + i), newPassword: '[SECURITY_DATA]', password: '[SECURITY_DATA]' } });
        if (r.response.status === 429) saw429 = true;
        if (r.response.status === 200) saw200 = true;
        expect(r.response.status, `${name} reset attempt ${i}`).toBeLessThan(500);
      }
      expect(saw200, `${name} reset succeeded with a guessed code`).toBe(false);
      expect(saw429, `${name}: no throttling after 30 reset-code guesses`).toBe(true);
    }
  }, 120_000);

  it('restore-auto never reports fake success; workers are blocked', async () => {
    const routes: Record<string, string> = { dairy: '/backup/restore-auto', flock: '/backup/restore-auto', agri: '/restore/auto' };
    const creates: Record<string, [string, any, string]> = {
      dairy: ['/cows', { name: `RA Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' }, '/cows?limit=500'],
      flock: ['/batches', { name: `RA Batch ${S}`, type: 'Broiler', start_date: '2026-09-01', intake_count: 5, cost_per_bird: 10 }, '/batches'],
      agri: ['/crops', { name: `RA Crop ${S}`, status: 'Growing', plant_date: '2026-09-01' }, '/crops?skip=0&limit=500'],
    };
    for (const name of ['dairy', 'flock', 'agri'] as const) {
      const ctx = apps[name];
      const workerTry = await raw(ctx, routes[name], { method: 'POST', token: ctx.worker, body: {} });
      expect([401, 403], `${name} worker restore-auto → ${workerTry.response.status}`).toContain(workerTry.response.status);
      // marker created AFTER any boot snapshot was taken
      const [route, body, list] = creates[name];
      const marker = await raw(ctx, route, { method: 'POST', token: ctx.owner, body });
      expect([200, 201]).toContain(marker.response.status);
      const res = await raw(ctx, routes[name], { method: 'POST', token: ctx.owner, body: {} });
      expect(res.response.status, `${name} restore-auto → ${res.response.status}`).toBeLessThan(500);
      const afterText = JSON.stringify((await raw(ctx, list, { token: ctx.owner })).data);
      const markerGone = !afterText.includes(`RA ${name === 'dairy' ? 'Cow' : name === 'flock' ? 'Batch' : 'Crop'} ${S}`);
      if (res.response.status === 200) {
        expect(markerGone, `${name} restore-auto claimed success but post-snapshot marker survived (fake restore)`).toBe(true);
      } else {
        expect([400, 404, 409], `${name} restore-auto without usable snapshot must error cleanly`).toContain(res.response.status);
        expect(markerGone, `${name} failed restore-auto still destroyed data`).toBe(false);
      }
    }
  });
});
