/**
 * ROUND 17 — NEW upstream features: All-Farms read-only mode,
 * permanent farm deletion rules, dairy backup registry (K1 fix
 * verification), Agri analytics worker redaction.
 * NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, rowsOf, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const apps: Record<string, Ctx> = {};

async function mkFarm(ctx: Ctx, label: string) {
  const r = await raw(ctx, '/farms', { method: 'POST', token: ctx.owner, body: { name: `${label} ${S}` } });
  expect([200, 201], `create farm ${label} → ${r.response.status}`).toContain(r.response.status);
  return String(r.data?.farm?.id || r.data?.id || r.data?.farm?._id || r.data?._id);
}

describe.sequential('ROUND 17: all-farms, deletion, analytics', () => {
  beforeAll(async () => {
    apps.dairy = await startApp('dairy', 'dairy_farm/backend');
    apps.flock = await startApp('flock', 'flock_farm/backend');
    apps.agri = await startApp('agri', 'agri_farm/backend');
  }, 180_000);
  afterAll(async () => { for (const c of Object.values(apps)) await stopApp(c); }, 60_000);

  it('all-farms mode: owner reads across farms but cannot write; worker stays inside assigned farms', async () => {
    const ctx = apps.dairy;
    const farmB = await mkFarm(ctx, 'AF Farm B');
    const cowB = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, farmId: farmB, body: { name: `AF Cow B ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    const cowBId = idOf(cowB.data);
    expect(cowBId).toBeTruthy();

    const all = await raw(ctx, '/cows?limit=500', { token: ctx.owner, farmId: 'all' });
    expect(all.response.status).toBe(200);
    expect(JSON.stringify(all.data), 'all-farms list missed Farm B cow').toContain(cowBId);

    const write = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, farmId: 'all', body: { name: `AF Sneak ${S}`, breed: 'Jersey' } });
    expect([400, 403], `create in all-farms mode → ${write.response.status}`).toContain(write.response.status);
    const upd = await raw(ctx, `/cows/${cowBId}`, { method: 'PUT', token: ctx.owner, farmId: 'all', body: { name: 'AF Edited' } });
    expect([400, 403], `update in all-farms mode → ${upd.response.status}`).toContain(upd.response.status);
    const del = await raw(ctx, `/cows/${cowBId}`, { method: 'DELETE', token: ctx.owner, farmId: 'all' });
    expect([400, 403], `delete in all-farms mode → ${del.response.status}`).toContain(del.response.status);

    // seeded worker is assigned to the default farm only
    const wAll = await raw(ctx, '/cows?limit=500', { token: ctx.worker, farmId: 'all' });
    expect(wAll.response.status).toBe(200);
    expect(JSON.stringify(wAll.data), 'worker all-farms list leaked Farm B cow').not.toContain(cowBId);
    const wWrite = await raw(ctx, '/cows', { method: 'POST', token: ctx.worker, farmId: 'all', body: { name: 'W Sneak', breed: 'Jersey' } });
    expect([400, 403]).toContain(wWrite.response.status);

    await raw(ctx, `/cows/${cowBId}`, { method: 'DELETE', token: ctx.owner, farmId: farmB });
  });

  it('farm deletion rules: confirm-name gate, move-records path, last-farm guard (dairy)', async () => {
    const ctx = apps.dairy;
    const farmB = await mkFarm(ctx, 'DEL Farm');
    const cow = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, farmId: farmB, body: { name: `DEL Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    const cowId = idOf(cow.data);

    const noConfirm = await raw(ctx, `/farms/${farmB}`, { method: 'DELETE', token: ctx.owner, body: {} });
    expect(noConfirm.response.status, `delete farm with records, no confirm → ${noConfirm.response.status}`).toBe(400);
    const wrongName = await raw(ctx, `/farms/${farmB}`, { method: 'DELETE', token: ctx.owner, body: { confirmName: 'Wrong Name', deleteData: true } });
    expect(wrongName.response.status).toBe(400);
    const workerTry = await raw(ctx, `/farms/${farmB}`, { method: 'DELETE', token: ctx.worker, body: { confirmName: `DEL Farm ${S}`, deleteData: true } });
    expect([401, 403]).toContain(workerTry.response.status);
    const ghost = await raw(ctx, '/farms/no-such-farm-id', { method: 'DELETE', token: ctx.owner, body: {} });
    expect(ghost.response.status).toBe(404);

    // move records to the default farm instead of deleting them
    const farms = await raw(ctx, '/farms', { token: ctx.owner });
    const farmA = String((farms.data?.farms || [])[0]?.id || (farms.data?.farms || [])[0]?._id);
    const moved = await raw(ctx, `/farms/${farmB}`, { method: 'DELETE', token: ctx.owner, body: { confirmName: `DEL Farm ${S}`, moveToFarmId: farmA } });
    expect([200, 204], `delete-with-move → ${moved.response.status} ${JSON.stringify(moved.data).slice(0, 140)}`).toContain(moved.response.status);
    const cowAfter = await raw(ctx, `/cows/${cowId}`, { token: ctx.owner, farmId: farmA });
    expect(cowAfter.response.status, 'moved cow not found in destination farm').toBe(200);
    await raw(ctx, `/cows/${cowId}`, { method: 'DELETE', token: ctx.owner });

    // last farm can never be deleted
    const farmsNow = await raw(ctx, '/farms', { token: ctx.owner });
    const only = (farmsNow.data?.farms || [])[0];
    if (only && (farmsNow.data?.farms || []).length === 1) {
      const lastTry = await raw(ctx, `/farms/${only.id || only._id}`, { method: 'DELETE', token: ctx.owner, body: { confirmName: only.name, deleteData: true } });
      expect(lastTry.response.status, 'deleted the last farm').toBe(400);
    }
  });

  it('K1 verification: dairy backup now contains suppliers + supplier payments', async () => {
    const ctx = apps.dairy;
    const sup = await raw(ctx, '/suppliers', { method: 'POST', token: ctx.owner, body: { name: `K1 Supplier ${S}`, phone: '0300-1112223' } });
    expect([200, 201]).toContain(sup.response.status);
    const backup = await raw(ctx, '/backup', { token: ctx.owner });
    expect(backup.response.status).toBe(200);
    const text = JSON.stringify(backup.data);
    expect(text, 'backup STILL omits the suppliers collection').toContain(`K1 Supplier ${S}`);
    expect(backup.data, 'backup has no suppliers key').toHaveProperty('suppliers');
    expect(backup.data, 'backup has no supplierPayments key').toHaveProperty('supplierPayments');
  });

  it('agri analytics: worker view redacts yields and finance; owner sees them', async () => {
    const ctx = apps.agri;
    const crop = await raw(ctx, '/crops', { method: 'POST', token: ctx.owner, body: { name: `Analytics Crop ${S}`, status: 'Completed', plant_date: '2026-09-01', yield_kg: 54321 } });
    const cropId = idOf(crop.data);
    expect(cropId).toBeTruthy();
    const fin = await raw(ctx, '/finance', { method: 'POST', token: ctx.owner, body: { type: 'income', category: `AnalyticsInc ${S}`, amount: 987654, date: '2026-09-10', crop_id: cropId } });
    expect([200, 201]).toContain(fin.response.status);

    const ownerView = await raw(ctx, '/analytics/summary', { token: ctx.owner });
    expect(ownerView.response.status).toBe(200);
    expect(JSON.stringify(ownerView.data), 'owner analytics missing yield').toContain('54321');

    const workerView = await raw(ctx, '/analytics/summary', { token: ctx.worker });
    expect(workerView.response.status).toBe(200);
    const wText = JSON.stringify(workerView.data);
    expect(wText, 'worker analytics leaks completed-crop yield').not.toContain('54321');
    expect(wText, 'worker analytics leaks finance income').not.toContain('987654');
    expect(wText, 'worker analytics leaks income category').not.toContain(`AnalyticsInc ${S}`);

    const finRows = rowsOf((await raw(ctx, '/finance?skip=0&limit=500', { token: ctx.owner })).data).filter((f: any) => f.category === `AnalyticsInc ${S}`);
    for (const f of finRows) await raw(ctx, `/finance/${f._id || f.id}`, { method: 'DELETE', token: ctx.owner });
    await raw(ctx, `/crops/${cropId}`, { method: 'DELETE', token: ctx.owner });
  });

  it('flock all-farms mode: batch writes are blocked in all mode too', async () => {
    const ctx = apps.flock;
    const all = await raw(ctx, '/batches', { token: ctx.owner, farmId: 'all' });
    expect(all.response.status).toBe(200);
    const write = await raw(ctx, '/batches', { method: 'POST', token: ctx.owner, farmId: 'all', body: { name: `AF Batch ${S}`, type: 'Broiler', start_date: '2026-09-01', intake_count: 5, cost_per_bird: 10 } });
    expect([400, 403], `flock create in all-farms mode → ${write.response.status}`).toContain(write.response.status);
  });
});
