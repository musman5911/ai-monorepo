/** ROUND R7 (post-pull deep): agri fields validation, scoping, delete semantics, cycle reuse. NO fixes. */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

describe.sequential('ROUND R7: agri fields deep', () => {
  let ctx: Ctx; let farmB = ''; let fA = ''; let fB = '';
  beforeAll(async () => {
    ctx = await startApp('agri', 'agri_farm/backend');
    const f = await raw(ctx, '/farms', { method: 'POST', token: ctx.owner, body: { name: `R7 FarmB ${S}` } });
    farmB = String((f.data as any)?.farm?.id || (f.data as any)?.id || (f.data as any)?.farm?._id || (f.data as any)?._id);
    const a = await raw(ctx, '/fields', { method: 'POST', token: ctx.owner, body: { name: `R7 Field ${S}`, acres: 10 } });
    fA = idOf(a.data);
    const b = await raw(ctx, '/fields', { method: 'POST', token: ctx.owner, farmId: farmB, body: { name: `R7 Field ${S}`, acres: 4 } });
    fB = idOf(b.data);
  }, 120_000);
  afterAll(async () => { await stopApp(ctx); }, 60_000);

  it('validation: negative/garbage acres rejected, duplicate name per farm 409, same name across farms OK', async () => {
    const neg = await raw(ctx, '/fields', { method: 'POST', token: ctx.owner, body: { name: `R7 Neg ${S}`, acres: -3 } });
    expect([400, 422], `negative acres → ${neg.response.status}`).toContain(neg.response.status);
    const gar = await raw(ctx, '/fields', { method: 'POST', token: ctx.owner, body: { name: `R7 Gar ${S}`, acres: 'banana' } });
    expect([400, 422], `garbage acres → ${gar.response.status}`).toContain(gar.response.status);
    const huge = await raw(ctx, '/fields', { method: 'POST', token: ctx.owner, body: { name: `R7 Huge ${S}`, acres: 1e12 } });
    expect([400, 422], `absurd acres 1e12 → ${huge.response.status}`).toContain(huge.response.status);
    const dup = await raw(ctx, '/fields', { method: 'POST', token: ctx.owner, body: { name: `R7 Field ${S}`, acres: 1 } });
    expect(dup.response.status, `duplicate name same farm → ${dup.response.status}`).toBe(409);
    expect(fB, 'same name in farm B was rejected').toBeTruthy();
    const wUpd = await raw(ctx, `/fields/${fA}`, { method: 'PUT', token: ctx.worker, body: { name: `R7 Field ${S}`, acres: 99 } });
    expect([401, 403], `worker update field → ${wUpd.response.status}`).toContain(wUpd.response.status);
    const wDel = await raw(ctx, `/fields/${fA}`, { method: 'DELETE', token: ctx.worker });
    expect([401, 403], `worker delete field → ${wDel.response.status}`).toContain(wDel.response.status);
    const wRead = await raw(ctx, '/fields', { token: ctx.worker });
    expect(wRead.response.status, `worker read fields → ${wRead.response.status}`).toBe(200);
  });

  it('cross-farm field access: farm B context cannot read/update/delete farm A field by id', async () => {
    const upd = await raw(ctx, `/fields/${fA}`, { method: 'PUT', token: ctx.owner, farmId: farmB, body: { name: 'Hijack', acres: 1 } });
    expect([404], `cross-farm field update → ${upd.response.status}`).toContain(upd.response.status);
    const del = await raw(ctx, `/fields/${fA}`, { method: 'DELETE', token: ctx.owner, farmId: farmB });
    expect([404], `cross-farm field delete → ${del.response.status}`).toContain(del.response.status);
    const still = await raw(ctx, '/fields', { token: ctx.owner });
    expect(JSON.stringify(still.data)).toContain(`R7 Field ${S}`);
  });

  it('rename collision → 409; rename to free name works and crop link follows the id (not the name)', async () => {
    const other = await raw(ctx, '/fields', { method: 'POST', token: ctx.owner, body: { name: `R7 Other ${S}`, acres: 2 } });
    const otherId = idOf(other.data);
    const collide = await raw(ctx, `/fields/${otherId}`, { method: 'PUT', token: ctx.owner, body: { name: `R7 Field ${S}`, acres: 2 } });
    expect(collide.response.status, `rename collision → ${collide.response.status}`).toBe(409);
    const crop = await raw(ctx, '/crops', { method: 'POST', token: ctx.owner, body: { name: `R7 Crop ${S}`, status: 'Growing', plant_date: '2026-10-01', fieldId: otherId } });
    expect(crop.response.status).toBeLessThan(300);
    const rename = await raw(ctx, `/fields/${otherId}`, { method: 'PUT', token: ctx.owner, body: { name: `R7 Renamed ${S}`, acres: 2 } });
    expect(rename.response.status).toBeLessThan(300);
    const byField = await raw(ctx, `/crops?fieldId=${otherId}&limit=50`, { token: ctx.owner });
    expect(JSON.stringify(byField.data), 'crop lost after field rename').toContain(`R7 Crop ${S}`);
  });

  it('deleting a field with linked finance: no dangling fieldId survives in finance rows or byField analytics', async () => {
    const fin = await raw(ctx, '/finance', { method: 'POST', token: ctx.owner, body: { type: 'expense', amount: 777001, category: `R7CAT${S}`, date: '2026-10-05', fieldId: fA } });
    expect(fin.response.status, `finance+field → ${fin.response.status}`).toBeLessThan(300);
    const del = await raw(ctx, `/fields/${fA}`, { method: 'DELETE', token: ctx.owner });
    if (del.response.status < 300) {
      const sum = await raw(ctx, '/analytics/summary', { token: ctx.owner });
      const byField = (sum.data as any)?.financeSummary?.byField || [];
      const dangling = byField.filter((r: any) => String(r.fieldId || '') === fA);
      expect(dangling.length, `byField still totals money under deleted field: ${JSON.stringify(dangling).slice(0, 160)}`).toBe(0);
      const fins = await raw(ctx, '/finance?limit=200', { token: ctx.owner });
      const rows: any[] = Array.isArray(fins.data) ? fins.data : (fins.data?.items || fins.data?.entries || []);
      const mine = rows.filter((r) => Number(r.amount) === 777001);
      for (const r of mine) expect(String(r.fieldId || ''), 'finance row keeps deleted fieldId').not.toBe(fA);
    } else {
      expect([400, 409, 422], `delete field with finance → ${del.response.status}`).toContain(del.response.status);
    }
  });

  it('field reuse across seasons: completed cycle then a new cycle on the same field is allowed', async () => {
    const c1 = await raw(ctx, '/crops', { method: 'POST', token: ctx.owner, body: { name: `R7 Cycle1 ${S}`, status: 'Completed', plant_date: '2025-11-01', harvest_date: '2026-04-01', fieldId: fB, crop_year: '2025', season: 'Rabi' } });
    expect([400, 422], `cycle1 cross-farm field link → ${c1.response.status}`).toContain(c1.response.status);
    // (that link was farm-A context pointing at farm B's field — correctly rejected; real cycles run in farm B below)
    const c2 = await raw(ctx, '/crops', { method: 'POST', token: ctx.owner, farmId: farmB, body: { name: `R7 Cycle2 ${S}`, status: 'Growing', plant_date: '2026-06-01', fieldId: fB, crop_year: '2026', season: 'Kharif' } });
    expect(c2.response.status, `cycle2 same field next season → ${c2.response.status} ${JSON.stringify(c2.data).slice(0, 120)}`).toBeLessThan(300);
    const c3 = await raw(ctx, '/crops', { method: 'POST', token: ctx.owner, farmId: farmB, body: { name: `R7 Cycle3 ${S}`, status: 'Growing', plant_date: '2026-06-02', fieldId: fB, crop_year: '2026', season: 'Kharif' } });
    expect(c3.response.status, `second simultaneous cycle same field → ${c3.response.status} (informational: overlap allowed by design?)`).toBeLessThan(300);
  });
});
