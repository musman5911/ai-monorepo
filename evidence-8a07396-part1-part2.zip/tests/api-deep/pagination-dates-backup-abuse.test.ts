/**
 * DEEP round 4 — pagination at scale, date/month edges, backup
 * abuse (restore-twice, cross-app restore, truncated payloads).
 * NO fixes; failures = findings.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { idOf, raw, rowsOf, S, startApp, stopApp, type Ctx } from '../api-matrix/harness';

const apps: Record<string, Ctx> = {};

describe.sequential('DEEP: pagination, dates, backup abuse', () => {
  beforeAll(async () => {
    apps.dairy = await startApp('dairy', 'dairy_farm/backend');
    apps.flock = await startApp('flock', 'flock_farm/backend');
    apps.agri = await startApp('agri', 'agri_farm/backend');
  }, 180_000);
  afterAll(async () => { for (const c of Object.values(apps)) await stopApp(c); }, 60_000);

  it('dairy pagination: limit/offset never duplicate or skip rows across pages', async () => {
    const ctx = apps.dairy;
    const ids: string[] = [];
    for (let i = 0; i < 12; i++) {
      const r = await raw(ctx, '/cows', { method: 'POST', token: ctx.owner, body: { name: `Page Cow ${S}-${i}`, breed: 'Jersey', gender: 'female', status: 'active' } });
      ids.push(idOf(r.data));
    }
    const seen = new Map<string, number>();
    for (let page = 0; page < 12; page++) {
      const r = await raw(ctx, `/cows?limit=5&skip=${page * 5}`, { token: ctx.owner });
      const rows = rowsOf(r.data);
      if (rows.length === 0) break;
      for (const row of rows) {
        const id = String(row._id || row.id);
        if (ids.includes(id)) seen.set(id, (seen.get(id) || 0) + 1);
      }
    }
    expect(seen.size, 'all 12 cows appear exactly once across pages').toBe(12);
    for (const [, count] of seen) expect(count).toBe(1);
    for (const id of ids) await raw(ctx, `/cows/${id}`, { method: 'DELETE', token: ctx.owner });
  });

  it('pagination abuse: negative/huge/float limits never 500', async () => {
    const cases: Array<[string, string]> = [
      ['dairy', '/cows?limit=-5'],
      ['dairy', '/cows?limit=999999'],
      ['dairy', '/cows?limit=1.5&skip=-1'],
      ['dairy', '/cows?limit=abc&skip=xyz'],
      ['agri', '/finance?skip=-10&limit=-1'],
      ['agri', '/finance?skip=0&limit=100000'],
      ['flock', '/batches?limit=-1'],
    ];
    for (const [name, route] of cases) {
      const r = await raw(apps[name], route, { token: apps[name].owner });
      expect(r.response.status, `${name} ${route}`).toBeLessThan(500);
    }
  });

  it('date edges: month summaries survive Feb-29, month 13 and boundary days', async () => {
    const dairy = apps.dairy;
    const cow = await raw(dairy, '/cows', { method: 'POST', token: dairy.owner, body: { name: `Edge Cow ${S}`, breed: 'Jersey', gender: 'female', status: 'active' } });
    const cowId = idOf(cow.data);
    const leap = await raw(dairy, '/milk', { method: 'POST', token: dairy.owner, body: { cowId, date: '2024-02-29', morning: 2, evening: 2 } });
    expect(leap.response.status, 'leap day milk entry').toBe(201);
    for (const month of ['2024-02', '2026-13', 'not-a-month', '2026-00']) {
      const r = await raw(dairy, `/milk/summary?month=${month}`, { token: dairy.owner });
      expect(r.response.status, `milk summary month=${month}`).toBeLessThan(500);
    }
    const agri = apps.agri;
    const badMonth = await raw(agri, '/finance/summary?month=2026-13', { token: agri.owner }).catch(() => null);
    if (badMonth) expect(badMonth.response.status).toBeLessThan(500);
    await raw(dairy, `/cows/${cowId}`, { method: 'DELETE', token: dairy.owner });
  });

  it('backup abuse: restoring the SAME backup twice must not duplicate data', async () => {
    const ctx = apps.dairy;
    const backup = await raw(ctx, '/backup', { token: ctx.owner });
    expect(backup.response.status).toBe(200);
    const countCows = async () => rowsOf((await raw(ctx, '/cows?limit=500', { token: ctx.owner })).data).length;
    const before = await countCows();
    const first = await raw(ctx, '/backup/restore', { method: 'POST', token: ctx.owner, body: backup.data });
    expect([200, 201]).toContain(first.response.status);
    const afterFirst = await countCows();
    const second = await raw(ctx, '/backup/restore', { method: 'POST', token: ctx.owner, body: backup.data });
    expect([200, 201]).toContain(second.response.status);
    const afterSecond = await countCows();
    expect(afterSecond, 'restore-twice duplicated cows').toBe(afterFirst);
  });

  it('backup abuse: cross-app restore is rejected (no silent mis-import)', async () => {
    const dairyBackup = (await raw(apps.dairy, '/backup', { token: apps.dairy.owner })).data;
    const r1 = await raw(apps.agri, '/restore', { method: 'POST', token: apps.agri.owner, body: dairyBackup });
    expect(r1.response.status, 'dairy backup → agri restore').toBeGreaterThanOrEqual(400);
    const agriBackup = (await raw(apps.agri, '/backup', { token: apps.agri.owner })).data;
    const r2 = await raw(apps.dairy, '/backup/restore', { method: 'POST', token: apps.dairy.owner, body: agriBackup });
    expect(r2.response.status, 'agri backup → dairy restore').toBeGreaterThanOrEqual(400);
  });

  it('backup abuse: wrong-shape payloads never 500 (truncated, array, nested junk)', async () => {
    const payloads: any[] = [
      { format: 'muf-backup', app: 'dairy', version: 1, exportedAt: new Date().toISOString(), data: {} },
      { format: 'muf-backup', app: 'dairy', version: 9999, exportedAt: new Date().toISOString(), data: { cows: 'not-an-array' } },
      ['just', 'an', 'array'],
      { data: { cows: [{ name: 'Partial Cow' }] } },
      { format: 'muf-backup', app: 'dairy', version: 1, data: { cows: [null, 42, 'x'] } },
    ];
    for (const [route, ctx] of [['/backup/restore', apps.dairy], ['/restore', apps.agri]] as const) {
      for (const body of payloads) {
        const r = await raw(ctx, route, { method: 'POST', token: ctx.owner, body });
        expect(r.response.status, `restore junk ${JSON.stringify(body).slice(0, 60)}`).toBeGreaterThanOrEqual(400);
        expect(r.response.status).toBeLessThan(500);
      }
    }
  });
});
