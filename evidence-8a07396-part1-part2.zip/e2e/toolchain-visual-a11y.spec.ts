/**
 * TOOLCHAIN: visual-regression + accessibility gates across
 * all three farm frontends (runs in every Playwright project).
 * - Visual: post-login home screenshot vs committed baseline
 *   (new file toolchain-home.png per project; first run creates
 *   it, later runs diff it).
 * - A11y: axe-core scan of the post-login home; serious/critical
 *   violations are findings.
 */
import { expect, test } from '@playwright/test';

import { login } from './helpers';

test.describe('toolchain visual + a11y', () => {
  test('home: visual baseline holds', async ({ page }) => {
    await login(page);
    await page.waitForTimeout(1500);
    await expect(page).toHaveScreenshot('toolchain-home.png', { maxDiffPixelRatio: 0.02 });
  });

  test('home: no serious/critical axe violations', async ({ page }) => {
    await login(page);
    await page.waitForTimeout(1000);
    await page.addScriptTag({ path: 'node_modules/axe-core/axe.min.js' });
    const results = await page.evaluate(async () => {
      // @ts-expect-error axe injected globally
      const r = await window.axe.run(document, { resultTypes: ['violations'] });
      return r.violations.map((v: { id: string; impact: string; nodes: unknown[] }) => ({ id: v.id, impact: v.impact, nodes: v.nodes.length }));
    });
    const bad = results.filter((v: { impact: string }) => v.impact === 'serious' || v.impact === 'critical');
    expect(bad, `axe serious/critical violations: ${JSON.stringify(bad)}`).toEqual([]);
  });
});
