git rev-parse HEAD: 3d366acdac322055c76f59830ad26152b9e45f09

# Round 3 — Phase 2 interim report (+ Phase 1 follow-ups, Phase 4 result)

Phase 2 was started on `3d366ac` (pulled before starting; diff from Phase 1's `f3dfa12` is Phase 14/15 docs, cross-farm-key header auth, and one Agri cron response change — no card/CSP changes). No app code was changed. All results files referenced start with the HEAD line.

## A. Flock cards quantified (follow-up 1)

Evidence: `results/round3/phase1d-followups.txt` (`tests/round3/phase1d-followups.mjs`, memory/test).

- **Enumeration from id 1 (anonymous):** customers — 200 at ids **1, 2, 3**, first 404 at 4; suppliers — 200 at **1, 2**, first 404 at 3; workers use `lw-<timestamp>` ids (demo: `lw-demo-1/2`). In production the customer/supplier counts will be however many records the farm has; the walk is `max+1` sequential (`flock_farm/client/src/App.tsx:66`), so an attacker reads every customer/supplier card in order until the first gap/404.
- **Fields returned per card (anonymous, exact card text in evidence):**
  - Customer: name, **phone**, total egg sales (Rs), total collected, this-month sales, this-month collected, balance to collect.
  - Supplier: name, **phone**, total purchases, total paid, balance to pay.
  - Worker: name, worker ID, daily wage, attendance days (full/half), wages this month, advance (udhaar) due, net payable.
- **Two-farm test:** created Farm B, PUT a distinct Farm-B customer `{id:1, name:'FARM-B-ONLY CUSTOMER', phone:'0399-0000001'}` under Farm B context (HTTP 200, bucket verified separate from Farm A). **Anonymous `/api/cards/customer/1` still showed Farm A's customer** (Khan General Store, 0301-1234567, balance). Conclusion: the card routes take **no farm context at all** — they read the default/first farm's DataStore bucket. An anonymous user cannot directly address Farm B's bucket through the card route in this test (it always resolves the default farm), but equally the route has no farm check: whichever farm is default is fully enumerable, and in a deployment where buckets are global or the target farm is default, all its cards are readable. Rated **P1** (production: a normal unauthenticated user can enumerate the default farm's customer/supplier cards and read names, phone numbers and balances; no unusual config needed).
- **Worker `lw-<timestamp>` guessability:** ids are `lw-${Date.now()}` (client `LaborTab.tsx`). One day = 86,400,000 ms candidates; at 60 req/15 min/IP a single IP needs ~3.9 years of limiter windows for a full day sweep — the limiter is meaningful per-IP, but there is **no global/account limiter**, so IP rotation defeats it; knowing the approximate creation time (e.g. from other leaked data) narrows the window drastically. Worker-card risk rated lower than customer/supplier (P2) because of the search space.

## B. Cron key in logs, per app (follow-up 2)

Runtime evidence (`LOG_REQUESTS=1`, correct-key requests; `phase1d-followups.txt`):

- **Agri — YES, logged.** Exact line: `[REQ] GET /api/cron/dispatch-report?key=[SECURITY_DATA] auth=NO -> 200`. Produced by `agri_farm/backend/server.js:117` (`console.log(\`[REQ] ${req.method} ${req.originalUrl} ...\`)`, logger block starts line 110).
- **Dairy — YES, logged** (telegram cron equivalent; Dairy has no `/cron/*` route): `[REQ] GET /api/telegram/cron?key=[SECURITY_DATA] auth=NO -> 200`, produced by `dairy_farm/backend/server.js:112`.
- **Flock — NO app log line.** Flock's `server.js` contains no request logger at all (only startup logs at lines 278/280; `logRequests` is parsed in `muf-env.mjs:85` but never used in `flock_farm/backend/server.js`). The Flock cron correct-key request produced **no** `[REQ]` line in captured stdout. So CRON-LOG-1 applies to **Agri and Dairy only**; for Flock the key can still land in intermediary/proxy/cron-service logs (any `?key=` URL is logged by cron-job.org/reverse proxies), but not in the app's own log. Finding CRON-LOG-1 revised: Agri + Dairy, P2.

## C. Other flagged items (follow-up 3)

- **Production CSP, full header sets** (`phase1d-followups.txt`, production mode, fake MONGO_URI, no dist yet): Dairy and Agri responses (HTML `/`, API, error) carry HSTS, nosniff, SAMEORIGIN, referrer-policy, COOP/CORP — but **no `Content-Security-Policy` at all** (helmet `contentSecurityPolicy:false`). Flock carries a full CSP (`default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; …`) on all three response types. Missing per app: Dairy/Agri missing only CSP (frame-ancestors is compensated by X-Frame-Options SAMEORIGIN); Flock missing nothing material. C1 stands, P2 (Dairy/Agri). Real-HTML confirmation after Phase 3 frontend builds is still pending (current `/` is the API placeholder text because no `dist/` exists).
- **Agri SMTP-unconfigured 500s:** exactly two routes return **500** with a configuration-leaking message instead of 503: `agri_farm/backend/routes/auth.js:294` (POST `/api/request-profile-code`, authenticated) and `auth.js:455` (POST `/api/forgot-password` after an admin is found) — body: “SMTP service failed to deliver the verification code. Please check that SMTP credentials are configured correctly in the environment.” Dairy/Flock forgot-password correctly return 503 “Email is not configured on this server”. Wider `err.message` leakage (manual review): Dairy returns raw `err.message` in 500s from **103** sites, Flock 22, Agri 5 (all in `routes/photos.js`) — an information-disclosure pattern (P2 note; individual reachability varies).
- **Agri operator objects (`{"$ne":"x"}`) on every string/enum field:** crops — `name`, `status`, `season`, `crop_type`, `variety`, `unit`, `notes`, `plant_date`, `harvest_date`, `field_id` all **store the object as `{}` with 201**; `area_kanal` (numeric) also stores `{}`; only `fieldId` rejects (400 “fieldId must be a valid field ID”). Liabilities `creditor:{}`, inventory `name:{}`, suppliers `name:{}` also stored 201; tasks returned `{status:"ok"}`. This is a broad validation gap (garbage/tampered types persist and render as empty), **not** a NoSQL injection (no query bypass; login probes all rejected). Extends FZ-3, P2.
- **Phase 4 (real DB) — final result for this sandbox:** ordered attempts in `results/round3/phase4-db-attempts.txt`: apt (package lists unreachable, `Unable to locate package mongodb`), conda/mamba (absent), mongodb-memory-server via fastdl (TLS reset, 3 retries), same via npmmirror mirror (TLS reset), FerretDB binary via `gh release download` (release-asset host EOF/blocked), Docker/Podman (absent), Go build of FerretDB/gitleaks (Go absent). **No real or substitute MongoDB could be run.** Authenticated production behaviour, real-Mongo IDOR/backup/photo behaviour therefore remain **UNVERIFIED**. Exact local commands for the user: `docker run -d -p 27017:27017 mongo:7` then re-run `tests/round3/phase1-dynamic.mjs`, `phase1b-prod-proxy-cards.mjs` and the IDOR matrix with `MEMORY_MODE=` unset and `MONGO_URI=mongodb://127.0.0.1:27017/muf` — or on any machine with MongoDB/fastdl access, `node -e "const {MongoMemoryServer}=require('mongodb-memory-server');…"`.

## D. Phase 2 static results

Raw vs triaged (files in `results/round3/`):

| Tool | Raw | Real after triage |
|---|---|---|
| Semgrep (cloned JS rules + 5 custom rules, 176 rules, 471 files) | 198 findings | SG-4 confirmed (below); rest FP/notes |
| njsscan (3 backends) | express_xss 1, helmet_feature_disabled 2, insecure_random 16, node_nosqli 77, timing_attack 1, regex_dos 2 | helmet_disabled = C1 (Dairy/Agri CSP off) — real; nosqli 77 are query-builder patterns, custom runtime probes rejected — FP; regex_dos are the memory-mode `muf-query` `$regex` evaluator (memory only) — note |
| ESLint (security/promise/no-unsanitized, backends) | 0 messages / 132 files | no findings under this ruleset |
| detect-secrets (647 tracked files) | 17 files flagged | all FPs: `.env.example` placeholders and the word “secret” in tests/tools |
| npm audit (3 backends) | 0 vulnerabilities (all severities) | AUD-1 does **not** reproduce on backends at this tip; client audits pending Phase 3 installs |
| depcheck (3 backends) | no issues | — |
| madge circular (3 backends) | no circular dependencies | — |
| knip | crashed (`Array buffer allocation failed`) scanning the whole tree incl. `tools-round3` | UNVERIFIED — rerun scoped per-client in Phase 3 if time |
| retire | CLI flag error (`--outputfile` unknown in this version) | UNVERIFIED — superseded by npm audit for backends |
| Stryker (flock `batch-math.mjs`) | mutation score **81.88%** (131 killed, 24 survived, 5 no-cov) | survivors cluster at `cost_per_bird` when `live_count` is 0 (`>0`→`>=0`/`<=0`, `/`→`*` at batch-math.mjs:49-50). Suggested tests: batch with all birds dead/sold (live_count=0) asserting cost_per_bird fallback; zero-intake batch; egg-income-only batch. Other Stryker targets (auth, validators, farm guards, photo routes) have no unit-test harness upstream — UNVERIFIED, exact command: `./tools-round3/node_modules/.bin/stryker run tests/round3/stryker.config.json` with `mutate` repointed |

Semgrep detail: 100× `html-in-template-string` are the muf-card HTML templates (values escaped by the card renderer; QR-card hostile-HTML test in Phase 3 will verify), 25× `missing-template-string-indicator` + 25× `javascript-confirm` are style/correctness noise, 4× custom wildcard-ACAO are the cross-farm farm-summary handlers (key-gated, now timing-safe header auth at this tip — P2 note), 3× prototype-pollution-loop are the memory-mode `muf-query` `setPath` (runtime proto probe in Phase 1 did not pollute; memory-only — note), 3× express-data-exfiltration are `Object.assign(sale/user, payload)` update paths (the Flock `Object.assign(user, updates)` at `routes/auth.js:359` is the A6-class mass-assignment surface to re-check against the Phase 1 role tests). **32× Math.random**: the security-relevant subset is 6-digit verification/link codes — Agri profile-code (`routes/auth.js:280`), Agri reset code (`:447`), Telegram link codes (`muf-telegram.mjs:132`, all three apps) — **SG-4 STILL FAILING, P2**; the rest are demo-data/UI randomness (FP).

Manual code-review pass (`phase2-manual-grep.txt`): raw `err.message` in 500 responses (Dairy 103 sites, Flock 22, Agri 5) — P2 information-disclosure note; timing-safe comparisons are used for cron/cross-farm secrets at this tip; IDs use `crypto.randomUUID` in Dairy routes.

## Phase 2 interim conclusions

No new P0/P1 from static analysis. Confirmed/standing: SG-4 (Math.random codes, P2), C1 (Dairy/Agri no CSP in production, P2), err.message disclosure pattern (P2 note), Agri operator-object validation gap (P2, extends FZ-3), Agri SMTP 500-vs-503 (P2 note). Phase 3 (browser: axe/Lighthouse/screenshots/service-worker/contract) follows next, then the final report with newest-tip P1 re-runs.
