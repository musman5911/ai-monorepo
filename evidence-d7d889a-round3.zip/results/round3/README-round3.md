git rev-parse HEAD: d7d889a3c1288e9baff346a8a0716ed092656efc
# Round 3 evidence bundle
Reports: PHASE0-INTERIM-REPORT.md, PHASE1-SUMMARY.md, PHASE2-INTERIM-REPORT.md, PHASE3-INTERIM-REPORT.md
Reproduce (from repo root, memory mode):
  cd dairy_farm/backend && PORT=19511 NODE_ENV=test MEMORY_MODE=1 JWT_SECRET=[SECURITY_DATA] DISABLE_INTERNAL_SCHEDULER=1 node server.js
  node tests/round3/phase1-dynamic.mjs ; node tests/round3/idor-authz-matrix.mjs
  node tests/round3/phase3-flock-cards-reverse.mjs ; node tests/round3/final-p1-rerun.mjs
Browser (needs tools-round3 with playwright-core + @sparticuz/chromium + NSS libs):
  node tests/round3/phase3-browser.mjs ; node tests/round3/phase3b-state.mjs
Real-DB rerun (user machine): docker run -d -p 27017:27017 mongo:7, then rerun the
Phase 1 / IDOR / card scripts with MEMORY_MODE unset and MONGO_URI=mongodb://127.0.0.1:27017/muf
