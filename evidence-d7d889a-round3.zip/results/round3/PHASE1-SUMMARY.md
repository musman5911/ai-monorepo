git rev-parse HEAD: f3dfa124a205e9adeab7e993f11ffbe8f3c5491f

# Round 3 — Phase 1 summary (backend dynamic)

Commit note: Phase 1 was started and finished on `f3dfa12`. During the work `origin/muf-monorepo` moved to `a8d4ad1f89e417a06b75b77c44f263c67983e69e`; per instruction the phase was NOT restarted. Failing P1 items will be re-run on the newest tip at the end. Environment labels are on every row; memory-mode/test results are rated by production meaning, not by test-env reachability alone.

## 1. Full-route Schemathesis (adjustment 1)

Spec built from the authorization-matrix route extractor (`tests/round3/build-full-specs.mjs`): **Dairy 119 routes / 82 paths, Agri 113 / 68, Flock 71 / 58** — exact extractor counts in `results/round3/full-spec-build.txt`, route lists in `results/round3/routes-*.txt`, specs in `tests/round3/specs-full/`. Runner: `tests/round3/run-schemathesis-full.mjs` (fresh server per role, `-n 2`, workers 4).

| App / role | Operations | Generated | Raw failures | File |
|---|---|---|---|---|
| Dairy owner | 118 | 624 | 101 | schemathesis-full-dairy-owner.txt |
| Dairy worker | 118 | 685 | 100 | schemathesis-full-dairy-worker.txt |
| Dairy anon | 118 | 685 | 100 | schemathesis-full-dairy-anon.txt |
| Agri owner | 99 | 553 | 101 | schemathesis-full-agri-owner.txt |
| Agri worker | 99 | 676 | 57 | schemathesis-full-agri-worker.txt |
| Agri anon | 99 | 699 | 55 | schemathesis-full-agri-anon.txt |
| Flock owner | 69 | 541 | 50 | schemathesis-full-flock-owner.txt |
| Flock worker | 69 | 495 | 48 | schemathesis-full-flock-worker.txt |
| Flock anon | 69 | 539 | 51 | schemathesis-full-flock-anon.txt |

**Triage (raw → real):**
- **Real bugs found by Schemathesis: none new.** Every ST101 “server error” is the deliberate **503 “Email is not configured on this server”** / Agri SMTP 500-on-unconfigured-mail path — an unconfigured-service response, not a crash (Agri’s is arguably the wrong status, 500 instead of 503; logged as a minor note, not a finding).
- ST401 “accepts without authentication” operations are the intentional public surface only: health, mail-status, can-signup/check-setup, logout, settings/location (Dairy, by design), and the Telegram webhook — which **always ACKs 200 but ignores wrong secrets** (`dairy_farm/backend/routes/telegram.js:108`), so it is not an auth bypass. False positives.
- ST203/ST204 (missing-header / undeclared-method expectations) and most ST202 are **generated-spec documentation mismatches**: our generated spec declares bearer auth and a fixed status set for every operation, so 400-before-401 ordering and TRACE→404 instead of 405 count as “failures”. False positives.
- ST201 “schema-violating accepted” reduces to (a) the webhook ACK above and (b) generic-object request schemas accepting operator objects — the one substantive case (Agri crop `status:{"$ne":"x"}` stored as `{}`) was re-probed manually in Phase 1C and is counted under the existing validation family, not as a Schemathesis-only finding.
- No 5xx crash, no cross-role data leak, and no wrong-2xx was produced by Schemathesis beyond the items already covered by the dedicated probes below. **Counts: 663 raw failures across 9 runs → 0 new real bugs; ~663 documentation/public-surface false positives** (the Agri SMTP-500 status choice is the only arguable exception, rated P2-note).

## 2. Production-mode retests (adjustment 2)

File: `results/round3/phase1b-prod-proxy-cards.txt` (script `tests/round3/phase1b-prod-proxy-cards.mjs`). Production servers used `NODE_ENV=production`, `FRONTEND_URL=https://good.example`, strong JWT_SECRET, `MONGO_URI=mongodb://127.0.0.1:27017/muf_prod` (unreachable — **no real DB exists in this sandbox**, so authenticated production behaviour remains UNVERIFIED; production+MEMORY_MODE exits by design in all three apps, which itself re-confirms SG-2’s fix).

- **CORS production:** good origin reflected with credentials where configured (Agri/Flock `ACAC=true`, Dairy no credentials flag); **evil origin gets no `Access-Control-Allow-Origin` in all three** (Dairy/Agri preflight 204 with `ACAO=null`; Flock preflight 503 at the startup gate with no ACAO). The test-mode reflection seen earlier does **not** reproduce in production mode. CORS-1 (test-env only) is therefore **downgraded to an environment note, not a production finding**.
- **Headers production:** Flock keeps its CSP on API/error/HTML responses; **Dairy and Agri have CSP ABSENT** on API (503 gate), error and `/` HTML responses (helmet `contentSecurityPolicy:false`) — C1 remains a real production-mode observation for Dairy/Agri, P2. `nosniff`/`SAMEORIGIN` present everywhere. Static-asset probing is limited: no frontend `dist/` exists yet (Phase 3 builds it); the guessed asset path returned the SPA/plain-text fallback. Authenticated-response cache headers could not be probed in production without a DB (503 gate) — UNVERIFIED for production, memory-mode evidence stands.
- **Reverse proxy + limiters:** the test proxy appends `, 198.51.100.23` to any client `X-Forwarded-For`. Direct-to-server changing-XFF wrong logins ×14: **no 429 in any app** (fresh bucket per spoofed IP — RL-1’s mechanism confirmed direct). **Through the appending proxy, the same changing-XFF attempts DO block**: Dairy 429 from attempt 6 (limit 5), Agri/Flock from attempt 11 (limit 10). Clear answer: **with a correctly appending proxy in front, the XFF spoof does NOT work** — `trust proxy: 1` keys on the proxy-appended address. RL-1 is therefore exploitable only when the app is directly exposed (or behind a non-appending proxy), and must be rated accordingly (P2, deployment-dependent), not P1.
- Load through the same proxy (autocannon `-c 10 -d 5`, Phase 1C): all three apps answer at ~1.3–2.7k req/s with p50 latency 1–2 ms; the non-2xx flood is the **API limiter (300) tripping**, not errors — LD-1 confirmed as a limiter-throughput ceiling behind a single-IP proxy, consistent with the proxy result above.

## 3. Cron key in URL (adjustment 3) — NEW FINDING CRON-LOG-1

With `LOG_REQUESTS=1`, the correct-key cron requests were written verbatim to server logs (`phase1b-prod-proxy-cards.txt`):

```
[REQ] GET /api/cron/dispatch-report?key=[SECURITY_DATA] auth=NO -> 200
```

(and the Flock equivalent). The secret is **not** echoed in any response body (checked wrong/correct, both apps). Agri correct query key → 200, Flock correct query key → 503 (recipients unconfigured; auth passed), wrong keys → 401 in both. Finding: **cron secret in URL is persisted in request logs whenever LOG_REQUESTS=1** (and would equally land in any intermediary/proxy access log). Severity **P2** (requires log access; header alternative exists and works in both apps after Phase 14). Status: STILL FAILING on f3dfa12, memory/test environment, production meaning = any deployment with request logging on. Suggested fix: prefer `x-cron-key` header and redact `key=` in the request logger.

## 4. Public cards after Phase 14 (adjustment 4)

Headers verified fixed in Phase 1 start. Dedicated results in `phase1b-prod-proxy-cards.txt`:

- **Burst limiter works:** first card tested per app: 60×200 then 429 from request 61, both direct same-IP and through the appending proxy with rotating spoofed XFF (proxy-appended IP is the bucket — spoof does not reset it). Later cards in the same server were already at 429 because the limiter is per-IP across all card types (shared bucket), which is itself worth noting: one IP’s card views exhaust the quota for every card type.
- **Data returned today (anonymous, by link):**
  - Dairy buyer: name, **phone 0312-9876543**, total milk value Rs 1,314,573, collected, monthly figures, balance Rs 64,023. Supplier: name, **phone 0300-1112233**, purchases/paid/balance. Worker: name, worker ID, daily wage Rs 700, attendance, wages, advance Rs 5,000, net payable.
  - Agri supplier: name, **phone 0300-4445566**, purchases Rs 268,600 / paid / balance Rs 115,720. Worker: name, ID, wage Rs 1,200, attendance, wages, advance Rs 6,000, net Rs 20,400.
  - Flock customer: name, **phone 0301-1234567**, egg sales/collected/monthly/balance. Supplier: name, **phone**, purchases/paid/balance. Worker: name, ID, wage Rs 300, attendance, wages, advance Rs 1,500, net.
- **Enumeration:** Dairy/Agri card IDs are 24-char hex (unguessable; demo-only short IDs like `b2`, `lw-demo-1` exist only in memory seed data). **Flock customer and supplier IDs are sequential integers** (`customers` ids 1,2,3; suppliers 1,2): anon probes of `/api/cards/customer/1..8` returned 200,200,200,404… — enumerable in production too, because the client assigns `nextId = max+1` (`flock_farm/client/src/App.tsx:66,446`). Flock worker IDs are `lw-<Date.now()>` timestamps (guessable within a time window). The 60/15 min limiter slows but does not prevent enumeration of Flock customer/supplier cards. This **sharpens B1–B3 for Flock**: rated **P1** for Flock customer/supplier cards (a normal unauthenticated user can walk sequential IDs and read names, phone numbers and balances), P2 for Dairy/Agri (link-possession only). Environment: memory/demo IDs, but the ID-generation code path is production client code — production meaning verified by code + runtime.

## 5. Rest of Phase 1

- **IDOR / authorization matrix** (`tests/round3/idor-authz-matrix.mjs`, all routes × anon/worker/manager-A/manager-B-other-farm/owner): Dairy 119, Agri 113, Flock 71 routes. Cross-farm manager-B got **no 2xx on any farm-scoped route**; the only manager-B 200s are public endpoints (health, mail-status, can-signup, webhook ACK, Dairy public location). Files `results/round3/idor-{dairy,agri,flock}.txt`. No new IDOR finding.
- **JWT** (`phase1c-protocol-chaos-load.txt`): token TTLs — Dairy 7d, **Agri 24h**, Flock 7d (A3 retest: Agri’s shorter TTL stands). alg=none rejected, weak-secret dictionary (secret/password/123456/jwt-secret/change-me) rejected, expired-valid-signature rejected, kid-traversal ignored. jwt_tool itself runs after `pip install ratelimit` but its decode path needs pycryptodomex (warning recorded in `phase1-jwt-nosql-tools.txt`); custom attacks above are the substantive evidence. No new JWT finding.
- **NoSQL:** NoSQLMap is Python-2-only (SyntaxError under py3, no python2) — tool limitation recorded; custom probes: all login operator injections rejected (401/400) in all three apps including Agri **urlencoded** `username[$ne]` forms. One validation-family data point: Agri crop create with `status:{"$ne":"x"}` returned 201 and stored `status:{}` — operator object coerced, not an injection (no query bypass). Counted under FZ validation, P2.
- **Protocol abuse:** malformed JSON → 400, 12 MB body → 413, duplicate keys → last-value-wins 201 (normal JSON semantics, noted), text/plain JSON body ignored → 400 validation, method-override header ignored, TRACE → 404, OPTIONS → 204, encoded/null-byte/semicolon paths → 404. No new finding.
- **Hypothesis (Agri):** minimal counterexamples found automatically — liability `amount_owed: -1` stored 201, inventory `quantity: -1` stored 201 (`phase1-hypothesis.txt`). G1/G2 STILL FAILING.
- **fast-check commands (Agri):** shrunk counterexample `[Create(0), Adjust(-1)]` — a PUT can drive inventory quantity negative after a valid create (`phase1-fastcheck.txt`). G2 also fails via update.
- **Chaos:** SIGKILL → connection refused; restart → healthy, post-restart malformed body → 400. Memory-mode data loss on kill is by design and labelled; production (Mongo) persistence remains UNVERIFIED.
- **Phase 1 first script** (`phase1-dynamic.txt`) stands: A1 logout-revocation STILL FAILING all three (Dairy has no logout endpoint), cross-app tokens rejected 6/6, Agri negative liability/inventory + invalid-date crop 201s, Dairy cow invalid birthDate now 400 (partial FZ-2 fix).

### Phase 1 findings carried to the master table
| ID (provisional) | Item | Severity (calibrated) | Status on f3dfa12 |
|---|---|---|---|
| CRON-LOG-1 | Cron `?key=` secret written verbatim to request logs (LOG_REQUESTS=1) | P2 | NEW, STILL FAILING |
| B1–B3-Flock | Flock customer/supplier cards enumerable (sequential IDs) + phone/balance exposure | P1 | SHARPENED |
| RL-1 | XFF-spoofable login limiter — direct exposure only; appending proxy defeats it | P2 (downgraded from P1) | NARROWED |
| LD-1 | API limiter ceiling behind single-IP proxy (autocannon non-2xx flood at 300) | P2 | CONFIRMED, environment-dependent |
| C1 | No CSP in production mode, Dairy/Agri (Flock has CSP) | P2 | STILL FAILING |
| A1, G1, G2, G3-class | Logout non-revocation; negative liability/inventory (create + PUT); huge area + invalid crop date | as previously rated | STILL FAILING |
| CORS-1 | Test-mode origin reflection | — | RETRACTED as production finding (production mode clean) |

Next: Phase 2 (static) and Phase 3 (frontend, real browser), then Phase 4 and the newest-tip P1 re-runs.
