Local clone `git rev-parse HEAD` = `8ed72e7d19b3cacf2b9e219adcd2ff9225420db8`; remote tip `git log -1 --format=%H origin/muf-monorepo` = `8ed72e7d19b3cacf2b9e219adcd2ff9225420db8`; difference: none — the fresh clone is exactly at the current `muf-monorepo` tip.

# Round 3 — Phase 0 Interim Report (install & capability proof)

Date: 2026-10-27 (Asia/Karachi) · Repo: `/home/user/bughunt-round3` · App code changed: **none** (only `tests/round3/`, `results/round3/`, `tools-round3/` added).

## Environment

| Item | Evidence |
|---|---|
| OS | Debian 12 (bookworm) |
| Node / npm | v22.22.3 / 10.9.8 |
| Python / pip | 3.11.2 / 23.0.1 |
| CPU/RAM/disk at probe | 3.8 GiB RAM, 21G disk / 18G available |
| Missing initially | Java, Go, Rust/Cargo, Docker/Podman, `mongod`/`mongosh`, conda, system browsers |
| Network | github.com, registry.npmjs.org, pypi.org reachable; Debian archive, MongoDB CDN and browser CDNs blocked/reset |
| Raw probe | `results/round3/phase0-probes.txt` |

## Tool capability table

| Capability | Status | Exact route / evidence |
|---|---|---|
| Schemathesis | WORKING | pip individual install; `schemathesis --version` → 4.32.5 (`results/round3/phase0-python-tools.txt`) |
| Hypothesis (Python) | WORKING | hypothesis 6.170.12 |
| fast-check | WORKING | installed in isolated `tools-round3` npm tree (919 packages) |
| autocannon | WORKING | `tools-round3/node_modules/.bin/autocannon` |
| Locust | WORKING | `python3 -m pip install --user --break-system-packages locust`; `~/.local/bin/locust --version` → 2.47.0 (`results/round3/phase0-sudo-locust.txt`) |
| jwt_tool | CLONED | `tools-round3/src/jwt_tool` |
| NoSQLMap | CLONED | `tools-round3/src/NoSQLMap` |
| Semgrep + rules | WORKING | `semgrep --version` reports 1.172.0 at report time (earlier individual-install probe reported 1.182.1; rules cloned at `tools-round3/src/semgrep-rules`) |
| njsscan / ESLint security suites | INSTALLED | Python njsscan plus npm ESLint with security, no-unsanitized, n, promise, react, react-hooks, jsx-a11y, typescript-eslint plugins |
| Stryker | INSTALLED | `tools-round3/node_modules/.bin/stryker`, vitest runner present |
| knip / madge / depcheck / retire / html-validate | INSTALLED | present in `tools-round3/node_modules/.bin` |
| Lighthouse | INSTALLED | present in `tools-round3/node_modules/.bin`; execution depends on the Chromium route below |
| Playwright-core + Chromium | WORKING (non-obvious route) | See “Browser route” below |
| Puppeteer-core | INSTALLED | present; same Chromium executable can be used |
| gitleaks | SOURCE ONLY | cloned `tools-round3/src/gitleaks`; binary build blocked because Go is absent |
| MongoDB (real) | NOT YET | no mongod; apt/Docker unavailable; `mongodb-memory-server` download from fastdl.mongodb.org failed ECONNRESET — full ordered Phase 4 attempts still pending |
| FerretDB | SOURCE ONLY | cloned `tools-round3/src/FerretDB`; build blocked because Go is absent; if ever run it will be labelled non-Mongo, never as real-Mongo evidence |
| Java-based tools | BLOCKED | Java absent and Debian archive unreachable |

## Failed routes and fallbacks (Phase 0)

1. **Batch pip install failed atomically** because PyPI package name `osv-scanner` does not exist in this environment. Fallback: install Python tools individually — succeeded for schemathesis, hypothesis, requests, PyJWT, njsscan, detect-secrets and semgrep. Evidence: `results/round3/phase0-python-tools.txt`.
2. **Locust first attempts failed**: `--user` without `--break-system-packages` hit PEP 668; a system attempt hit permission errors. Working fallback: `python3 -m pip install --user --break-system-packages locust` → Locust 2.47.0. Evidence: `results/round3/phase0-sudo-locust.txt`.
3. **apt route blocked**: `sudo -n apt-get update` succeeds with rc=0 but every Debian InRelease fetch fails (“Connection failed”), so `apt-cache policy` has no candidates for mongodb/firefox-esr/chromium, and browser libraries cannot be located. Evidence: `results/round3/phase0-sudo-locust.txt`, `results/round3/phase0-browser-libs.txt`.
4. **`@sparticuz/chromium` first probe failed** only because the CommonJS export nests the API under `.default`. Correct route: `require('@sparticuz/chromium').default`.
5. **Chromium launch then failed** with `libnspr4.so: cannot open shared object file`; `ldd /tmp/chromium` showed exactly three missing libraries: `libnspr4.so`, `libnss3.so`, `libnssutil3.so`. Evidence: `results/round3/phase0-sparticuz.txt`.
6. **NSS/NSPR fallback built from GitHub**: cloned `nss-dev/nss` and `mozilla/nspr`, added Chromium `gyp` (GitHub) via a Python wrapper (`tools-round3/bin/gyp`), installed PyPI `ninja` and `six`, then `./build.sh -o`. The overall NSS build stopped later in an unrelated command tool (`tstclnt` needs `zlib.h`), but the required shared libraries were already produced in `tools-round3/src/dist/Release/lib/`.
7. **Browser route proven working**: with `LD_LIBRARY_PATH=/home/user/bughunt-round3/tools-round3/src/dist/Release/lib`, Playwright-core launched the Sparticuz Chromium: `LAUNCH OK 153.0.8010.0`, page title/h1 round-trip succeeded, `BROWSER ROUTE: WORKING`. Evidence: `results/round3/phase0-sparticuz-launch2.txt`. Therefore Phase 3 browser attempts, axe and Lighthouse are **not** pre-blocked; if they fail later it will be for app/tool-specific reasons recorded then.
8. **MongoDB substitute attempt**: npm `mongodb-memory-server` installed, but creating a server failed because `https://fastdl.mongodb.org/linux/mongodb-linux-x86_64-debian12-8.2.6.tgz` reset the TLS connection after retries. Phase 4 will still run the remaining ordered routes (alternate mirrors / npm distributions / any other sanctioned source) and will leave real-DB items UNVERIFIED if none works; exact local commands will be supplied.

## What Phase 0 does — and does not — prove

- Phase 0 proves tool availability only. **No Round 3 vulnerability findings are claimed yet.**
- All prior verdicts remain “to be retested on `8ed72e7`” until Phase 1–3 evidence exists.
- Because the browser route works, earlier “browser UNVERIFIED” gaps (axe/Lighthouse/screenshots, M1–M4 contrast in a real browser) will be attempted for real in Phase 3 before any jsdom fallback is used.
- Because real MongoDB is not yet available, anything depending on real-DB behaviour stays UNVERIFIED unless Phase 4 succeeds; memory-mode results will be labelled and severity-rated by production meaning per the Round 3 calibration (P0/P1/P2).

## Evidence files (Phase 0)

- `results/round3/phase0-probes.txt`
- `results/round3/phase0-python-tools.txt`
- `results/round3/phase0-sudo-locust.txt`
- `results/round3/phase0-browser-libs.txt`
- `results/round3/phase0-sparticuz.txt`
- `results/round3/phase0-sparticuz-launch2.txt`
- `tests/round3/phase0-probe.sh`

## Next

Phases 1A–J (backend dynamic), 2K–P (static), 3Q–W (frontend; another interim follows Phase 3), then Phase 4X (real DB) and the final report with zipped tests/results/README.
