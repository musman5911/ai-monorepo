import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';
const root=process.cwd();
console.log(`git rev-parse HEAD: ${execSync('git rev-parse HEAD',{cwd:root,encoding:'utf8'}).trim()}`);
const cfgs={dairy:'dairy_farm/backend',agri:'agri_farm/backend',flock:'flock_farm/backend'};
function extract(dir){
 const server=fs.readFileSync(path.join(dir,'server.js'),'utf8'); const imports={};
 for(const m of server.matchAll(/import\s+(\w+)(?:\s*,\s*\{[^}]*\})?\s+from\s+'.\/routes\/([\w.-]+)'/g)) imports[m[1]]=m[2];
 const mounts=[]; for(const m of server.matchAll(/app\.use\('([^']+)',\s*(\w+)\)/g)) if(imports[m[2]]) mounts.push([m[1],imports[m[2]]]);
 const routes=[]; const seen=new Set(); const add=(method,p)=>{const k=`${method} ${p}`; if(!seen.has(k)&&!p.includes('*')){seen.add(k);routes.push([method,p]);}};
 for(const m of server.matchAll(/app\.(get|post|put|patch|delete)\('([^']+)'/g)) add(m[1].toUpperCase(),m[2]);
 const readRoutes=(file,prefix)=>{const src=fs.readFileSync(path.join(dir,'routes',file),'utf8'); for(const m of src.matchAll(/router\.(get|post|put|patch|delete)\('([^']+)'/g)){const sub=m[2]==='/'?'':m[2]; add(m[1].toUpperCase(),(prefix+sub).replace(/\/{2,}/g,'/'));}};
 for(const [mount,file] of mounts) readRoutes(file,mount);
 const arr=server.match(/const apiRouters = \[([\s\S]*?)\];/); if(arr){for(const m of arr[1].matchAll(/(\w+)/g)){const file=imports[m[1]]; if(file) readRoutes(file,'/api');}}
 for(const m of server.matchAll(/app\.use\('\/api',\s*(\w+)\)/g)){const file=imports[m[1]]; if(file) readRoutes(file,'/api');}
 return routes;
}
fs.mkdirSync('tests/round3/specs-full',{recursive:true});
const counts={};
for(const [app,dir] of Object.entries(cfgs)){
 const routes=extract(dir); counts[app]=routes.length;
 const paths={};
 for(const [method,p0] of routes){
   if(!p0.startsWith('/api')) continue;
   let p=p0.slice(4)||'/';
   const params=[]; p=p.replace(/:([A-Za-z_][A-Za-z0-9_]*)/g,(_,n)=>{params.push(n); return `{${n}}`;});
   paths[p] ||= {};
   const op={operationId:`${method.toLowerCase()}_${p.replace(/[^A-Za-z0-9]+/g,'_')}`, responses:{'200':{description:'ok'},'201':{description:'created'},'204':{description:'no content'},'400':{description:'bad request'},'401':{description:'unauthorized'},'403':{description:'forbidden'},'404':{description:'not found'},'405':{description:'method not allowed'},'409':{description:'conflict'},'422':{description:'unprocessable'},'429':{description:'rate limited'},'500':{description:'server error'},'502':{description:'bad gateway'},'503':{description:'unavailable'}}};
   if(params.length) op.parameters=params.map(n=>({name:n,in:'path',required:true,schema:{type:'string'}}));
   if(!['GET','DELETE'].includes(method)) op.requestBody={content:{'application/json':{schema:{type:'object',additionalProperties:true}},'application/x-www-form-urlencoded':{schema:{type:'object',additionalProperties:true}}}};
   paths[p][method.toLowerCase()]=op;
 }
 const spec={openapi:'3.0.3',info:{title:`${app} full-route fuzz spec (generated from route extractor)`,version:'1.0.0'},servers:[{url:'/api'}],security:[{bearer:[]}],components:{securitySchemes:{bearer:{type:'http',scheme:'bearer'}},schemas:{}},paths};
 fs.writeFileSync(`tests/round3/specs-full/spec-${app}-full.yaml`, JSON.stringify(spec,null,2).replaceAll('\\"','"'));
 console.log(`${app}: routes=${routes.length} paths=${Object.keys(paths).length}`);
 const routeList=routes.map(([m,p])=>`${m} ${p}`).join('\n');
 fs.writeFileSync(`results/round3/routes-${app}.txt`, `git rev-parse HEAD: ${execSync('git rev-parse HEAD',{cwd:root,encoding:'utf8'}).trim()}\n${app} extracted routes: ${routes.length}\n${routeList}\n`);
}
console.log('counts',counts);
