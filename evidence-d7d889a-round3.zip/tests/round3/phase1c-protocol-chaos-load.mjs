import { spawn, execSync, execFile } from 'node:child_process';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
const root=process.cwd(); const outDir=path.join(root,'results/round3'); const head=execSync('git rev-parse HEAD',{cwd:root,encoding:'utf8'}).trim();
const out=[]; const log=(s='')=>{out.push(String(s)); console.log(s)};
log(`git rev-parse HEAD: ${head}`); log('command: node tests/round3/phase1c-protocol-chaos-load.mjs'); log('environment: direct + local appending proxy, NODE_ENV=test, MEMORY_MODE=1');
const SECRET='[SECURITY_DATA]';
const apps=[{name:'dairy',dir:'dairy_farm/backend',port:18701,proxy:18801},{name:'agri',dir:'agri_farm/backend',port:18702,proxy:18802},{name:'flock',dir:'flock_farm/backend',port:18703,proxy:18803}];
const procs=[], proxies=[]; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
function start(app){ const p=spawn(process.execPath,['server.js'],{cwd:path.join(root,app.dir),env:{...process.env,PORT:String(app.port),NODE_ENV:'test',MEMORY_MODE:'1',MONGO_URI:'',MONGODB_URI:'',JWT_SECRET:SECRET,CRON_SECRET:'[SECURITY_DATA]',TELEGRAM_BOT_TOKEN:'',DISABLE_INTERNAL_SCHEDULER:'1',LOG_REQUESTS:'0'},stdio:'ignore'}); procs.push(p); app.proc=p; app.base=`http://127.0.0.1:${app.port}`; }
function proxy(app){ const srv=http.createServer((rq,rs)=>{const ch=[];rq.on('data',c=>ch.push(c));rq.on('end',()=>{const b=Buffer.concat(ch);const h={...rq.headers,host:`127.0.0.1:${app.port}`,'x-forwarded-for':(rq.headers['x-forwarded-for']?rq.headers['x-forwarded-for']+', ':'')+'198.51.100.23'};const up=http.request({hostname:'127.0.0.1',port:app.port,path:rq.url,method:rq.method,headers:h},u=>{rs.writeHead(u.statusCode,u.headers);u.pipe(rs)});up.on('error',e=>{rs.writeHead(502);rs.end(String(e))});if(b.length)up.write(b);up.end()})}); srv.listen(app.proxy,'127.0.0.1'); proxies.push(srv); app.pbase=`http://127.0.0.1:${app.proxy}`; }
async function ready(app){for(let i=0;i<80;i++){try{const r=await fetch(app.base+'/api/farms'); if(r.status&&r.status!==503)return true}catch{} await sleep(300)} return false}
async function req(base,route,o={}){const h={...(o.headers||{})}; if(o.token)h.Authorization=`Bearer ${o.token}`; let body=o.raw; if(o.raw!==undefined&&o.ct) h['Content-Type']=o.ct; if(o.form){h['Content-Type']='application/x-www-form-urlencoded';body=new URLSearchParams(o.form)} else if(o.body!==undefined){h['Content-Type']=o.ct||'application/json';body=typeof o.body==='string'?o.body:JSON.stringify(o.body)} const r=await fetch(base+route,{method:o.method||'GET',headers:h,body}); const t=await r.text(); let d=null; try{d=JSON.parse(t)}catch{d=t} return {status:r.status,headers:Object.fromEntries(r.headers.entries()),text:t,data:d}}
async function login(app,u,p){let last; for(let i=0;i<30;i++){ last=app.name==='agri'?await req(app.base,'/api/login',{method:'POST',form:{username:u,password:p}}):await req(app.base,'/api/auth/login',{method:'POST',body:{username:u,password:p}}); if(last.data?.token||last.data?.access_token)break; await sleep(400)} return last.data?.token||last.data?.access_token||''}
const b64=o=>Buffer.from(JSON.stringify(o)).toString('base64url');
function sign(payload,secret,header={alg:'HS256',typ:'JWT'}){const data=`${b64(header)}.${b64(payload)}`; const sig=crypto.createHmac('sha256',secret).update(data).digest('base64url'); return `${data}.${sig}`}
try{
 for(const app of apps){start(app); await ready(app); proxy(app); app.owner=await login(app,'admin','admin123'); log(`${app.name} setup owner=${app.owner?'ok':'FAIL'}`)}
 const dairy=apps[0], agri=apps[1], flock=apps[2];
 log('\n=== JWT attacks (custom + jwt_tool) ===');
 for(const app of apps){
   const payload=JSON.parse(Buffer.from(app.owner.split('.')[1],'base64url').toString());
   log(`${app.name} real token payload keys=${Object.keys(payload).join(',')} exp=${payload.exp} iat=${payload.iat} ttlSec=${payload.exp-payload.iat}`);
   const none=`${b64({alg:'none',typ:'JWT'})}.${b64({...payload,exp:9999999999})}.`;
   let r=await req(app.base,'/api/farms',{token:none}); log(`${app.name} alg=none token -> GET /farms HTTP ${r.status}`);
   for(const weak of ['secret','password','123456','jwt-secret','change-me']){ const t=sign(payload,weak); r=await req(app.base,'/api/farms',{token:t}); if(r.status<400) log(`${app.name} WEAK SECRET ACCEPTED: ${weak} HTTP ${r.status}`); }
   log(`${app.name} weak-secret dictionary (secret,password,123456,jwt-secret,change-me): none accepted (only failures logged above)`);
   const expired=sign({...payload,iat:1000000000,exp:1000000100},SECRET); r=await req(app.base,'/api/farms',{token:expired}); log(`${app.name} expired-but-valid-signature token -> HTTP ${r.status}`);
   const kid=`${b64({alg:'HS256',typ:'JWT',kid:'../../dev/null'})}.${b64(payload)}.${crypto.createHmac('sha256',SECRET).update(`${b64({alg:'HS256',typ:'JWT',kid:'../../dev/null'})}.${b64(payload)}`).digest('base64url')}`; r=await req(app.base,'/api/farms',{token:kid}); log(`${app.name} kid-traversal header (signed with test secret) -> HTTP ${r.status} (proves kid ignored, not a vuln alone)`);
 }
 // jwt_tool decode dairy token
 try{ const toolOut=execSync(`python3 tools-round3/src/jwt_tool/jwt_tool.py ${dairy.owner}`,{cwd:root,encoding:'utf8',timeout:60000}); log(`jwt_tool decode dairy token:\n${toolOut.slice(0,1200)}`);}catch(e){log(`jwt_tool decode failed: ${String(e.stdout||e.message).slice(0,500)}`)}
 log('\n=== NoSQL injection (custom; NoSQLMap is Python2-only, see phase1-jwt-nosql-tools.txt) ===');
 const nosqlBodies=[{username:{'$ne':null},password:{'$ne':null}},{username:{'$regex':'^admin'},password:{'$ne':null}},{username:'admin',password:{'$gt':''}},{'$where':'1==1'}];
 for(const app of apps){ if(app.name==='agri') continue; for(const b of nosqlBodies){ const r=await req(app.base,'/api/auth/login',{method:'POST',body:b}); log(`${app.name} NoSQL JSON ${JSON.stringify(b)} -> HTTP ${r.status} token=${r.data?.token?'YES':'no'}`);} }
 // Agri urlencoded operator injection
 for(const form of [{'username[$ne]':'x','password[$ne]':'x'},{'username':'admin','password[$ne]':'x'},{'username[$regex]':'^admin','password[$gt]':''}]){
   const r=await req(agri.base,'/api/login',{method:'POST',form}); log(`agri NoSQL urlencoded ${JSON.stringify(form)} -> HTTP ${r.status} token=${r.data?.access_token?'YES':'no'} body=${JSON.stringify(r.data).slice(0,160)}`);
 }
 const rSan=await req(agri.base,'/api/crops',{method:'POST',token:agri.owner,body:{name:'R3 nosql crop','status':{'$ne':'x'}}}); log(`agri NoSQL operator in create field -> HTTP ${rSan.status} body=${JSON.stringify(rSan.data).slice(0,200)}`);
 log('\n=== Protocol abuse ===');
 const probes=[
  ['malformed JSON', '/api/cows', {method:'POST',token:dairy.owner,raw:'{"name":',ct:'application/json'}],
  ['duplicate JSON keys', '/api/cows', {method:'POST',token:dairy.owner,raw:'{"name":"dupA","name":"dupB","breed":"Jersey","gender":"female","status":"active"}',ct:'application/json'}],
  ['JSON as text/plain', '/api/cows', {method:'POST',token:dairy.owner,raw:'{"name":"ctcow","breed":"Jersey"}',ct:'text/plain'}],
  ['method override header', '/api/cows', {method:'POST',token:dairy.owner,body:{name:'overridecow',breed:'Jersey'},headers:{'X-HTTP-Method-Override':'DELETE'}}],
 ];
 for(const [label,route,o] of probes){ const r=await req(dairy.base,route,o); log(`dairy ${label} -> HTTP ${r.status} body=${String(r.text).slice(0,180)}`); }
 const big='x'.repeat(12*1024*1024); const rb=await req(dairy.base,'/api/cows',{method:'POST',token:dairy.owner,raw:JSON.stringify({name:big}),ct:'application/json'}); log(`dairy 12MB JSON body -> HTTP ${rb.status} body=${String(rb.text).slice(0,160)}`);
 for(const m of ['TRACE','OPTIONS']){ const st=await new Promise(resolve=>{ const rq=http.request({hostname:'127.0.0.1',port:dairy.port,path:'/api/farms',method:m,headers:{Authorization:`Bearer ${dairy.owner}`}},rs=>{rs.resume(); rs.on('end',()=>resolve(`${rs.statusCode} allow=${rs.headers.allow||''}`))}); rq.on('error',e=>resolve(`ERR ${e.message}`)); rq.end(); }); log(`dairy ${m} /api/farms -> HTTP ${st}`); }
 for(const path of ['/api//farms','/api/farms%2f..%2fhealth','/api/cows/%00','/api/cows/..;foo']){ const r=await req(dairy.base,path,{token:dairy.owner}); log(`dairy path ${path} -> HTTP ${r.status} body=${String(r.text).slice(0,120)}`); }
 log('\n=== Load through appending proxy (autocannon) ===');
 for(const app of apps){
   const url=`${app.pbase}/api/farms`;
   const ac=await new Promise(resolve=>{ execFile(path.join(root,'tools-round3/node_modules/.bin/autocannon'),['-c','10','-d','5','-H',`Authorization=Bearer ${app.owner}`,url],{cwd:root,timeout:120000,maxBuffer:10*1024*1024},(e,stdout,stderr)=>resolve(String(stdout)+String(stderr)+(e?`\nexit=${e.code}`:''))) });
   const summary=ac.split('\n').filter(l=>/requests in|responses|Latency|Req\/Sec|Bytes\/Sec|errors|non 2xx/i.test(l)).join(' | ');
   log(`${app.name} autocannon -c 10 -d 5 GET ${url} (through proxy): ${summary.slice(0,600)}`);
   fs.writeFileSync(path.join(outDir,`phase1-autocannon-${app.name}.txt`), `git rev-parse HEAD: ${head}\ncommand: autocannon -c 10 -d 5 -H Authorization=Bearer <redacted> ${url}\n${ac}\n`);
 }
 log('\n=== Chaos: SIGKILL + restart (memory mode data loss is EXPECTED, labelled) ===');
 const cow=await req(dairy.base,'/api/cows',{method:'POST',token:dairy.owner,body:{name:'Chaos Cow',breed:'Jersey',gender:'female',status:'active'}}); log(`dairy create before kill HTTP ${cow.status}`);
 dairy.proc.kill('SIGKILL'); await sleep(600);
 let down; try{ const r=await fetch(dairy.base+'/api/farms'); down=r.status }catch(e){ down=`CONNECTION FAILED (${e.cause?.code||e.message})` }
 log(`dairy after SIGKILL GET /api/farms -> ${down}`);
 start(dairy); // new proc replaces app.proc
 const ready2=await ready(dairy); dairy.owner=await login(dairy,'admin','admin123');
 const list=await req(dairy.base,'/api/cows?limit=5',{token:dairy.owner}); log(`dairy after restart ready=${ready2} GET /api/cows HTTP ${list.status} (memory mode: pre-kill records gone by design; production Mongo persistence UNVERIFIED)`);
 const bad=await req(dairy.base,'/api/cows',{method:'POST',token:dairy.owner,raw:'not json',ct:'application/json'}); log(`dairy post-restart malformed body -> HTTP ${bad.status}`);
} catch(e){ log(`FATAL ${e.stack||e}`)}
finally{ for(const s of proxies){try{s.close()}catch{}} for(const p of procs){try{p.kill('SIGTERM')}catch{}} await sleep(400); for(const p of procs){try{p.kill('SIGKILL')}catch{}} fs.writeFileSync(path.join(outDir,'phase1c-protocol-chaos-load.txt'),out.join('\n')+'\n'); }
