import { spawn, execSync } from 'node:child_process';
import fs from 'node:fs'; import path from 'node:path';
import fc from '../../tools-round3/node_modules/fast-check/lib/fast-check.js';
const root=process.cwd(); const head=execSync('git rev-parse HEAD',{cwd:root,encoding:'utf8'}).trim();
const out=[]; const log=s=>{out.push(String(s)); console.log(s)};
log(`git rev-parse HEAD: ${head}`); log('command: node tests/round3/fastcheck-commands.mjs'); log('environment: Agri direct local server, NODE_ENV=test, MEMORY_MODE=1');
const proc=spawn(process.execPath,['server.js'],{cwd:path.join(root,'agri_farm/backend'),env:{...process.env,PORT:'18903',NODE_ENV:'test',MEMORY_MODE:'1',MONGO_URI:'',MONGODB_URI:'',JWT_SECRET:'[SECURITY_DATA]',DISABLE_INTERNAL_SCHEDULER:'1',LOG_REQUESTS:'0'},stdio:'ignore'});
const base='http://127.0.0.1:18903/api'; const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function req(route,o={}){const h={}; if(o.token)h.Authorization=`Bearer ${o.token}`; let body; if(o.body!==undefined){h['Content-Type']='application/json'; body=JSON.stringify(o.body)} const r=await fetch(base+route,{method:o.method||'GET',headers:h,body}); const t=await r.text(); let d=null; try{d=JSON.parse(t)}catch{d=t} return {status:r.status,data:d}}
try{
 let token=''; for(let i=0;i<40&&!token;i++){ try{ const r=await fetch(base+'/login',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({username:'admin',password:'admin123'})}); const j=await r.json().catch(()=>({})); token=j.access_token||j.token||''; }catch{} if(!token) await sleep(400); }
 log(`setup token=${token?'ok':'FAIL'}`);
 // fc.commands: model = expected stored quantity IF the API behaved (never negative).
 // Commands create or adjust one inventory item; after the run we read the item back.
 class CreateCmd { constructor(q){this.q=q} check(){return true} async run(model, real){ const r=await req('/inventory',{method:'POST',token,body:{name:'FC Cmd Item',quantity:this.q,unit:'bags'}}); real.lastStatus=r.status; real.id=r.data?._id||real.id; model.accepted = r.status===201; model.quantity = r.status===201 ? this.q : model.quantity; } toString(){return `Create(${this.q})`} }
 class AdjustCmd { constructor(q){this.q=q} check(m){return !!m} async run(model, real){ if(!real.id) return; const r=await req(`/inventory/${real.id}`,{method:'PUT',token,body:{quantity:this.q}}); real.lastStatus=r.status; if(r.status===200) model.quantity=this.q; } toString(){return `Adjust(${this.q})`} }
 const cmdArb=fc.oneof(fc.integer({min:-50,max:50}).map(q=>new CreateCmd(q)), fc.integer({min:-50,max:50}).map(q=>new AdjustCmd(q)));
 try{
   await fc.assert(fc.asyncProperty(fc.commands([cmdArb],{maxCommands:6}), async (cmds)=>{ const setup={model:{quantity:0,accepted:false}, real:{id:'',lastStatus:0}}; await fc.asyncModelRun(()=>setup, cmds); if(setup.real.id){ const list=await req('/inventory?limit=500',{token}); const rows=Array.isArray(list.data)?list.data:(list.data?.items||list.data?.data||[]); const row=rows.find(x=>x._id===setup.real.id); if(row) { if(!(Number(row.quantity)>=0)) throw new Error(`stored quantity negative: ${row.quantity} after ${cmds.map(String).join(',')}`); } } }), {numRuns:8});
   log('fast-check commands: PASS');
 }catch(e){ log(`fast-check commands: FAIL -> ${String(e.message||e).slice(0,600)}`); }
} finally { proc.kill('SIGTERM'); await sleep(300); try{proc.kill('SIGKILL')}catch{} fs.writeFileSync(path.join(root,'results/round3/phase1-fastcheck.txt'), out.join('\n')+'\n'); }
