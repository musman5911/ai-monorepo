import subprocess, time, sys, os, requests
from hypothesis import given, settings, strategies as st

HEAD = subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip()
print(f'git rev-parse HEAD: {HEAD}')
print('command: python3 tests/round3/hypothesis_agri.py')
print('environment: Agri direct local server, NODE_ENV=test, MEMORY_MODE=1')

proc = subprocess.Popen(['node','server.js'], cwd='agri_farm/backend', env={**os.environ,'PORT':'18902','NODE_ENV':'test','MEMORY_MODE':'1','MONGO_URI':'','MONGODB_URI':'','JWT_SECRET':'[SECURITY_DATA]','DISABLE_INTERNAL_SCHEDULER':'1','LOG_REQUESTS':'0'}, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
base='http://127.0.0.1:18902/api'
try:
    token=None
    for _ in range(60):
        try:
            r=requests.post(base+'/login', data={'username':'admin','password':'admin123'}, timeout=2)
            token=r.json().get('access_token') or r.json().get('token')
            if token: break
        except Exception: pass
        time.sleep(0.5)
    print('setup token acquired:', bool(token))
    H={'Authorization':f'Bearer {token}'}

    @settings(max_examples=12, deadline=None)
    @given(amount=st.integers(min_value=-100000, max_value=100000))
    def test_liability_never_negative(amount):
        r=requests.post(base+'/liabilities', json={'creditor':'Hyp Cred','amount_owed':amount}, headers=H, timeout=5)
        if r.status_code==201:
            assert r.json().get('amount_owed',0) >= 0, f'negative liability stored: {r.json()}'

    @settings(max_examples=12, deadline=None)
    @given(qty=st.integers(min_value=-100000, max_value=100000))
    def test_inventory_never_negative(qty):
        r=requests.post(base+'/inventory', json={'name':'Hyp Item','quantity':qty,'unit':'bags'}, headers=H, timeout=5)
        if r.status_code==201:
            assert r.json().get('quantity',0) >= 0, f'negative inventory stored: {r.json()}'

    for name, fn in [('liability', test_liability_never_negative), ('inventory', test_inventory_never_negative)]:
        try:
            fn(); print(f'Hypothesis {name}: PASS (no counterexample in 12 examples)')
        except AssertionError as e:
            print(f'Hypothesis {name}: FAIL counterexample -> {e}')
finally:
    proc.terminate()
    try: proc.wait(timeout=5)
    except Exception: proc.kill()
