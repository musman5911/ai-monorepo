import { spawn, execSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const head = execSync('git rev-parse HEAD', { cwd: root, encoding: 'utf8' }).trim();
const outDir = path.join(root, 'results/round3');
fs.mkdirSync(outDir, { recursive: true });
const out = [];
function log(s='') { out.push(String(s)); console.log(s); }
log(`git rev-parse HEAD: ${head}`);
log(`environment: direct local servers, NODE_ENV=test, MEMORY_MODE=1, no proxy, no real MongoDB`);
log(`command: node tests/round3/phase1-dynamic.mjs`);

const apps = [
  { name:'dairy', dir:'dairy_farm/backend', port:18101 },
  { name:'agri', dir:'agri_farm/backend', port:18102 },
  { name:'flock', dir:'flock_farm/backend', port:18103 },
];
const JWT_SECRET='[SECURITY_DATA]';
const CRON_SECRET='[SECURITY_DATA]';
const procs=[];
async function waitReady(app){
  const base=`http://127.0.0.1:${app.port}`;
  for(let i=0;i<80;i++){
    try{ const r=await fetch(`${base}/api/farms`); if([200,401,403,404].includes(r.status)) return; }catch{}
    await new Promise(r=>setTimeout(r,300));
  }
  throw new Error(`${app.name} not ready`);
}
function start(app){
  const proc=spawn(process.execPath,['server.js'],{cwd:path.join(root,app.dir),env:{...process.env,PORT:String(app.port),NODE_ENV:'test',MEMORY_MODE:'1',MONGO_URI:'',MONGODB_URI:'',JWT_SECRET,CRON_SECRET,DAILY_SUMMARY_EMAILS:'',TELEGRAM_BOT_TOKEN:'',DISABLE_INTERNAL_SCHEDULER:'1',LOG_REQUESTS:'0'},stdio:['ignore','pipe','pipe']});
  proc.stdout.on('data',d=>log(`[${app.name} stdout] ${String(d).trim().slice(0,300)}`));
  proc.stderr.on('data',d=>log(`[${app.name} stderr] ${String(d).trim().slice(0,300)}`));
  procs.push(proc); app.base=`http://127.0.0.1:${app.port}`;
}
async function req(app, route, opts={}){
  const headers={...(opts.headers||{})};
  if(opts.token) headers.Authorization=`Bearer ${opts.token}`;
  if(opts.farmId) headers['X-Farm-Id']=opts.farmId;
  let body=opts.rawBody;
  if(opts.form){ headers['Content-Type']='application/x-www-form-urlencoded'; body=new URLSearchParams(opts.form); }
  else if(opts.body!==undefined){ headers['Content-Type']=opts.contentType||'application/json'; body=typeof opts.body==='string'?opts.body:JSON.stringify(opts.body); }
  const res=await fetch(`${app.base}/api${route}`,{method:opts.method||'GET',headers,body,redirect:'manual'});
  const text=await res.text();
  let data=null; try{data=text?JSON.parse(text):null}catch{data=text}
  return {status:res.status,headers:Object.fromEntries(res.headers.entries()),text,data};
}
function rows(data){
  if(Array.isArray(data)) return data;
  for(const k of ['items','data','rows','results','batches','crops','records','workers','buyers','suppliers','customers']) if(Array.isArray(data?.[k])) return data[k];
  return [];
}
function idOf(data){ const r=data?.record||data?.item||data?.crop||data?.batch||data?.task||data; return String(r?._id||r?.id||r?.batch_id||''); }
async function login(app,user,pass){
  const r=app.name==='agri'? await req(app,'/login',{method:'POST',form:{username:user,password:pass}}) : await req(app,'/auth/login',{method:'POST',body:{username:user,password:pass}});
  log(`${app.name} login ${user}: HTTP ${r.status} token=${r.data?.token||r.data?.access_token?'present':'absent'}`);
  return r.data?.token||r.data?.access_token||'';
}
function summarize(label,r,extra=''){
  const body=typeof r.data==='string'?r.data:JSON.stringify(r.data||'');
  log(`${label}: HTTP ${r.status} cache-control=${r.headers['cache-control']||''} csp=${r.headers['content-security-policy']?'present':'absent'} xcto=${r.headers['x-content-type-options']||''} xfo=${r.headers['x-frame-options']||''} robots=${r.headers['x-robots-tag']||''} referrer=${r.headers['referrer-policy']||''} body=${body.slice(0,500)} ${extra}`);
  return r;
}
try{
  for(const app of apps){ start(app); await waitReady(app); app.owner=await login(app,'admin','admin123'); app.worker=await login(app,'worker','worker123'); }
  for(const app of apps){
    log(`\n=== ${app.name} Phase1A/J headers/auth/public ===`);
    summarize(`${app.name} anon GET /farms`, await req(app,'/farms'));
    summarize(`${app.name} owner GET /farms`, await req(app,'/farms',{token:app.owner}));
    summarize(`${app.name} worker GET /farms`, await req(app,'/farms',{token:app.worker}));
    summarize(`${app.name} anon GET /farms/public`, await req(app,'/farms/public'));
    const cors=await fetch(`${app.base}/api/farms`,{headers:{Authorization:`Bearer ${app.owner}`,Origin:'https://evil.example.com'}});
    log(`${app.name} CORS evil origin: HTTP ${cors.status} ACAO=${cors.headers.get('access-control-allow-origin')} ACAC=${cors.headers.get('access-control-allow-credentials')}`);
    // JWT attacks: alg none-ish malformed, tampered payload, cross-app token
    const parts=app.owner.split('.');
    if(parts.length===3){
      const tampered=`${parts[0]}.${Buffer.from(JSON.stringify({id:'attacker',role:'admin',exp:9999999999})).toString('base64url')}.${parts[2]}`;
      summarize(`${app.name} tampered JWT GET /farms`, await req(app,'/farms',{token:tampered}));
      summarize(`${app.name} garbage JWT GET /farms`, await req(app,'/farms',{token:'not.a.jwt'}));
    }
    // NoSQL / prototype pollution probes on login and a list endpoint
    summarize(`${app.name} NoSQL login object probe`, app.name==='agri' ? await req(app,'/login',{method:'POST',form:{username:'admin',password:'x'}}) : await req(app,'/auth/login',{method:'POST',body:{username:{'$ne':null},password:{'$ne':null}}}));
    summarize(`${app.name} proto pollution query GET /farms`, await req(app,'/farms?__proto__[polluted]=1',{token:app.owner}));
    log(`${app.name} Object.prototype.polluted after probe: ${({}).polluted}`);
    // logout revocation
    const logoutRoute = app.name==='agri' ? '/logout' : '/auth/logout';
    const lo=await req(app,logoutRoute,{method:'POST',token:app.worker});
    const reuse=await req(app,'/farms',{token:app.worker});
    log(`${app.name} A1 logout+reuse: logout HTTP ${lo.status}; reuse GET /farms HTTP ${reuse.status} => ${reuse.status<400?'TOKEN STILL WORKS':'revoked/blocked'}`);
  }
  // Cross-app tokens
  log('\n=== cross-app JWT ===');
  for(const a of apps) for(const b of apps) if(a!==b){ const r=await req(b,'/farms',{token:a.owner}); log(`${a.name} owner token -> ${b.name} /farms: HTTP ${r.status}`); }

  log('\n=== Phase14 public cards ===');
  const cardChecks=[
    ['dairy','/buyers','/cards/buyer/'],['dairy','/suppliers','/cards/supplier/'],['dairy','/labor/workers','/cards/worker/'],
    ['agri','/suppliers','/cards/supplier/'],['agri','/labor/workers','/cards/worker/'],['agri','/workers','/cards/worker/'],
    ['flock','/customers','/cards/customer/'],['flock','/suppliers','/cards/supplier/'],['flock','/workers','/cards/worker/'],
  ];
  for(const [name,listRoute,cardRoute] of cardChecks){
    const app=apps.find(a=>a.name===name);
    const list=await req(app,listRoute,{token:app.owner});
    const rs=rows(list.data); const id=rs[0]?idOf(rs[0]):'';
    log(`${name} list ${listRoute}: HTTP ${list.status} rows=${rs.length} firstId=${id||'none'}`);
    const target=id||'000000000000000000000000';
    const card=await req(app,`${cardRoute}${target}`);
    const hasPhone=/03\d{2}-?\d{7}|Phone|فون/.test(card.text||'');
    summarize(`${name} ANON card ${cardRoute}${target}`,card,`phonePattern=${hasPhone} bytes=${(card.text||'').length}`);
  }

  log('\n=== Phase14 cron header auth ===');
  const flock=apps.find(a=>a.name==='flock'), agri=apps.find(a=>a.name==='agri');
  for(const [label,app,route] of [['flock',flock,'/cron/daily-summary'],['agri',agri,'/cron/dispatch-report']]){
    summarize(`${label} cron no key`, await req(app,route));
    summarize(`${label} cron wrong query key`, await req(app,`${route}?key=wrong`));
    summarize(`${label} cron wrong header`, await req(app,route,{headers:{'x-cron-key':'wrong'}}));
    summarize(`${label} cron correct header (auth passes; downstream may 503)`, await req(app,route,{headers:{'x-cron-key':CRON_SECRET}}));
    summarize(`${label} cron correct query key`, await req(app,`${route}?key=${CRON_SECRET}`));
  }
  summarize('agri public location', await req(agri,'/settings/location'));

  log('\n=== Phase1 money/validation/concurrency spot invariants ===');
  // Agri negative liability/inventory, Dairy invalid date, Flock oversell: routes from prior rounds; failures recorded, not asserted away.
  let r=await req(agri,'/liabilities',{method:'POST',token:agri.owner,body:{creditor:'R3 neg liability',amount_owed:-5000}});
  log(`agri G1 negative liability create: HTTP ${r.status} body=${JSON.stringify(r.data).slice(0,300)}`);
  r=await req(agri,'/inventory',{method:'POST',token:agri.owner,body:{name:'R3 neg inventory',quantity:-5,unit:'bags'}});
  log(`agri G2 negative inventory create: HTTP ${r.status} body=${JSON.stringify(r.data).slice(0,300)}`);
  r=await req(agri,'/crops',{method:'POST',token:agri.owner,body:{name:'R3 huge acres',area_kanal:999999999,status:'active',plant_date:'2026-02-30'}});
  log(`agri invalid-date/huge-area crop create: HTTP ${r.status} body=${JSON.stringify(r.data).slice(0,300)}`);
  const dairy=apps.find(a=>a.name==='dairy');
  r=await req(dairy,'/cows',{method:'POST',token:dairy.owner,body:{name:'R3 cow',breed:'Jersey',gender:'female',status:'active',birthDate:'2026-02-30'}});
  log(`dairy FZ-2 invalid birthDate cow create: HTTP ${r.status} body=${JSON.stringify(r.data).slice(0,300)}`);
  // Telegram unbounded expense K1 endpoint probe: inspect via expenses with telegram-like source if route accepts; at minimum create huge expense amount.
  r=await req(dairy,'/expenses',{method:'POST',token:dairy.owner,body:{name:'R3 huge expense',amount:999999999999,category:'feed',date:'2026-10-01'}});
  log(`dairy huge expense create: HTTP ${r.status} body=${JSON.stringify(r.data).slice(0,300)}`);
  // Concurrent duplicate creates CC-1 spot: 10 parallel identical inventory creates in Agri
  const dupes=await Promise.all(Array.from({length:10},()=>req(agri,'/inventory',{method:'POST',token:agri.owner,body:{name:'R3 dupe item',quantity:1,unit:'bags'}})));
  log(`agri CC spot 10 parallel identical inventory creates statuses: ${dupes.map(x=>x.status).join(',')}`);
} catch(e){ log(`FATAL ${e.stack||e}`); }
finally{
  for(const p of procs){ try{p.kill('SIGTERM')}catch{} }
  await new Promise(r=>setTimeout(r,500));
  for(const p of procs){ try{p.kill('SIGKILL')}catch{} }
  fs.writeFileSync(path.join(outDir,'phase1-dynamic.txt'), out.join('\n')+'\n');
}
