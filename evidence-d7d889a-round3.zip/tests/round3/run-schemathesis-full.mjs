import { spawn, execFileSync, execSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd(); const head=execSync('git rev-parse HEAD',{cwd:root,encoding:'utf8'}).trim();
const apps=[{name:'dairy',dir:'dairy_farm/backend',port:18301},{name:'agri',dir:'agri_farm/backend',port:18302},{name:'flock',dir:'flock_farm/backend',port:18303}];
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function login(app,base,u,p){
 const route=app.name==='agri'?'/api/login':'/api/auth/login';
 const isAgri=app.name==='agri';
 const res=await fetch(base+route,{method:'POST',headers:{'Content-Type':isAgri?'application/x-www-form-urlencoded':'application/json'},body:isAgri?new URLSearchParams({username:u,password:p}):JSON.stringify({username:u,password:p})});
 const j=await res.json().catch(()=>({})); return j.token||j.access_token||'';
}
for(const app of apps){
 for(const role of ['owner','worker','anon']){
   const lines=[`git rev-parse HEAD: ${head}`,`app=${app.name} role=${role} environment=direct local server NODE_ENV=test MEMORY_MODE=1 no proxy`,`command: schemathesis run tests/round3/specs-full/spec-${app.name}-full.yaml --url http://127.0.0.1:${app.port}/api -n 2 ${role==='anon'?'':'-H Authorization: Bearer <redacted>'}`];
   const proc=spawn(process.execPath,['server.js'],{cwd:path.join(root,app.dir),env:{...process.env,PORT:String(app.port),NODE_ENV:'test',MEMORY_MODE:'1',MONGO_URI:'',MONGODB_URI:'',JWT_SECRET:'[SECURITY_DATA]',CRON_SECRET:'[SECURITY_DATA]',DAILY_SUMMARY_EMAILS:'',TELEGRAM_BOT_TOKEN:'',DISABLE_INTERNAL_SCHEDULER:'1',LOG_REQUESTS:'0'},stdio:'ignore'});
   try{
     const base=`http://127.0.0.1:${app.port}`; let ready=false;
     for(let i=0;i<80&&!ready;i++){try{const r=await fetch(base+'/api/farms'); if(r.status) ready=true;}catch{} if(!ready) await sleep(300);}
     let token=''; if(role!=='anon') token=await login(app,base,role==='owner'?'admin':'worker',role==='owner'?'admin123':'worker123');
     lines.push(`setup: ready=${ready} tokenAcquired=${!!token}`);
     const args=['run',`tests/round3/specs-full/spec-${app.name}-full.yaml`,'--url',`${base}/api`,'-n','2','--workers','4'];
     if(token) args.push('-H',`Authorization: Bearer ${token}`);
     let out=''; try{ out=execFileSync('schemathesis',args,{cwd:root,encoding:'utf8',timeout:600000,maxBuffer:50*1024*1024}); }catch(e){ out=String(e.stdout||'')+String(e.stderr||'')+`\nSCHemathesis exit=${e.status}`; }
     lines.push(out);
   } finally { proc.kill('SIGTERM'); await sleep(400); try{proc.kill('SIGKILL')}catch{} }
   const file=`results/round3/schemathesis-full-${app.name}-${role}.txt`; fs.writeFileSync(file,lines.join('\n')+'\n'); console.log(file);
 }
}
console.log('done');
