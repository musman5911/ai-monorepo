EVIDENCE PACKAGE — A–O audit verification
Tested upstream commit: 1e68a8b82f8ddbf3de0afec0e7defe855ab8f338 (branch muf-monorepo tip at test time)
NOTE: a second verification on the NEW tip follows in the chat report; this package is the 1e68a8b run.

CONTENTS
  tests/api-deep/        deep behavioral + role-system suites (vitest, 242 checks)
  tests/api-matrix/      field-validation matrices + harness (tests/api-matrix/harness.ts)
  tests/toolchain/       fast-check invariants, security scan, spawn.mjs, stryker config, bruno starter
  tests/verification/    contested-probes.sh (curl evidence), contested-probes-output.txt, locust-agri.py
  e2e/toolchain-visual-a11y.spec.ts   Playwright visual + axe spec (needs local Playwright browsers; NOT re-run in sandbox)
  results/               RAW outputs of every run in this package:
                           api-matrix-and-toolchain.txt (142 checks)
                           api-deep.txt (242 checks)
                           upstream-own-suite.txt (upstream tests/ at 1e68a8b)
                           contested-extra.txt / c4-evidence.txt (curl-level probes)

ENVIRONMENT (all local runs)
  MEMORY_MODE=1  JWT_SECRET=[SECURITY_DATA]  DISABLE_INTERNAL_SCHEDULER=1  NODE_ENV=test
  No FRONTEND_URL / CORS_ORIGIN set (this is why C2 reflects in test env; production default differs — see report).
  Real MongoDB: NOT available in the sandbox; all results are memory mode.

COMMANDS
  npm install                      # repo root (vitest etc.), then in each app dir: dairy_farm/backend, dairy_farm/client, agri_farm/backend, agri_farm/frontend, flock_farm/backend, flock_farm/client
  npx vitest run tests/api-matrix tests/toolchain
  npx vitest run tests/api-deep
  npx vitest run tests/toolchain/fastcheck-invariants.test.ts     # G1/G2 property tests
  npx vitest run tests/api-deep/round11-role-system.test.ts tests/api-deep/round11-role-agri.test.ts tests/api-deep/round11-role-flock.test.ts
  bash tests/verification/contested-probes.sh                     # A4/C2/E11 curl evidence
  locust -f tests/verification/locust-agri.py --headless -u 10 -r 10 -t 30s --host http://127.0.0.1:<agri-port>
  npx playwright test e2e/toolchain-visual-a11y.spec.ts           # axe/visual — needs browsers installed

READING THE RESULTS
  Failing tests are the finding probes (each failure = one reproduced finding, named in plain English).
  results/*.txt are the unedited vitest outputs from the runs above.
